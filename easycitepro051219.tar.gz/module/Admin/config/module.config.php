<?php
namespace Admin;
use Zend\Router\Http\Literal;
use Zend\Router\Http\Segment;
use Zend\ServiceManager\Factory\InvokableFactory;
use Zend\Mvc\Controller\LazyControllerAbstractFactory;
return [
    'router' => [
        'routes' => [
				'adminescapeslace' => [
					'type' => 'literal',
					'options' => [
						'route' => '/admin',
						'defaults' => [
							'controller' => Controller\LoginController::class,
							'action' => 'login',
						],
					],
				],
				'adminwithslace' => [
					'type' => 'literal',
					'options' => [
						'route' => '/admin/',
						'defaults' => [
							'controller' => Controller\LoginController::class,
							'action' => 'login',
						],
					],
					],
				'login' => [
					'type'    => Segment::class,
					'options' => [
						'route' => '/admin/login[/:action]',
						'constraints' => [
							'action' => '[a-zA-Z][a-zA-Z0-9_-]*',
						],
						'defaults' => [
							'controller' => Controller\LoginController::class,
							'action'     => 'login',
						],
					],
				],
				'admin' => [
					'type'    => Segment::class,
					'options' => [
						'route' => '/admin/index[/:action[/:id]]',
						'constraints' => [
							'action' => '[a-zA-Z][a-zA-Z0-9_-]*',
							'id'     => '[0-9]+',
						],
						'defaults' => [
							'controller' => Controller\IndexController::class,
							'action'     => 'index',
						],
					],
				],
				'offer' => [
					'type'    => Segment::class,
					'options' => [
						'route' => '/admin/offer[/:action[/:id]]',
						'constraints' => [
							'action' => '[a-zA-Z][a-zA-Z0-9_-]*',
							'id'     => '[0-9]+',
						],
						'defaults' => [
							'controller' => Controller\OfferController::class,
							'action'     => 'list',
						],
					],
				],
				'customer' => [
					'type'    => Segment::class,
					'options' => [
						'route' => '/admin/customer[/:action[/:id]]',
						'constraints' => [
							'action' => '[a-zA-Z][a-zA-Z0-9_-]*',
							'id'     => '[0-9]+',
						],
						'defaults' => [
							'controller' => Controller\CustomerController::class,
							'action'     => 'index',
						],
					],
				],
				'order' => [
					'type'    => Segment::class,
					'options' => [
						'route' => '/admin/order[/:action[/:id][/:page]]',
						'constraints' => [
							'action' => '[a-zA-Z][a-zA-Z0-9_-]*',
							'id'     => '[0-9]+',
							'page'     => '[0-9]+',
						],
						'defaults' => [
							'controller' => Controller\OrderController::class,
							'action'     => 'index',
						],
					],
				],
            ],
        ],
    'controllers' => [
        'factories' => [
			'Admin\Controller\LoginController' => \Admin\Controller\Factory\LoginControllerFactory::class,
			'Admin\Controller\CommonController' => \Admin\Controller\Factory\CommonControllerFactory::class,
			'Admin\Controller\IndexController' => \Admin\Controller\Factory\IndexControllerFactory::class,
			'Admin\Controller\OfferController' => function($sm){
              $commservice = new \Admin\Service\CommonService();
              $commservice->setController('\Admin\Controller\OfferController');
              return $commservice->createService($sm);  
           },
			'Admin\Controller\CustomerController' => \Admin\Controller\Factory\CustomerControllerFactory::class,
		   'Admin\Controller\OrderController' => \Admin\Controller\Factory\OrderControllerFactory::class,
		   
        ],
    ],
    'view_manager' => [
        'template_path_stack' => [
            'Admin' => __DIR__ . '/../view',
        ],
		'template_map' => [
            'layout/login' => __DIR__ . '/../view/layout/login.phtml',
			'layout/dashboard' => __DIR__ . '/../view/layout/dashboard.phtml',
        ]
    ],
	'view_helpers' => [
        'factories' => [      
		  '\Admin\View\Helper\GetOrderStatus'=> \Admin\View\Helper\Factory\GetOrderStatusFactory::class,
      
        ],
        'aliases' => [
			'orderStatus'=> '\Admin\View\Helper\GetOrderStatus',
        ]
    ],	
	'service_factory' => [
		'invokables' => [
		 ],
	],
	'service_manager' => [
        'factories' => [
             \Zend\Authentication\AuthenticationService::class => Service\Factory\AuthenticationServiceFactory::class,
            'Admin\Service\AuthAdapter'=> \Admin\Service\Factory\AuthAdapterFactory::class,
            'Admin\Service\AuthManager'=> \Admin\Service\Factory\AuthManagerFactory::class,
			'Admin\Service\CommonService'=> \Admin\Service\Factory\CommonServiceFactory::class,

        ]
    ],
];


