<?php
namespace Admin\Form;use Zend\Form\Form;use Zend\InputFilter\InputFilter;use Application\Entity\Post;
/**
 * This form is used to collect post data.
 */
class LoginForm extends Form
{
    /**		* Constructor.     	*/
    public function __construct()	{
        // Define form name		parent::__construct('login-form');		// Set POST method for this form		$this->setAttribute('method', 'post');		$this->addElements();		$this->addInputFilter();  	}
    /**
     * This method adds elements to form (input fields and submit button).
     */
    protected function addElements() 
    {
         $this->add([        
            'type'  => 'text',
            'name' => 'username',
            'attributes' => [
                'id' => 'username',
                'class'=>'username form-control'
            ],
            'options' => [
                'label' => 'Username',
            ],
        ]);
		$this->add([        			'type'  => 'password',			'name' => 'password',			'attributes' => [				'id' => 'password',				'class'=>'password form-control'			],			'options' => [				'label' => 'Password',			],		]);
        // Add the CSRF field		$this->add([			'type' => 'csrf',			'name' => 'csrf',			'options' => [			'csrf_options' => [					'timeout' => 600				],				'label' => 'Csrf',			],		]);
       $this->add([			'type'  => 'submit',			'attributes' => [                                'value' => 'Sign In',                'id' => 'submitbutton',            ],        ]);    }
     /**
     * This method creates input filter (used for form filtering/validation).
     */
    private function addInputFilter() 	{		$inputFilter = new InputFilter();        		$this->setInputFilter($inputFilter);		$inputFilter->add([
                'name'     => 'username',
                'required' => true,
                'filters'  => [
                    ['name' => 'StringTrim'],
                    ['name' => 'StripTags'],
                    ['name' => 'StripNewlines'],
                ],                
                'validators' => [
                    [
                        'name'    => 'StringLength',
                        'options' => [
                            'min' => 2,
                            'max' => 25
                        ],
                    ],
                ],
            ]);
			$inputFilter->add([
                'name'     => 'password',
                'required' => true,
            ]);	}
}