<?php
namespace Admin\View\Helper;
use Zend\View\Helper\AbstractHelper;
	/* 
	 * **********************************************************
	 * File Name:			GetOrderStatus.php
	 * Description:			Helper to get the HTML for the order status in the admin panel order listing.
	 * Created By:			1984
	 * Company:				Synapse India Outsourcing Pvt. Ltd.
	 * Created On:			DEC 04, 2019
	 * Last Modified On:	DEC 04, 2019
	 * Modified By:         1984
	 * **********************************************************
	*/
class GetOrderStatus extends AbstractHelper {

private $dbAdapter;
	
	public function __construct($db)
    {
		$this->dbAdapter = $db;
    }
	
	public function render($order_detail) 
	{
		// Check whether CC information is deleted or not (Start)
		$CcdetailsTable =  new \Admin\Model\CcdetailsTable();
		$CcdetailsTable($this->dbAdapter); 
		$data = $CcdetailsTable->fetchCcdetailsByOrderId($order_detail['id']);
		if(isset($data['id'])):
			$cc_deletion = false;
		else:
			$cc_deletion = true;
		endif;
		// Check whether CC information is deleted or not (End)
			
 		if($order_detail['xml_status'] == 'SEND' && $order_detail['parent_order_id']!="")
		{
			$duplicate_order=$order_detail['parent_order_id'];
			$html='<i class="fa fa-clone btn-danger btn-sm" aria-hidden="true" title="Duplicate order placed before 24 hours of Order Id : '.$duplicate_order.'"></i>&nbsp;&nbsp;<i class="fa fa-repeat btn-danger btn-sm" aria-hidden="true" title="Can\'t resubmit this Order"></i>';	
			
		}else{
			
			if($order_detail['xml_status'] == 'SEND'):
				if($order_detail['resubmission_status'] == 'N'):
					$html = '<i class="fa fa-check btn-success btn-sm" aria-hidden="true" title="Order Completed"></i>&nbsp;&nbsp;<i class="fa fa-repeat btn-danger btn-sm" aria-hidden="true" title="Can\'t resubmit this Order"></i>';
			 	 else:
					$html = '<i class="fa fa-repeat btn-success btn-sm" aria-hidden="true" title="Successfully resubmitted"></i>&nbsp;&nbsp;<i class="fa fa-repeat btn-danger btn-sm" aria-hidden="true" title="Can\'t resubmit this Order"></i>';
				endif;
			elseif ($order_detail['xml_status'] == 'UNSEND' || $order_detail['xml_status'] == 'NONE'):
				/* if($cc_deletion):
					$html = '<i class="fa fa-shopping-cart btn-danger btn-sm" aria-hidden="true"  title="CC information deleted"></i>&nbsp;&nbsp;<i class="fa fa-repeat btn-danger btn-sm" aria-hidden="true" title="Can\'t resubmit this Order"></i>';
				else: */
					$html = '<i class="fa fa-warning btn-danger btn-sm" aria-hidden="true"  title="Order recieved successfully and XML unsend to Innotrac"></i>&nbsp;&nbsp;<a href=""><i class="fa fa-repeat btn-success btn-sm" aria-hidden="true" title="Re-submit this Order"></i></a>';
				//endif;
			endif;
			
		} 	
		return $html;

	}
}