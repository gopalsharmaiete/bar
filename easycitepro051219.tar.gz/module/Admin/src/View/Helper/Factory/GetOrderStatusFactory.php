<?php
namespace Admin\View\Helper\Factory;
use Interop\Container\ContainerInterface;
use Admin\View\Helper\GetOrderStatus;
/* 
 * **********************************************************
 * File Name:			GetOrderStatusFactory.php
 * Description:			Factory to set depandancy for GetOrderStatus.
 * Created By:			1984
 * Company:				Synapse India Outsourcing Pvt. Ltd.
 * Created On:			DEC 04, 2019
 * Last Modified On:	DEC 04, 2019
 * Modified By:         1984
 * **********************************************************
*/
class GetOrderStatusFactory
{

    public function __invoke(ContainerInterface $container, $requestedName, array $options = null)
	{
			
		
		$db = $container->get('Zend\Db\Adapter\Adapter');
		return new GetOrderStatus($db);

    }	
	
}