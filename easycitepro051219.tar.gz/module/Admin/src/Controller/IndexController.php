<?php
/**
 * @Controller   : IndexController for dashboard related functionality 
 * @Created Date : 24-09-2019
 * @Created By   : 1984
 */
namespace Admin\Controller;
use Zend\View\Model\ViewModel;
use Zend\Mvc\Controller\AbstractActionController;


class IndexController extends AbstractActionController
{


	private $dbAdapter;
	
	public function __construct($db)
    {
		$this->dbAdapter = $db;
    }	
    /*
     * dashboardAction() - Method to show dashboard detail
     * @access public
     * @return void
     */
    public function dashboardAction()
    {
    	try{
			$this->layout()->setTemplate('layout/dashboard');
			
			$CustomerTable =  new \Admin\Model\OrdersTable();
			
			$CustomerTable($this->dbAdapter);  ;
			$result = $CustomerTable->fetchAll();
			//print_r($result);
    	}
    	catch(\Exception $e){
			$this->flashMessenger()->addErrorMessage($e->getMessage());
			return $this->redirect()->toUrl('/admin');
		}
       
    }
}
