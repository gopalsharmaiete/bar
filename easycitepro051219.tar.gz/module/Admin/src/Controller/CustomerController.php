<?php
/**
 * @Controller   : CustomerController for offer related functionality 
 * @Created Date : 24-09-2019
 * @Created By   : 1984
 */
namespace Admin\Controller;
use Zend\View\Model\ViewModel;
use Zend\Mvc\Controller\AbstractActionController;

class CustomerController extends AbstractActionController
{


	private $dbAdapter;
	
	public function __construct($db)
    {
		$this->dbAdapter = $db;
    }
    /*
     * indexAction() - Method to show Customer listing
     * @access public
     * @return void
     */
    public function indexAction()
    {
    	try{
			$this->layout()->setTemplate('layout/dashboard');
 			$CustomerTable =  new \Admin\Model\CustomersTable();
			//echo "Customer Index"; die;
			$CustomerTable($this->dbAdapter);  
			$result = $CustomerTable->fetchAll();
			return new ViewModel(array('data'=>$result)); 
		}catch(\Exception $e){
			echo $e; die;
			$this->flashMessenger()->addErrorMessage($e->getMessage());
			return $this->redirect()->toUrl('/admin');
		}
       
    }
}