<?php
/**
 * @Controller   : CustomerController for offer related functionality 
 * @Created Date : 24-09-2019
 * @Created By   : 1984
 */
namespace Admin\Controller;
use Zend\View\Model\ViewModel;
use Zend\Mvc\Controller\AbstractActionController;
use Zend\Paginator\Adapter;
use Zend\Paginator\Paginator;
class OrderController extends AbstractActionController
{


	private $dbAdapter;
	
	public function __construct($db)
    {
		$this->dbAdapter = $db;
    }
    /*
     * indexAction() - Method to show Customer listing
     * @access public
     * @return void
     */
    public function indexAction()
    {
		
    	try{
			$this->layout()->setTemplate('layout/dashboard');
			$OrdersTable =  new \Admin\Model\OrdersTable();
			$OrdersTable($this->dbAdapter);  
			$result = $OrdersTable->fetchAll();
			if($this->getRequest()->isGet()) {
				// Fill in the form with POST data
				$data = $this->params()->fromQuery(); 
				//print_r($data); die;
			}
			$paginator = new Paginator(new Adapter\ArrayAdapter($result));	
			$paginator->setCurrentPageNumber((int) $this->params()->fromQuery('page', 1));
			$paginator->setItemCountPerPage(2);			 
			return new ViewModel(array('paginator'=>$paginator)); 
		}catch(\Exception $e){ 
			echo $e; die;
			$this->flashMessenger()->addErrorMessage($e->getMessage());
			return $this->redirect()->toUrl('/admin');
		}
       
    }
}
