<?php
namespace Admin;

use Zend\Db\Adapter\AdapterInterface;
use Zend\Db\ResultSet\ResultSet;
use Zend\Db\TableGateway\TableGateway;
use Zend\ModuleManager\Feature\ConfigProviderInterface;
use Zend\ModuleManager\ModuleManager;
use Zend\Authentication\AuthenticationService;
use Zend\Http\Request;
use Zend\Mvc\MvcEvent;
use Zend\Session\Container;
use Zend\Session\SessionManager;
use Zend\Session\Validator\HttpUserAgent;
use Zend\Session\Validator\RemoteAddr;
class Module
{
    /**
     * @var AuthenticationService
     */
    private $auth;
    public function getConfig()
    {
        return include __DIR__ . '/../config/module.config.php';
    }
	
	public function getServiceConfig()
    {
        return array(
            'factories' => array(
                Model\AdminTable::class =>  function($container) {
                    $tableGateway = $container->get(Model\AdminTableGateway::class);
                    $table = new Model\AdminTable($tableGateway);
                    return $table;
                },
                Model\AdminTableGateway::class => function ($container) {
                    $dbAdapter = $container->get(AdapterInterface::class);
					$resultSetPrototype = new ResultSet();
                    $resultSetPrototype->setArrayObjectPrototype(new \Admin\Model\Admin());
                    return new TableGateway('tbl_admin', $dbAdapter, null, $resultSetPrototype);
                },
            ),
        );
    }
    public function onBootstrap(MvcEvent $mvcEvent)
    {
        $this->bootstrapSession($mvcEvent);
        $this->auth = $mvcEvent->getApplication()->getServiceManager()->get(AuthenticationService::class);
        // store user and role in global viewmodel
        if ($this->auth->hasIdentity()) {
            // for e.g. store your auth identity into ViewModel
            $mvcEvent->getViewModel()->setVariable('authIdentity', $this->auth->getIdentity());
            // extend functionality with acl to checkPermission if user has rights to the given route
        } else {		
		$request = $mvcEvent->getRequest();
		var_dump($mvcEvent->getParams()->getUrl());
			echo "<pre>"; print_r(get_class_methods($request));
		die;
    //    echo $controller = $mvcEvent->getTarget();
        echo $controllerName = $mvcEvent->getRouteMatch()->getParam('controller');
        echo  $actionName = $mvcEvent->getRouteMatch()->getParam('action'); die;
            if (!$this->auth->hasIdentity() && $mvcEvent->getRequest()->getUri() != 'admin/login/login') {
                $response = $mvcEvent->getResponse();
                $response->getHeaders()->addHeaderLine('Location',$mvcEvent->getRouter()->assemble(array(),array('name' => 'admin/login/login')));
                $response->setStatusCode(302);
                return $response;
            }
        }				
				
    }
	
	
	
	
	
	
    /**
     * @param MvcEvent $e
     */
    private function bootstrapSession($e)
    {
        /** @var SessionManager $session */
        $session = $e->getApplication()->getServiceManager()->get(SessionManager::class);
        $session->start();
        $container = new Container('your_session_name', $session);
        if (isset($container->init)) {
            return;
        }
        /** @var Request $request */
        $request = $e->getRequest();
        $session->regenerateId(true);
        $container->init = 1;
        $container->remoteAddr = $request->getServer()->get('REMOTE_ADDR');
        $container->httpUserAgent = $request->getServer()->get('HTTP_USER_AGENT');
        $config = $e->getApplication()->getServiceManager()->get('config');
        if (!isset($config['session'])) {
            return;
        }
        if (!isset($config['session_validators'])) {
            return;
        }
        $chain = $session->getValidatorChain();
        foreach ($config['session_validators'] as $validator) {
            switch ($validator) {
                case HttpUserAgent::class:
                    $validator = new $validator($container->httpUserAgent);
                    break;
                case RemoteAddr::class:
                    $validator = new $validator($container->remoteAddr);
                    break;
                default:
                    $validator = new $validator();
            }
            $chain->attach('session.validate', [$validator, 'isValid']);
        }
    }
}