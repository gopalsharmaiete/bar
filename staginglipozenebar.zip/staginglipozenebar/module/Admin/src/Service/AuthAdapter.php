<?php
namespace Admin\Service;

use Zend\Authentication\Adapter\AdapterInterface;
use Zend\Authentication\Result;
use Zend\Crypt\Password\Bcrypt;
use Admin\Model\AdminTable;
use Zend\Session\Container;
use Zend\Session\SessionManager;

/**
 * Adapter used for authenticating user. It takes login and password on input
 * and checks the database if there is a user with such login (email) and password.
 * If such user exists, the service returns his identity (email). The identity
 * is saved to session and can be retrieved later with Identity view helper provided
 * by ZF3.
 */
class AuthAdapter implements AdapterInterface
{
    /**
     * User email.
     * @var string 
     */
    private $username;
    
    /**
     * Password
     * @var string 
     */
    private $password;
    
    /**
     * admintable.
     */
    private $table;
        
    /**
     * Constructor.
     */
    public function __construct(AdminTable $admintable)
    {
        $this->table = $admintable;
		
    }
    
    /**
     * Sets user email.     
     */
    public function setUsername($username) 
    {
        $this->username = $username;        
    }
    
    /**
     * Sets password.     
     */
    public function setPassword($password) 
    {
        $this->password = (string)$password;        
    }
    
    /**
     * Performs an authentication attempt.
     */
    public function authenticate()
    {                
       // $admins = $this->table->fetchAll();
		//echo '<pre>'; print_r( $admins); die;


        $this->password = md5($this->password);
		
		// Check the database if there is a user with such email.
        $user = $this->table->checkAdminUserExist($this->username,$this->password);
              
        // If there is no such user, return 'Identity Not Found' status.
        if ($user==null) {
            return new Result(
                Result::FAILURE_IDENTITY_NOT_FOUND, 
                null, 
                ['Invalid credentials.']);        
        }   
        
        // If the user with such email exists, we need to check if it is active or retired.
        // Do not allow retired users to log in.
        if ($user->status==0) {
            return new Result(
                Result::FAILURE, 
                null, 
                ['User is inactive.']);        
        }
        if ($user->id) {
            // Great! The password hash matches. Return user identity (email) to be
            // saved in session for later use.
            $sessionContainer = new Container('LoggeedInUser', new SessionManager());
            $sessionContainer->userdata = $user;

            return new Result(
                    Result::SUCCESS, 
                    $this->username, 
                    ['Authenticated successfully.']);        
        }             
                
    }
}