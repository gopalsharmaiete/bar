<?php
/**
 * @link      http://github.com/zendframework/ZendSkeletonModule for the canonical source repository
 * @copyright Copyright (c) 2005-2016 Zend Technologies USA Inc. (http://www.zend.com)
 * @license   http://framework.zend.com/license/new-bsd New BSD License
 */
namespace Admin\Controller;
use Admin\Model\AdminTable;
use Zend\View\Model\ViewModel;
use Zend\Mvc\Controller\AbstractActionController;
use Admin\Form\LoginForm;


class IndexController extends AbstractActionController
{
	private $table;

	private $authManager;
	
	public function __construct($authManager)
    {

		$this->authManager = $authManager;
    }

    public function checkUserLoggedIn(){

        $logged_in = $this->authManager->isUserLoggedIn(); //$this->authService->getIdentity();
        if($logged_in){
        	return $this->redirect()->toUrl('/admin/dashboard');
        }
    }

    public function indexAction()
    {
  		$this->checkUserLoggedIn();
  		return $this->redirect()->toUrl('/admin/login');


    }
	
	public function loginAction()
	{
			if ($this->getRequest()->isPost()) {
				// Fill in the form with POST data
				$data = $this->params()->fromPost();            
				$form = new LoginForm(); 
				$form->setData($data);
				// Validate form
				if($form->isValid()) {
					try{
						$result = $this->authManager->login($data['username'],$data['password'],true);
						if($result->getCode()!=1){
						 	$this->flashMessenger()->addErrorMessage('Invalid username or password');
							return $this->redirect()->toUrl('/admin/login');
						 }
					 	if($result->getIdentity()){
					 		//logged in
					 		return $this->redirect()->toUrl('/admin/dashboard');
					 	}
						
					}
					catch(\Exception $e){
						$this->flashMessenger()->addErrorMessage('Error in login. please try again');
						return $this->redirect()->toUrl('/admin/login');
					}

				}else{

					//echo '<pre>'; print_r($form->getMessages()); die;
					$messages = $form->getMessages();
					if(isset($messages['csrf']['notSame'])){
						$this->flashMessenger()->addErrorMessage($messages['csrf']['notSame']);
						
					}else{
						$this->flashMessenger()->addErrorMessage('Error in data. please try again');
					}
					return $this->redirect()->toUrl('/admin/login');
					
				}
        }

        $this->checkUserLoggedIn();
		$this->layout()->setTemplate('layout/login');      
		 return new ViewModel([
	            'form' =>new LoginForm(),
	     ]);

	}


	/**
     * The "logout" action performs logout operation.
     */
    public function logoutAction()
    {
    	try{
    		 $this->authManager->logout();
       		 $this->flashMessenger()->addSuccessMessage('You have been logged out.');
			return $this->redirect()->toUrl('/admin/login');
    	}
    	catch(\Exception $e){
			$this->flashMessenger()->addErrorMessage($e->getMessage());
			return $this->redirect()->toUrl('/admin/login');
		}
       
    }
}
