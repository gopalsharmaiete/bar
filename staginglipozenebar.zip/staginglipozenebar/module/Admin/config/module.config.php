<?php
namespace Admin;
use Zend\Router\Http\Literal;
use Zend\Router\Http\Segment;
use Zend\ServiceManager\Factory\InvokableFactory;

return [
    'router' => [
        'routes' => [
            'admin' => [
                'type'    => Segment::class,
                'options' => [
					'route' => '/admin[/:action]',
                    'defaults' => [
                        'controller'    => Controller\IndexController::class,
                        'action'        => 'index',
                    ],
                ],
                'may_terminate' => true,
                'child_routes' => [
                ],
            ],
			'login' => [
				'type' => Segment::class,
				'options' => [
					'route'    => '/admin[/:action]',
					'defaults' => [
							'controller' => Controller\IndexController::class,
							'action'     => 'login',
					],
					'constraints' => [
						'action' => '[a-zA-Z][a-zA-Z0-9_-]+',
					]
				],
			],
			'dashboard' => [
				'type' => Literal::class,
				'options' => [
					'route'    => 'admin/dashboard',
					'defaults' => [
							'controller' => Controller\IndexController::class,
							'action'     => 'index',
					]
				]
			],
        ],
    ],
    'controllers' => [
        'factories' => [
			'Admin\Controller\IndexController' => \Admin\Controller\Factory\IndexControllerFactory::class,
        ],
    ],
    'view_manager' => [
        'template_path_stack' => [
            'Admin' => __DIR__ . '/../view',
        ],
		'template_map' => [
            'layout/login' => __DIR__ . '/../view/layout/login.phtml'
        ]
    ],
	'service_manager' => [
        'factories' => [
             \Zend\Authentication\AuthenticationService::class => Service\Factory\AuthenticationServiceFactory::class,
            'Admin\Service\AuthAdapter'=> \Admin\Service\Factory\AuthAdapterFactory::class,
            'Admin\Service\AuthManager'=> \Admin\Service\Factory\AuthManagerFactory::class,

        ]
    ],
];
