<?php
namespace Admin\Model;
class Admin{
    public $id;	public $first_name;	public $last_name;	public $username;	public $role;	public $status;
	public function exchangeArray(array $data)	{		$this->id     = (isset($data['id'])) ? $data['id'] : null;		$this->first_name = (isset($data['first_name'])) ? $data['first_name'] : null;		$this->last_name  = (isset($data['last_name'])) ? $data['last_name'] : null;		$this->username  = (isset($data['username'])) ? $data['username'] : null;		$this->role  = (isset($data['role'])) ? $data['role'] : null;		$this->status  = (isset($data['status'])) ? $data['status'] : null;	}
}