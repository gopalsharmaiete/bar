<?phpnamespace Admin\Controller\Factory;use Interop\Container\ContainerInterface;use Admin\Controller\OfferController;use Zend\ServiceManager\Factory\FactoryInterface;use Admin\Service\AuthAdapter;use Admin\Service\AuthManager;
/** * This is the factory for IndexController. Its purpose is to instantiate the controller * and inject dependencies into its constructor.**/
class OfferControllerFactory implements FactoryInterface
{
    public function __invoke(ContainerInterface $container, $requestedName, array $options = null)	{		$authManager = $container->get(AuthManager::class);		return new OfferController($authManager);
    }
}
