<?phpnamespace Admin\Controller\Factory;use Interop\Container\ContainerInterface;use Admin\Controller\IndexController;use Zend\ServiceManager\Factory\FactoryInterface;use Admin\Service\AuthAdapter;use Admin\Service\AuthManager;
/** * This is the factory for LoginController. Its purpose is to instantiate the controller * and inject dependencies into its constructor.**/
class IndexControllerFactory implements FactoryInterface
{
    public function __invoke(ContainerInterface $container, $requestedName, array $options = null)	{		return new IndexController($authManager);
    }
}
