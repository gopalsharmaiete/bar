<?php
/**
 * @Controller   : IndexController for dashboard related functionality 
 * @Created Date : 24-09-2019
 * @Created By   : 1984
 */
namespace Admin\Controller;
use Admin\Model\AdminTable;
use Zend\View\Model\ViewModel;
use Zend\Mvc\Controller\AbstractActionController;


class IndexController extends AbstractActionController
{

	
    /*
     * dashboardAction() - Method to show dashboard detail
     * @access public
     * @return void
     */
    public function dashboardAction()
    {
    	try{
			$this->layout()->setTemplate('layout/dashboard');
    	}
    	catch(\Exception $e){
			$this->flashMessenger()->addErrorMessage($e->getMessage());
			return $this->redirect()->toUrl('/admin');
		}
       
    }
}
