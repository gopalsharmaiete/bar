<?php
/**
 * @Controller   : OfferController for offer related functionality 
 * @Created Date : 24-09-2019
 * @Created By   : 1984
 */
namespace Admin\Controller;
use Zend\View\Model\ViewModel;
use Admin\Controller\MasterController;


class OfferController extends MasterController
{

	
    /*
     * indexAction() - Method to show offer listing
     * @access public
     * @return void
     */
    public function indexAction()
    {
		echo "offer"; 
    	try{
			$this->layout()->setTemplate('layout/dashboard');
			$offerstable =  new \Admin\Model\OffersTable();
			
			//dbAdapter will automatically getted !
			$offerstable($this->dbAdapter);  
			 
			$result = $offerstable->fetchAll();
			//just test 😉
			foreach($result as $key=>$row){
				echo $row['title'];
			}
			die;
				return new ViewModel();
			}
    	catch(\Exception $e){
			echo $e; die;
			$this->flashMessenger()->addErrorMessage($e->getMessage());
			return $this->redirect()->toUrl('/admin');
		}
       
    }
}