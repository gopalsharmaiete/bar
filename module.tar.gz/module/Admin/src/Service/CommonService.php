<?php
namespace Admin\Service;
 
use Zend\ServiceManager\FactoryInterface;
use Zend\ServiceManager\ServiceLocatorInterface;
 
 
class CommonService
{
    protected $controller;
 
     
    public function createService(ServiceLocatorInterface $services)
    {
        $dbAdapter      = $services->get('Zend\Db\Adapter\Adapter');
         
        $controller = new $this->controller;
        $controller->setDbAdapter($dbAdapter);
         
        return $controller;
    }
     
    //setter controller 
    public function setController($controller)
    {
        $this->controller = $controller;
    }
}
