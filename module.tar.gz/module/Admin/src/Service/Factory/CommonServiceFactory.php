<?php
namespace Admin\Service\Factory;

use Interop\Container\ContainerInterface;
use Zend\ServiceManager\Factory\FactoryInterface;
use Admin\Service\CommonService;
use Admin\Service\AuthManager; 
 
 
class CommonServiceFactory implements FactoryInterface
{
    /**
     * This method creates the Common service and returns its instance. 
     */
    public function __invoke(ContainerInterface $container, $requestedName, array $options = null)
    {
	  
        $authManager = $container->get(AuthManager::class);
		$conftable = $container->get(AdminTable::class);
        return new CommonService($conftable,$authManager);
    }
}
