<?php
namespace Admin;
use Zend\Router\Http\Literal;
use Zend\Router\Http\Segment;
use Zend\ServiceManager\Factory\InvokableFactory;

return [
    'router' => [
        'routes' => [
				'adminescapeslace' => [
					'type' => 'literal',
					'options' => [
						'route' => '/admin',
						'defaults' => [
							'controller' => Controller\LoginController::class,
							'action' => 'login',
						],
					],
				],
				'adminwithslace' => [
					'type' => 'literal',
					'options' => [
						'route' => '/admin/',
						'defaults' => [
							'controller' => Controller\LoginController::class,
							'action' => 'login',
						],
					],
					],
				'login' => [
					'type'    => Segment::class,
					'options' => [
						'route' => '/admin/login[/:action]',
						'constraints' => [
							'action' => '[a-zA-Z][a-zA-Z0-9_-]*',
						],
						'defaults' => [
							'controller' => Controller\LoginController::class,
							'action'     => 'login',
						],
					],
				],
				'admin' => [
					'type'    => Segment::class,
					'options' => [
						'route' => '/admin/index[/:action[/:id]]',
						'constraints' => [
							'action' => '[a-zA-Z][a-zA-Z0-9_-]*',
							'id'     => '[0-9]+',
						],
						'defaults' => [
							'controller' => Controller\IndexController::class,
							'action'     => 'index',
						],
					],
				],
				'offer' => [
					'type'    => Segment::class,
					'options' => [
						'route' => '/admin/offer[/:action[/:id]]',
						'constraints' => [
							'action' => '[a-zA-Z][a-zA-Z0-9_-]*',
							'id'     => '[0-9]+',
						],
						'defaults' => [
							'controller' => Controller\OfferController::class,
							'action'     => 'index',
						],
					],
				],
            ],
        ],
    'controllers' => [
        'factories' => [
			'Admin\Controller\LoginController' => \Admin\Controller\Factory\LoginControllerFactory::class,
			'Admin\Controller\CommonController' => \Admin\Controller\Factory\CommonControllerFactory::class,
			'Admin\Controller\IndexController' => \Admin\Controller\Factory\IndexControllerFactory::class,
			'Admin\Controller\OfferController' => function($sm){
              $commservice = new \Admin\Service\CommonService();
              $commservice->setController('\Admin\Controller\OfferController');
              return $commservice->createService($sm);  
           },
        ],
    ],
    'view_manager' => [
        'template_path_stack' => [
            'Admin' => __DIR__ . '/../view',
        ],
		'template_map' => [
            'layout/login' => __DIR__ . '/../view/layout/login.phtml',
			'layout/dashboard' => __DIR__ . '/../view/layout/dashboard.phtml',
        ]
    ],
	'service_factory' => [
		'invokables' => [
		   'Admin\Model\OffersTable' => 'Admin\Model\OffersTable',
		 ],
	],
	'service_manager' => [
        'factories' => [
             \Zend\Authentication\AuthenticationService::class => Service\Factory\AuthenticationServiceFactory::class,
            'Admin\Service\AuthAdapter'=> \Admin\Service\Factory\AuthAdapterFactory::class,
            'Admin\Service\AuthManager'=> \Admin\Service\Factory\AuthManagerFactory::class,
			'Admin\Service\CommonService'=> \Admin\Service\Factory\CommonServiceFactory::class,

        ]
    ],
];


