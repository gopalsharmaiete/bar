<?php

// Define path to application directory
defined('APPLICATION_PATH') || define('APPLICATION_PATH', realpath(dirname(__FILE__) . '/application'));
defined('ROOT_PATH') || define('ROOT_PATH', realpath(dirname(__FILE__) . ''));


require_once "public/DB_vars.php";
require_once "public/system_vars.php";
require_once "public/commonfunction.php";

// Define application environment
defined('APPLICATION_ENV')|| define('APPLICATION_ENV', (getenv('APPLICATION_ENV') ? getenv('APPLICATION_ENV') : 'production'));

// Ensure library/ is on include_path
/*set_include_path(implode(PATH_SEPARATOR, array(
    realpath(APPLICATION_PATH . '/../library'),
    get_include_path(),
)));*/
set_include_path(implode(PATH_SEPARATOR,
	array(
		realpath(APPLICATION_PATH),
		realpath('library'),
		APPLICATION_PATH . '/controllers',
		APPLICATION_PATH . '/forms',
		get_include_path(),
)));

/** Zend_Application */
require_once 'Zend/Application.php';

// Create application, bootstrap, and run
$application = new Zend_Application(
    APPLICATION_ENV,
    APPLICATION_PATH . '/configs/application.ini'
);
$application->bootstrap()
            ->run();