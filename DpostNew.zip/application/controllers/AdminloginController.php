<?php

class AdminloginController extends Zend_Controller_Action
{

    public $Model = null;

    public $params = null;

    public function init()
    {
        /* Initialize action controller here */
	  
    }

    public function indexAction()
    {
	  global $objSession;
	   try{	
	        $auth = Zend_Auth::getInstance();
	        if($auth->hasIdentity()){ 
			   $this->_redirect('Dashboard');
			}
		$this->Model = new Application_Model_Adminlogin();
		$this->params = $this->_request->getParams();
		//$obj->test();
	 }catch(Exception $e){
	    echo $e->getMessage();die;
	 }	
	
        // action body
		if($this->getRequest()->isPost()){
                $authAdapter = new Zend_Auth_Adapter_DbTable($this->Model->getAdapter(),USERS,'username','password');
				
				//echo md5($this->params['admin_password']); die;
                $authAdapter->setIdentity($this->params['admin_userid'])
                        	->setCredential(md5($this->params['admin_password']));
                $result = $auth->authenticate($authAdapter);
				if ($result->isValid()) {
				    $logicSeesion = new Zend_Session_Namespace('logicSeesion');
					$logicSeesion->userconfig = $this->Model->getUserconfigs($authAdapter->getResultRowObject()->user_id);
					//Zend_Session::namespaceUnset('logicSeesion');
					if(isset($this->params['url'])){	
						 $this->_redirect(urldecode($this->params['url']));
					}else{
						 $this->_redirect('Dashboard');
					}
					
               }else{
			       Zend_Auth::getInstance()->clearIdentity();
				   $objSession->errorMsg = "Email or password is invalid.";
			   }
	    	}
    }

    public function logoutAction()
    {
        $auth = Zend_Auth::getInstance();
		$auth->clearIdentity();
		Zend_Session::namespaceUnset('logicSeesion');
		$this->_redirect(BASE_URL);
    }


}



