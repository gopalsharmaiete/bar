<?php
ini_set('display_errors','1');
class ParceltrackingController extends Zend_Controller_Action
{

    public function init()
    {
		   try{	
				$this->_helper->layout->setLayout('popup');
				$this->Request = $this->_request->getParams();
				$this->ModelObj = new Application_Model_Parceltracking();
				$this->ModelObj->getData  = $this->Request;
				$this->view->Request = $this->Request;
				$this->view->ModelObj = $this->ModelObj;
				if(isset($this->Request['tockenno']) && $this->Request['tockenno']!=''){
				  $this->ModelObj->getData[BARCODE_ID] = Zend_Encript_Encription::decode($this->Request['tockenno']);
				}
				if(isset($this->Request['tocken']) && $this->Request['tocken']!=''){
				  $this->ModelObj->getData[BARCODE_ID] = base64_decode(base64_decode($this->Request['tocken']));
				}
				if(isset($this->Request['trackingnumber']) && $this->Request['trackingnumber']!=''){
					$this->ModelObj->getData[BARCODE_ID] = $this->ObjModel->SpecialTrackingBarcodeid($this->Request['trackingnumber']);
				}
		 }catch(Exception $e){
			echo $e->getMessage();die;
		 }
    }

    public function indexAction()
    {
        // action body
    }

    public function trackingAction()
    {  
        $this->_helper->layout->setLayout('popup');
		$this->view->parcelinfo = $this->ModelObj->parcelinformation();
    }


}



