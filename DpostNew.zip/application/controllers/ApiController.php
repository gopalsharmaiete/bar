<?php
ini_set('display_errors','1');
class ApiController extends Zend_Rest_Controller
{
	public $ObjModel;
	public $response=NULL;

    public function init()
    {  
       $this->_helper->layout->disableLayout();
	   $this->ObjModel 	= new Application_Model_ApiShipping();
	   $this->ObjModel->setDataToIndex($this->_request->getParams());
    }

    public function indexAction()
    {
        $this->_helper->viewRenderer->setNoRender(true);
    }
	public function getAction()
    {
        $this->_helper->viewRenderer->setNoRender(true);
    }
	public function headAction(){
	     $this->_helper->viewRenderer->setNoRender(true);
	}
	public function postAction(){
	 $uservalidation = $this->ObjModel->UsernamePasswordValidation();
	 if(!empty($uservalidation)){
		  print $this->_handleStruct($uservalidation);exit;
	 }
	 switch($this->ObjModel->getData['ActionCode']){
		   case 'add':
				$this->response = $this->ObjModel->AddApiShipment();
		   break;
		   case 'edit':
		   break;
		   case 'delete':
		   break;
		   case 'sendercodelist':
		   break;
		   case 'parcelstatus':
		   break;
		   case 'checkinshipment':
		   break;
		   case 'newshipment':
		   break;
		   case 'getrouting':
		   break;
		   case 'getstatus':
		   break;
		  default:
		      $this->response = array('Status'=>'Invalid Action');
		  break; 
	   }	
		$this->getResponse ()->setHeader ( 'Content-Type', 'text/xml' ); 
		print $this->_handleStruct($this->response);exit;
		$this->_helper->viewRenderer->setNoRender(true);
	}
	public function putAction()
    {
	 $this->_helper->viewRenderer->setNoRender(true);
	}
	public function deleteAction()
    {
        $this->_helper->viewRenderer->setNoRender(true);
    }
	public function ResponseAction(){
	     $this->_helper->viewRenderer->setNoRender(true);
	}
	public function picqerAction()
	{
		// These variables are standard variables used by PHP for Basic Auth
		if (isset($_SERVER['PHP_AUTH_USER']) && isset($_SERVER['PHP_AUTH_PW'])) {
		 
			// Get the username and password from Basic Auth
			$_POST['username'] = $_SERVER['PHP_AUTH_USER'];
			$_POST['password'] = $_SERVER['PHP_AUTH_PW'];
			
			// Check if username and password are correct (as given in Picqer JSON Push settings)
    		if (!empty($_POST['username']) && !empty($_POST['password'])) {
				// Retrieve the JSON push data 
				$postData = file_get_contents('php://input');
				
				/*$LogFileName = YODEL_LABEL_LINK.'/'.date('YmdHis').'_picqer.log';
				$LogHeader = fopen($LogFileName,'a+');
				fwrite($LogHeader, $postData);
				fclose($LogHeader);*/
				
				$rawData  = json_decode($postData);
				$orderDetail = $rawData->picklist;
				
				//URL Data
				$service = $this->_request->getParams();
				
				$_POST['weight'] 		= (isset($rawData->weight)) ? ($rawData->weight/1000) : 0.1;
				$_POST['quantity'] 		= 1;
				$_POST['shipto'] 		= $orderDetail->deliveryname;
				$_POST['contact'] 		= $orderDetail->deliverycontact;
				$_POST['street'] 		= $orderDetail->deliveryaddress;
				$_POST['streetno'] 		= '';
				$_POST['address1'] 		= '';
				$_POST['address2'] 		= $orderDetail->deliveryaddress2;
				$_POST['postalcode'] 	= $orderDetail->deliveryzipcode;
				$_POST['city'] 			= $orderDetail->deliverycity;
				$_POST['countrycode'] 	= $orderDetail->deliverycountry;
				$_POST['phone'] 		= $orderDetail->telephone;
				$_POST['email'] 		= $orderDetail->emailaddress;
				$_POST['servicecode'] 	= (isset($service['service']) && !empty($service['service'])) ? trim($service['service']) : 'A';
				$_POST['price'] 	    = '';
				$_POST['reference'] 	= (isset($orderDetail->reference) && !empty($orderDetail->reference)) ? $orderDetail->reference : $orderDetail->idorder;
				$_POST['goods_type'] 	= ''; //Goods Tyoe of the Parcel - Optional Field
				$_POST['goods_description'] = ''; //Goods Description of the Parcel - Optional Field
				$_POST['labeltype']		= 'PDF';
				$_POST['shipment_status']= 10;
				
				$this->ObjModel->setDataToIndex($_POST); //print_r($_POST);die;
				
				$uservalidation = $this->ObjModel->UsernamePasswordValidation();
				if(!empty($uservalidation)){
				  print $this->_handleStruct($uservalidation);exit;
				}
					
				$Error = $this->ObjModel->ErrorCheck();
				if(empty($Error)){
						$this->response = $this->ObjModel->AddApiShipment();
						$barcode = explode(':',$this->response['Success']['TrackingDetails']['ParcelNumber1']);
						$filenme = explode('pdf/',$this->response['Success']['LabelURL']);
						$trackurl= explode('URL:',$this->response['Success']['TrackingDetails']['TrackingURL1']);
					  
						$resp['identifier'] = $barcode[1];
						$resp['trackingurl'] = $trackurl[1];
						$resp['label']['filename'] = $filenme[1];
						$resp['label']['filetype'] = "application/pdf";
						$resp['label']['file'] = $this->response['Success']['Label'];
						
						/*$LogFileName = YODEL_LABEL_LINK.'/'.date('YmdHis').'_picqer.log';
						$LogHeader = fopen($LogFileName,'a+');
						fwrite($LogHeader, $trackurl[1]);
						fclose($LogHeader);*/
						
						// Send the response back to Picqer
						header("HTTP/1.1 200 OK");
						echo json_encode($resp);
						exit;
				}
				else{
					// No authorization data given
					header("HTTP/1.1 401 Empty Weight");
					$this->response = $Error;
					print_r(json_encode($this->response));
					exit;
				}
			}
			else{
				// No authorization data given
				header("HTTP/1.1 401 Empty Credential");
				exit;
			}
		}
		else{
			// No authorization data given
			header("HTTP/1.1 401 Unauthorized Credential");
			exit;
		}
	   
	   	$this->_helper->viewRenderer->setNoRender(true);
	}
	
	/**
	  * Handle an array or object result
	  *
	  * @param array|object $struct Result Value
	  * @return string XML Response
	  */
    protected function _handleStruct($struct) {
	  $dom = new DOMDocument ( '1.0', 'UTF-8' );
	  $root = $dom->createElement ( "xml" );
	  $method = $root;
	   
	 // $root->setAttribute ( 'generator', 'Yiyu Blog' );
	  //$root->setAttribute ( 'version', '1.0' );
	  $dom->appendChild ( $root );
	   
	  $this->_structValue ( $struct, $dom, $method );
	   
	  $struct = ( array ) $struct;
	   //$status = $dom->createElement ( 'status', 'success' );
	   //$method->appendChild ( $status );
	   //$dom->save('simple_eng.xml');
	   return $dom->saveXML ();
	 }
	 /**
	  * Recursively iterate through a struct
	  *
	  * Recursively iterates through an associative array or object's properties
	  * to build XML response.
	  *
	  * @param mixed $struct
	  * @param DOMDocument $dom
	  * @param DOMElement $parent
	  * @return void
	  */
   protected function _structValue($struct, DOMDocument $dom, DOMElement $parent) {
  $struct = ( array ) $struct;
   
  foreach ( $struct as $key => $value ) {
   if ($value === false) {
    $value = 0;
   } elseif ($value === true) {
    $value = 1;
   }
    
   if (ctype_digit ( ( string ) $key )) {
    $key = 'key_' . $key;
   }
    
   if (is_array ( $value ) || is_object ( $value )) {
    $element = $dom->createElement (str_replace(range(0,9),'',$key));
    $this->_structValue ( $value, $dom, $element );
   } else {
    $element = $dom->createElement (str_replace(range(0,9),'',$key));
    $element->appendChild ( $dom->createTextNode ( $value ) );
   }
    
   $parent->appendChild ( $element );
  }
 }


}

