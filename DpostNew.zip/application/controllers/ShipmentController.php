<?php
ini_set('display_errors','1');
class ShipmentController extends Zend_Controller_Action
{

    public $ModelObj = null;

    private $Request = array();

    public function init()
    {
        /* Initialize action controller here */ 
		try{	
			$this->_helper->layout->setLayout('main');
			$this->Request = $this->_request->getParams();
			$this->ModelObj = new Application_Model_Shipments();
			$this->ModelObj->getData  = $this->Request;
			$this->view->Request = $this->Request;
			$this->view->ModelObj = $this->ModelObj;
	 }catch(Exception $e){
	    echo $e->getMessage();die;
	 }	
    }

    public function indexAction()
    {
        // action body
    }

    public function addshipmentAction()
    {
//Zend_Encript_Encription::encode('Hello');
		 global $objSession,$labelObj;
		  if(isset($objSession->AddSipmentLabel)){
		     $labelObj->_filePath = $objSession->AddSipmentLabel; 
		     unset($objSession->AddSipmentLabel);
	         $labelObj->printLabel();
		  }
        // action body
		 if($this->_request->IsPost()){
		 	//$this->ModelObj->shipment_type = 0;
		    $this->ModelObj->addShipment();
			$this->_redirect($this->_request->getControllerName().'/'.$this->_request->getActionName());  
		 }
		 $this->view->customerlist = $this->ModelObj->getCustomerList();
	     $this->view->countrylist =  $this->ModelObj->getCountryList();
    }
	public function customerdeclarationAction()
    {
        $this->_helper->layout->setLayout('popup');
		// action body
		 if($this->_request->IsPost()){
		    $this->ModelObj->shipment_type = 0;
		    $this->ModelObj->addShipment();
			echo '<script type="text/javascript">window.top.location.href = "'.BASE_URL.'/Shipment/addshipment";parent.jQuery.fancybox.close();</script>';exit();
			
		 }
		 $this->view->countrylist =  $this->ModelObj->getCountryList();
		 $this->view->goodslist   =  $this->ModelObj->getGoodsCategory();
		 if(isset($this->Request['addservice_id']) && ($this->Request['addservice_id']==126 || $this->Request['addservice_id']==149)){
		 	$commonObj =  new Application_Model_Common();
		    $this->view->parcelpointlist   =  $commonObj->getParcelshopList($this->Request['country_id'],$this->Request[ZIPCODE]);
		 }
		  //$this->ModelObj->CountryInfomations();
		 
    }
	public function editshipmentAction()
    {
          
		 $this->view->records = $this->ModelObj->getShipmentById(); 
        // action body
		 if($this->_request->IsPost()){
		 	//$this->ModelObj->shipment_type = 0;
		    $this->ModelObj->editShipment($this->view->records);
			$this->_redirect($this->_request->getControllerName().'/showallparcel');  
		}
	   //$this->view->records = $this->ModelObj->getShipmentById();
	   $this->view->customerlist = $this->ModelObj->getCustomerList();
	   $this->view->countrylist =  $this->ModelObj->getCountryList();
    }

    public function newshipmentAction()
    {
         /*global $objSession,$labelObj;
		  if(isset($objSession->AddSipmentLabel)){
		     $labelObj->_filePath = $objSession->AddSipmentLabel; 
		     unset($objSession->AddSipmentLabel);
	         $labelObj->printLabel();
		  }
        // action body
		 if($this->_request->IsPost()){
		 	$this->ModelObj->shipment_type = 0;
		    $this->ModelObj->addShipment();
			$this->_redirect($this->_request->getControllerName().'/'.$this->_request->getActionName());  
		 }*/
		$this->view->records = $this->ModelObj->getNewShipment();
		$this->view->customerlist = $this->ModelObj->getCustomerList();
    }

    public function showallparcelAction()
    {  
		 global $objSession,$labelObj;
		  if(isset($objSession->AddSipmentLabel)){
		     $labelObj->_filePath = $objSession->AddSipmentLabel; 
		     unset($objSession->AddSipmentLabel);
	         $labelObj->printLabel();
		  }
        if($this->_request->isPost() && isset($this->Request['shipment_mode']) && isset($this->Request['shipment_id'])){
		   $this->ModelObj->PrintAction();
		}elseif($this->_request->isPost() && (isset($this->Request['BulkShipping']) || isset($this->Request['BulkPrint']))){
		   $this->ModelObj->BulkPrinting();   
		}/*elseif($this->_request->isPost() && isset($this->Request['shipment_mode']) && !isset($this->Request['shipment_id'])){
		     $objSession->errorMsg = "Please Select row(s)";
		}*/
		$this->view->records = $this->ModelObj->getShowAllShipments();
		$this->view->countrylist =  $this->ModelObj->getCountryList();
	    $this->view->depotlist =  $this->ModelObj->getDepotList();
		$this->view->customerlist =  $this->ModelObj->getCustomerList();
		$this->view->forwarderlist =  $this->ModelObj->getForwarderList();
		$this->view->servicelist =  $this->ModelObj->getCustomServiceList();
		$this->view->addedtype = $this->ModelObj->ParcelAddedType();
    }

    public function shipmenthistoryAction()
    {
        // action body
		if(isset($this->Request['export']) && $this->Request['export']!=''){
		      $this->ModelObj->ExportHistory();
		}
		$this->view->records = $this->ModelObj->getShipmentHistory();
		$this->view->countrylist =  $this->ModelObj->getCountryList();
	    $this->view->depotlist =  $this->ModelObj->getDepotList();
		$this->view->customerlist =  $this->ModelObj->getCustomerList();
		$this->view->forwarderlist =  $this->ModelObj->getForwarderList();
		$this->view->servicelist =  $this->ModelObj->getCustomServiceList();
		$this->view->addedtype = $this->ModelObj->ParcelAddedType();
    }

    public function viewshipmentAction()
    {
        // action body
		$this->_helper->layout->setLayout('popup');
		$this->view->records = $this->ModelObj->getShowAllShipments();
		$this->view->countrylist =  $this->ModelObj->getCountryList();
		$this->view->forwarderlist =  $this->ModelObj->getForwarderList();
    }

    public function importshipmentAction()
    {
        if($this->_request->isPost() && (!empty( $this->Request['import']) || !empty( $this->Request['importwithHeader']))){
		   $error_data = $this->ModelObj->importShipment(1);
		   $this->_redirect($this->_request->getControllerName().'/importlist'); 
		}
		$this->view->customerlist = $this->ModelObj->getCustomerList();
    }
	public function importlistAction(){ 
	     if($this->_request->isPost() && (isset($this->Request['shipment_mode']) && isset($this->Request['shipment_id'])) || isset($this->Request['shipment_mode1'])){ 
		   $this->ModelObj->importPrint();
		   $this->_redirect($this->_request->getControllerName().'/importlist'); 
		}
		$this->view->importlist = $this->ModelObj->getImportShipmentList();
		$this->view->countrylist =  $this->ModelObj->getCountryList();
		$this->view->depotlist =  $this->ModelObj->getDepotList();
		$this->view->customerlist =  $this->ModelObj->getCustomerList();
		$this->view->forwarderlist =  $this->ModelObj->getForwarderList();
	}
    public function showaddbookAction()
    {
       $this->_helper->layout->setLayout('popup');
	   $this->view->records = $this->ModelObj->AddressBookList();
	   $this->view->countrylist =  $this->ModelObj->getCountryList();
    }
	public function shipmentvalidateAction(){
	     $this->ModelObj->ErrorCheck(1);die;
	}
	public function importsampleAction(){
	    $csvheaders = $this->ModelObj->getImportheaders();
		$header = array();
		foreach($csvheaders as $csvheader){
		  $header[] = $csvheader;
		}
		commonfunction::ExportCsv(commonfunction::implod_array(array_reverse($header),';'),'Import_sample');
	}
	public function importerrorAction(){
	
	}
}



















