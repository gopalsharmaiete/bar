<?php

class DashboardController extends Zend_Controller_Action
{
	public $ModelObj = null;
    private $Request = array();

    public function init()
    {
        /* Initialize action controller here */
		 try{	
			$this->_helper->layout->setLayout('dashboard');
			$this->Request = $this->_request->getParams();
			$this->ModelObj = new Application_Model_Dashboard();
			$this->ModelObj->getData  = $this->Request;
			$this->view->Request = $this->Request;
			$this->view->ModelObj = $this->ModelObj;
	 }catch(Exception $e){
	    echo $e->getMessage();die;
	 }	
		
    }

    public function indexAction()
    {
        $this->view->addedParcel = $this->ModelObj->AddedParcel();
		$this->view->deliveredParcel = $this->ModelObj->DeliveredParcel();
		$this->view->errorParcel = $this->ModelObj->ErrorParcel();
		if($this->ModelObj->Useconfig['level_id']==5){
		   $this->view->pickups = $this->ModelObj->PlannedPickup();
		   //$this->view->pickups = $this->ModelObj->shopAPiorders();
		}
		if($this->ModelObj->Useconfig['level_id']==4 || $this->ModelObj->Useconfig['level_id']==6 || $this->ModelObj->Useconfig['level_id']==5 || $this->ModelObj->Useconfig['level_id']==10){
			$this->view->openinvoices = $this->ModelObj->openInvoices();
			$this->view->opentickets = $this->ModelObj->openTickets();
		}
    }
	public function shopordersAction(){
	      $this->ModelObj->shopAPiorders();
	}
}

