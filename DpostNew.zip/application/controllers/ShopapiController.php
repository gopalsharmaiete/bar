<?php
ini_set('display_errors','1');
class ShopapiController extends Zend_Controller_Action
{
	public $ModelObj = null;
    private $Request = array();
    public function init()
    {
      		$this->_helper->layout->setLayout('main');
			$this->Request = $this->_request->getParams();
			$this->ModelObj = new Application_Model_Shopapi();
			$this->ModelObj->getData  = $this->Request;
			$this->view->Request = $this->Request;
			$this->view->ModelObj = $this->ModelObj;
    }

    public function indexAction()
    {
        // action body
    }
	public function shopimportAction(){
	     if($this->_request->isPost()){
		    $import = $this->ModelObj->ImportFromShop();
		    if($import){
			     $this->_redirect('Shipment/importlist');
			}
		 }
	     $this->view->shopList = $this->ModelObj->getShopList();
	}
	public function ordercountAction(){
	    $this->_helper->layout->setLayout('main');
		$this->ModelObj->getOrderCount();
	}
}

