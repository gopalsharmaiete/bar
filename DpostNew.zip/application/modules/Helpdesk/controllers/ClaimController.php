<?php
ini_set('display_errors','1');
class Helpdesk_ClaimController extends Zend_Controller_Action
{

     public $Request = array();
     public $ModelObj = null;
	 
	
     /**
	 * Auto load NameSpace and create objects 
	 * Function : init()
	 * Auto call and loads the default namespace and create object of model and form
	 **/
	 
     public function init()
     { 
		try{
			$this->Request = $this->_request->getParams();
			$this->ModelObj = new Helpdesk_Model_ClaimManager();
			$this->formObj = new Helpdesk_Form_Helpdesk();
			$this->ModelObj->getData  = $this->Request;
			$this->view->ModelObj = $this->ModelObj;
			$this->_helper->layout->setLayout('main');
	   }catch(Exception $e){
	    echo $e->getMessage();
	   }
     }

    
	public function claimlistAction(){
	  
    }
	
     	 
	public function claimsettingAction(){
	  $this->view->allquestions = $this->ModelObj->allclaimquestions();
	  
    }
	
	/**
	* Action for getting all claims
	* Function : claimstatusAction()
	* Date of creation 13/01/2017
	**/
	public function claimstatusAction(){
	  $this->view->claimstatus = $this->ModelObj->getclaimstatus();
	}
	
	/**
	* Action for adding new claim question
	* Function : claimstatusAction()
	* Date of creation 18/01/2017
	**/
	public function addnewclaimquestionAction(){
	 try{
		 global $objSession;
		  $this->view->operatortype = $this->ModelObj->operatortype();
		  $sub_que['sub_question'][0]=0;
		  $sub_que['sub_question'][1]=1;
		  $this->view->allclaimquestiondata = $this->ModelObj->allclaimquestiondata($sub_que);
		  $this->view->claimquestion = $this->ModelObj->getclaimquestion();
		  if($this->_request->isPost()){
			if(!empty($this->Request['question']) && !empty($this->Request['question_type'])){
			  $question_id = $this->ModelObj->addnewclaimquestion();
			  $objSession->successMsg =  "New claim question added successfully";
			}
			else{
			  $objSession->successMsg = "Pease enter question and select question type!";
			}
		  }
	  }
	  catch (Exception $e) {
      $this->_logger->info('Class-'.__CLASS__.',Function-'.__FUNCTION__.',Line-'.__LINE__.',Error-'.$e->getMessage());
     }

    }
	
	/**
     * Get claim question option
     * Function : getoptionclaimquestionbyidAction()
	 * Date of creation 20/01/2017
   */
	public function getoptionclaimquestionbyidAction(){
	   $result = $this->ModelObj->getclaimqueoptionsbyid();
	   $results['Claimquebyid'] = $result;
	   echo json_encode($results); exit;
	}
	
	/**
     * 
     * Function : claimquebyidoptionAction()
	 * Date of creation 20/01/2017
   */
	public function claimquebyoptionidAction(){
	  $result1 = $this->ModelObj->getquestionbyidoption();
	  $result2 = $this->ModelObj->getclaimquestion();
	  $result3 = $this->ModelObj->getquestionbyidoptionother();
	  $results['claimque'] = $result1;
	  $results['claimallque'] = $result2;
	  $results['claimotherqsss'] = $result3;
	  echo json_encode($results); exit;
	}
	/**
	* Action for update 
	* Function : editclaimstatusAction()
	* Date of creation 16/01/2017
	**/
	public function editclaimstatusAction(){
	  global $objSession;
	  $this->_helper->layout->setLayout('popup');
	  $this->view->getstatus = $this->ModelObj->getclaimstatus();
	  $this->view->notificationlist = $this->notificationdropdownarray($category_id=1);
	  
	  if($this->_request->isPost() && $this->Request['editclaimstatus']=='Update Status'){
        if($this->Request['newnotification']!=''){
		  $notificationid = $this->ModelObj->addnewnotification($templatecategory_id=1);
		} 
		 if($this->ModelObj->updateclaimstatus($notificationid)){
		  $objSession->successMsg = "Claim Status has been Updated Successfully";
		  echo '<script type="text/javascript">parent.window.location.reload();
          parent.jQuery.fancybox.close();</script>';
          exit();
		  $this->_redirect($this->_request->getControllerName().'/claimstatus');
		 }
		 else{
	     $objSession->errorMsg = "There is some problem!";
		 $this->_redirect($this->_request->getControllerName().'/claimstatus');
	     }
	  }
	  
	}
	
	
	public function notificationdropdownarray($category_id){
	  $notification_list = array();
	  $notifications = $this->ModelObj->notificationlist();
	  foreach($notifications as $notifcation){
	    if($notifcation['templatecategory_id']==$category_id){
		  $notification_list[] = $notifcation;
		}
	  }
	  return $notification_list;
	}
	
	
	public function mailtemplateAction(){
	  $this->_helper->layout->setLayout('popup');
	  
	}
	
	/**
	* Action for update claim questions and operators
	* Function : updateclaimquestionAction()
	* Date of creation 13/01/2017
	**/
	public function updateclaimquestionAction(){
	  try{
	   global $objSession;
	   $this->_helper->layout->setLayout('popup');
	   $this->view->operatortype = $this->ModelObj->operatortype(); 
	   $this->view->updatedetails = $this->ModelObj->claimquebyquestionid($this->Request['question_id']);
	   if($this->_request->isPost() && $this->Request['updateque']=='Update Question'){
	     $this->ModelObj->updateclaimquestion();
		 $objSession->successMsg = "Record Updated Successfully";
		 echo '<script type="text/javascript">parent.window.location.reload();
         parent.jQuery.fancybox.close();</script>';
         exit();
		 $this->_redirect($this->_request->getControllerName().'/claimsetting');
	   }
	 }
	 catch (Exception $e) {
     $this->_logger->info('Class-'.__CLASS__.',Function-'.__FUNCTION__.',Line-'.__LINE__.',Error-'.$e->getMessage());
    }
	
	}
	
	/**
	* Action for adding new claim status
	* Function : addclaimstatusAction()
	* Date of creation 17/01/2017
	**/
	public function addclaimstatusAction(){
	 try{
	  global $objSession;
	  $this->_helper->layout->setLayout('popup');
	  if($this->_request->isPost() && $this->Request['editclaimstatus']=='Add new Status'){
	    if(!empty($this->Request['addnewclaimstatus'])){
		  $this->ModelObj->addclaimstatus();
		  $objSession->successMsg = "New claim status has been added Successfully";
		  echo '<script type="text/javascript">parent.window.location.reload();
          parent.jQuery.fancybox.close();</script>';
          exit();
		  $this->_redirect($this->_request->getControllerName().'/claimstatus');
		}
		else{
		   $objSession->errorMsg = "Please enter new status and then submit!";
		   echo '<script type="text/javascript">parent.window.location.reload();
           parent.jQuery.fancybox.close();</script>';
           exit();
		   $this->_redirect($this->_request->getControllerName().'/claimstatus');
		}
	  }
	 }
	 catch (Exception $e) {
     $this->_logger->info('Class-'.__CLASS__.',Function-'.__FUNCTION__.',Line-'.__LINE__.',Error-'.$e->getMessage());
    }
	
	}
	
	/**
	* Action for fetching mail template for claim
	* Function : emailtemplateAction()
	* @param notification_id
	* Date of creation 13/01/2017
	**/
	public function emailtemplateAction(){
	 $this->_helper->layout->setLayout('popup');
     $this->view->mailtemplate = $this->ModelObj->fetchtemailemplate();
	 $this->view->templatename = ($this->Request['notification_name']) ? $this->Request['notification_name'] : ''; 
   }
	
	
	
}
?>