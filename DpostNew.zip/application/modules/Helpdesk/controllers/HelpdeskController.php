<?php
ini_set('display_errors','1');
class Helpdesk_HelpdeskController extends Zend_Controller_Action
{
	public $Request = array();
    public $ModelObj = NULL;
     /**
	 * Auto load NameSpace and create objects 
	 * Function : init()
	 * Auto call and loads the default namespace and create object of model and form
	 **/ 
     public function init()
     { 
		try{
			$this->Request = $this->_request->getParams();
			$this->ModelObj = new Helpdesk_Model_HelpdeskManager();
			$this->ModelObj->getData  = $this->Request;
			$this->view->ModelObj = $this->ModelObj;
			$this->view->Request = $this->Request;
			$this->_helper->layout->setLayout('main');
	   }catch(Exception $e){
	    echo $e->getMessage();
	   }
     }
  
    /**
	* Action for listing ticket details
	* Function : ticketlistAction()
	* Date of creation 31/01/2017
	**/  
	public function ticketlistAction(){
	  $this->view->session_data = $this->ModelObj->Useconfig;
	  $this->view->heldeskdetails = $this->ModelObj->helpdeskinformation();
	  $this->view->countries = $this->ModelObj->getCountryList();
	  $this->view->helpdeskstatus = $this->ModelObj->getstatuslist(); 
	  $this->view->allcustomers = $this->ModelObj->getCustomerList();
	  $this->view->forwarders = $this->ModelObj->getForwarderList();
	  
	  
     }
     
	 
    public function helpdesksettingAction(){
	  $this->view->allquestion = $this->ModelObj->allquestionrecord();
    } 
	
	/**
	* Action for add new question
	* Function : addnewquestionAction()
	* Date of creation 06/01/2017
	**/
	public function addnewquestionAction(){
	  try{
		   global $objSession;
		   $this->view->languages = $this->ModelObj->systemlanguage();
		   $this->view->operatortype = $this->ModelObj->operatortype();
		   if($this->_request->isPost()){
			   if(count($this->Request['question'])>0 && !empty ($this->Request['operators'])){
				  $question_id=$this->ModelObj->addnewquestion();
				  $objSession->successMsg = "New question added successfully";
				  $this->_redirect($this->_request->getControllerName().'/setstep?question_id='.$question_id);
			   } 
			   else{
				   $objSession->errorMsg = "Please enter question and select Operator!";
			   }
		  }
	  }
	  catch (Exception $e) {
      $this->_logger->info('Class-'.__CLASS__.',Function-'.__FUNCTION__.',Line-'.__LINE__.',Error-'.$e->getMessage());
     }
	 
   } 
	
   /**
	* Action for update existing questions and operators
	* Function : updatequestionAction()
	* Date of creation 06/01/2017
	**/
   public function updatequestionAction(){
    try{
		 global $objSession;
		 $this->view->languages = $this->ModelObj->systemlanguage();
		 $this->view->operatortype = $this->ModelObj->operatortype(); 
		 $this->view->addedquestions = $this->ModelObj->addedquestiondata($this->Request);
		 if($this->_request->isPost()){
		   if(!empty($this->Request['operators']) && count($this->Request['question'])>0){
			  $this->ModelObj->updatequestions($this->Request);	
			  $objSession->successMsg = "Record Updated Successfully";
			  $this->_redirect($this->_request->getControllerName().'/helpdesksetting');  
		   }
		   else{
			  $objSession->errorMsg = "Please enter question and select Operator!";
		   }
		}
	 }
	  
	 catch (Exception $e) {
     $this->_logger->info('Class-'.__CLASS__.',Function-'.__FUNCTION__.',Line-'.__LINE__.',Error-'.$e->getMessage());
    }
	 
   }
	
   /**
	* Action for adding step
	* Function : setstepAction()
	* Date of creation 06/01/2017
	**/
   public function setstepAction(){
     $this->view->getdata = $this->Request;
	 $this->view->steplistdata = $this->ModelObj->steplist();
	 $this->view->steps = $this->ModelObj->showsteps();
   }	
	
   /**
	* Action for adding steps and getting new row 
	* Function : addstepsAction()
	* Date of creation 06/01/2017
	**/
   public function addstepsAction(){
	  echo $this->ModelObj->addstepandgetnewrow($this->Request); exit;
	}
	
	/**
	* Action for update steps/existing step 
	* Function : addstepsAction()
	* Date of creation 06/01/2017
	**/
	public function editstepsAction(){
	  echo $this->ModelObj->updatesteps($this->Request); exit;
	}
	
	/**
	* Action for fetching all helpdesk status 
	* Function : helpdeskstatusAction()
	* Date of creation 09/01/2017
	**/
	public function helpdeskstatusAction(){
      $this->view->helpdeskstatus = $this->ModelObj->allheldeskstatus(); 
   }
   
   /**
	* Action for adding new helpdesk status 
	* Function : addhelpdeskstatusAction()
	* Date of creation 18/01/2017
	**/
   public function addhelpdeskstatusAction(){
	 try{
	  global $objSession;
	  $this->_helper->layout->setLayout('popup');
	  if($this->_request->isPost() && $this->Request['addnewhelpdesk']=='Add New Helpdesk'){
	    if(!empty($this->Request['helpdeskname'])){
		  $this->ModelObj->addnewhelpdeskstatus();
		  $objSession->successMsg = "New helpdesk status has been added Successfully";
		  echo '<script type="text/javascript">parent.window.location.reload();
          parent.jQuery.fancybox.close();</script>';
          exit();
		  $this->_redirect($this->_request->getControllerName().'/helpdeskstatus');
		}
		else{
		   $objSession->errorMsg = "Please enter new status and then submit!";
		   echo '<script type="text/javascript">parent.window.location.reload();
           parent.jQuery.fancybox.close();</script>';
           exit();
		   $this->_redirect($this->_request->getControllerName().'/helpdeskstatus');
		}
	  }
	 }
	 catch (Exception $e) {
     $this->_logger->info('Class-'.__CLASS__.',Function-'.__FUNCTION__.',Line-'.__LINE__.',Error-'.$e->getMessage());
    }
   }
   
   /**
	* Action for fetching mail template
	* Function : heldeskstatusmailtemplateAction()
	* Date of creation 10/01/2017
	**/
   public function emailtemplateAction(){
     $this->_helper->layout->setLayout('popup'); 
	 $this->view->emailtemplate = $this->ModelObj->fetchemailtemplate(array('notification_id'=>$this->Request['notification_id'])); 
	 $this->view->templatename = ($this->Request['notification_name']!='') ? $this->Request['notification_name'] : '';
   }
   
   /**
	* Action for edit helpdesk status
	* Function : edithelpdeskstatusAction()
	* Date of creation 11/01/2017
	**/
   public function edithelpdeskstatusAction(){
     $this->_helper->layout->setLayout('popup');
	 $status_id = Zend_Encript_Encription:: decode($this->Request['status_id']);
	 $this->view->statuslist = $this->ModelObj->getstatuslist($status_id);
   }
  
   /**
	* Action for getiing FAQ's List
	* Function : faqdetailAction()
	* Date of creation 27/01/2017
	**/
   public function faqdetailAction(){
     $this->view->faqquestion = $this->ModelObj->faqdetails();
   
   }
   
   /**
	* Action for adding FAQ's Question
	* Function : addfaqAction()
	* Date of creation 27/01/2017
	**/
   public function addfaqAction(){
    try{
		global $objSession;
		 $this->view->opertortype = $this->ModelObj->operatortype();
		 if($this->_request->isPost()){
			 $this->ModelObj->addnewfaqquestion();
			 $objSession->successMsg = "New FAQ's question has been added Successfully";
		     $this->_redirect($this->_request->getControllerName().'/faqdetail');
		   }
	 }
	 catch (Exception $e) {
     $this->_logger->info('Class-'.__CLASS__.',Function-'.__FUNCTION__.',Line-'.__LINE__.',Error-'.$e->getMessage());
    }
   }
   
  /**
	* Action for updating FAQ's Question
	* Function : updatefaqAction()
	* Date of creation 28/01/2017
	**/
   public function updatefaqAction(){
    try{
	  global $objSession;
       $this->view->quedetails = $this->ModelObj->updatequedetails();
	   $this->view->opertortype = $this->ModelObj->operatortype();
	   if($this->_request->isPost()){
	    $this->ModelObj->updatefaqquestion();
	    $objSession->successMsg = "Updated Successfully";
		$this->_redirect($this->_request->getControllerName().'/faqdetail');
	   }
	 }
	 catch (Exception $e) {
     $this->_logger->info('Class-'.__CLASS__.',Function-'.__FUNCTION__.',Line-'.__LINE__.',Error-'.$e->getMessage());
    }
	
   }
   
   public function addticketAction(){
      $this->_helper->layout->setLayout('popup');
	   if($this->_request->isPost()){
	        global $objSession;
	        $this->ModelObj->addNewTicket();
			 $objSession->successMsg = "Ticket Added successfully!!";
			echo '<script type="text/javascript">parent.window.location.reload(); parent.jQuery.fancybox.close();</script>';exit;
	   }
	   $this->view->parcelinfo = $this->ModelObj->ParcelDetails();
	   $this->view->allquestion = $this->ModelObj->allquestionrecord();
   }
   public function checkticketAction(){
	  $this->view->allquestion = $this->ModelObj->checkAddedTicket();
   }
}
?>