<?php
class Helpdesk_Model_ClaimManager extends Zend_Custom
{
   
   public function getclaimstatus(){
	  $where = "1";
      if(isset($this->getData['status_id']) && $this->getData['status_id']!=''){
	    $where .= " AND ".CLAIM_STATUS_ID."='".$this->getData['status_id']."'";
	  }
	  $select= $this->_db->select()
			   ->from(array('CS'=>CLAIM_STATUS), array('*'))
			   ->joinleft(array('MN'=>MAIL_NOTIFY_TYPES), 'MN.notification_id = CS.notification_id', array('notification_name'))
			   ->where("CS.delete_status='0'")
			   ->where($where);
	  $result= $this->getAdapter()->fetchAll($select);
	  return $result;   
   }
   
   
   public function allclaimquestions(){
     if($this->Useconfig['level_id']=='6'){
		   $select = $this->_db->select()
					 ->from(array('CQ'=>CLAIM_QUESTIONS), array('*'));
		   $result = $this->getAdapter()->fetchAll($select);
		   $question_id = array();
		   foreach($result as $operators){
			 $totaloperators = commonfunction::explode_string($operators['operators']);
			 if(commonfunction::inArray($this->Useconfig['user_id'], $totaloperators)){
			   $question_id[] = $operators['question_id'];
			 }
		   }
		   if(!empty($question_id)){
			 $userdata = "CQ.question_id IN(".commonfunction::implod_array($question_id).")";
		   }else{
			 $userdata = '0';
		   }
	   }
	   else if($this->Useconfig['level_id']=='5'){
	     $userdata = '0';
	   }else{
	     $userdata = '1';
	   }
       $select = $this->_db->select()
	            ->from(array('CQ'=>CLAIM_QUESTIONS), array('*'))
				->where($userdata)
				->order('CQ.create_date DESC');//echo $select->__tostring(); die;
	   $result = $this->getAdapter()->fetchAll($select);
	   $finalresult = array();
	   foreach($result as $data){
	    $operator_list = array();
	    $operator = commonfunction::explode_string($data['operators']);
	    foreach($operator as $operators){
		   $operator_list[] = $this->getCustomerDetails($operators);
		 }
		 $finalresult[] = array('question_id'=>$data['question_id'],'operators'=>$operator_list, 'question'=>$data['question'], 'status'=>$data['status']);
	   }
 	   return $finalresult;
   }
   
   /**
     * getting claimquestion options
     * @param question_id;
	 * Date of creation 20/01/2017
   */
   public function getclaimqueoptionsbyid(){
     $where = "question_id='".$this->getData['question_id']."'";
	 $select = $this->_db->select()
	         ->from(array('CQ'=>CLAIM_QUESTIONS), array('*'))
			 ->where("CQ.question_options!=''")
			 ->where("CQ.status='1'")
			 ->where($where);
     $result = $this->getAdapter()->fetchAll($select);
	 return $result;
   }
   
   /**
     * getting question by id option
     * @param question_id,sub_question_option;
	 * Date of creation 20/01/2017
   */
   public function getquestionbyidoption(){
     $select = $this->_db->select()
	         ->from(array('CQ'=>CLAIM_QUESTIONS), array('*'))
			 ->where("CQ.sub_question='".$this->getData['question_id']."'")
			 ->where("CQ.sub_question_option='".$this->getData['sub_question_option']."'")
			 ->where("CQ.status='1'"); 
	$result = $this->getAdapter()->fetchAll($select);
    return $result;
   }
   
   /**
     * 
     * @param question_id,sub_question_option;
	 * Date of creation 20/01/2017
   */
   public function getquestionbyidoptionother(){
     $select = $this->_db->select()
	         ->from(array('CQ'=>CLAIM_QUESTIONS), array('*'))
			 ->where("CQ.sub_question='".$this->getData['question_id']."'")
			 ->where("CQ.sub_question_option!='".$this->getData['sub_question_option']."'")
			 ->where("CQ.status='1'"); 
	 $result = $this->getAdapter()->fetchAll($select);
     return $result;
   
   }
   
   public function allclaimquestiondata($sub_que){
     if(isset($sub_que['sub_question']) && $sub_que['sub_question'][0]=='0' && $sub_que['sub_question'][1]=='1'){
	   $where ="sub_question='".$sub_que['sub_question'][0]."' OR sub_question='".$sub_que['sub_question'][1]."' ";
	 }
	 else{
	   $where ='1';
	 }
     
	 $select = $this->_db->select()
	         ->from(array('CQ'=>CLAIM_QUESTIONS), array('*'))
			 ->where($where)
			 ->order("CQ.create_date DESC");
	$result = $this->getAdapter()->fetchAll($select);
    return $result; 
   }
   
   
   public function getclaimquestion(){
     $select = $this->_db->select()
	         ->from(array('CQ'=>CLAIM_QUESTIONS), array('*'))
			 ->where("CQ.status='1'");
	 $result = $this->getAdapter()->fetchAll($select);
     return $result; 
   }
   
   /**
     * Return detail of existing claim question
     * @param question_id;
	 * Date of creation 12/01/2017
   */
   public function claimquebyquestionid($data){
     echo $sub_que['sub_question']; 
     $select = $this->_db->select()
	         ->from(array(CLAIM_QUESTIONS), array('*'))
			 ->where("question_id='".$data."'"); //echo $select->__tostring(); die;
	 $result = $this->getAdapter()->fetchAll($select);
     return $result;
   }
   
   /**
     * Add new claim question
     * @param question_id;
	 * Date of creation 25/01/2017
   */
   public function addnewclaimquestion(){
	if(isset($this->getData['opertaors']) && !empty($this->getData['opertaors'])){
	 $operators = commonfunction::implod_array($this->getData['opertaors']);
	}
	else{
	  $operators = '';
 	}
	if($this->getData['question_type']=='file'){
	  $file_upload = 1;
	}else{
	  $file_upload = 0;
	}
	if($this->getData['question_type']=='select' || $this->getData['question_type']=='radio'){
	  foreach($this->getData['questionoption'] as $key=>$que_option){
		$que_value = $this->getData['questionvalue'][$key];
		$question_options .= $que_option.'|'.$que_value.';';
	  }
	}
	if(isset($this->getData['subquestion_a']) && $this->getData['subquestion_a']!=''){
	  $sub_question = $this->getData['subquestion_a'];
	  $sub_que_option = $this->getData['subquestion_option_a'];
	}else{
	  $sub_question = $this->getData['subquestion'];
	  $sub_que_option = $this->getData['subquestion_option'];
	}
	$lastinserted_id = $this->insertInToTable(CLAIM_QUESTIONS, array(array('sub_question'=>$sub_question,'sub_question_option'=>$sub_que_option,'question_type'=>$this->getData['question_type'],'question'=>$this->getData['question'],'question_options'=>$question_options,'operators'=>$operators,'file_upload'=>$file_upload,'status'=>$this->getData['claim_status'],'created_by'=>$this->Useconfig['user_id'],'created_ip'=>commonfunction::loggedinIP())));
	return $lastinserted_id;
   }
   
   /**
     * update detail of existing claim question
     * @param operators,claimquename,claim_status ;
	 * Date of creation 13/01/2017
   */
   public function updateclaimquestion(){
   try{
	 if(isset($this->getData['operators'])){
	  $opertaors = commonfunction::implod_array($this->getData['operators']);
	  $update = $this->UpdateInToTable(CLAIM_QUESTIONS, array(array('operators'=>$opertaors, 'question'=>$this->getData['claimquename'], 'status'=>$this->getData['claim_status'])), "question_id='".$this->getData['question_id']."'");
	 }
	 else{
	   $update = $this->UpdateInToTable(CLAIM_QUESTIONS, array(array('question'=>$this->getData['claimquename'], 'status'=>$this->getData['claim_status'])), "question_id='".$this->getData['question_id']."'");
	 }
	}
	catch (Exception $e) {
       $this->_logger->info('Class-'.__CLASS__.',Function-'.__FUNCTION__.',Line-'.__LINE__.',Error-'.$e->getMessage());
     } 
	 return $update;
   }
   
   /**
     * fetching email template for claim
     * @param notification_id ;
	 * Date of creation 13/01/2017
   */
   public function fetchtemailemplate(){
     $notification_id = Zend_Encript_Encription:: decode($this->getData['notification_id']);
     $select = $this->_db->select()
	         ->from(array(MAIL_MANAGER), array('*'))
			 ->where("notification_id='".$notification_id."'"); //echo $select->__tostring(); die;
	 $result = $this->getAdapter()->fetchAll($select);
	 return $result;
   }
  
  /**
     * fetching active notification list
	 * Function : notificationlist()
     * @param null;
	 * Date of creation 16/01/2017
  */
  public function notificationlist(){
  
     $select = $this->_db->select()
           ->from(array('MNT'=>MAIL_NOTIFY_TYPES), array('MNT.notification_id','MNT.notification_name','MNT.templatecategory_id'))
		   ->where("MNT.notification_staus='1'")
		   ->order("MNT.notification_name ASC"); //echo $select->__tostring(); die;
     $result = $this->getAdapter()->fetchAll($select);
	 return $result;
  }

  /**
     * Insert new notification
	 * Function : addnewnotification()
     * @param newnotification,templatecategory_id;
	 * Date of creation 16/01/2017
  */
  public function addnewnotification($data){
	$catId = (isset($data)) ? $data : 0;
    $last_id= $this->insertInToTable(MAIL_NOTIFY_TYPES,array(array('notification_name'=>$this->getData['newnotification'], 'notification_staus'=>'1','admin_display'=>'1', 'templatecategory_id'=>$catId)));
	return $last_id;
  }
  
  /**
     * Insert new claim status
	 * Function : addnewnotification()
     * @param addnewclaimstatus;
	 * Date of creation 16/01/2017
  */
  public function addclaimstatus(){
    $response = $this->insertInToTable(CLAIM_STATUS, array(array('claim_status_name'=>$this->getData['addnewclaimstatus'], 'create_date'=>'', 'created_by'=>$this->Useconfig['user_id'], 'created_ip'=>commonfunction::loggedinIP())));
    return $response;
  }
  
  /**
     * Update claim status 
	 * Function : updateclaimstatus()
	 * Date of creation 16/01/2017
  */
  public function updateclaimstatus($notificationid){
    $notification_id= (isset($notificationid)) ?  $notificationid : $this->getData['notificationid'];
    $response = $this->UpdateInToTable(CLAIM_STATUS, array(array('claim_status_name'=>$this->getData['claimstatusname'], 'notification_id'=>$notification_id, 'modify_by'=>$this->Useconfig['user_id'], 'modify_date'=>'', 'modify_ip'=>commonfunction::loggedinIP())), "".CLAIM_STATUS_ID."='".$this->getData['status_id']."'");
	return $response;
  }

}
?>