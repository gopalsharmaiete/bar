<?php
class Helpdesk_Model_HelpdeskManager extends Zend_Custom
{

   /**
	 * Fetching All Languages
	 * Function : systemlanguage()
	 * Date of creation 06/01/2017
   **/
	public function systemlanguage($data=array()){
		$select = $this->_db->select()
							->from(LANGUAGE,array('*'))
							->order(array('language_name ASC'));
		$result = $this->getAdapter()->fetchAll($select);
		return $result; 
	}

	
	public function addedquestiondata($data){
	  $select = $this->_db->select()
	           ->from(array('HQ'=>HELPDESK_QUESTION), array('*'))
			   ->joinInner(array('HQL'=>HELPDESK_QUESTION_LANGUAGE), "HQ.question_id= HQL.question_id", array('*'))
	   		   ->where("HQL.question_id=".$data['question_id']);
	  $result = $this->getAdapter()->fetchAll($select);
	  return $result;		   
	}
	
	    
	public function allquestionrecord(){
	  $select= $this->_db->select()
	           ->from(array('HQ'=>HELPDESK_QUESTION), array('*'))
			   ->joinInner(array('HQL'=>HELPDESK_QUESTION_LANGUAGE),'HQ.question_id=HQL.question_id', array('question_type'=>'question_type'))
			   ->where("HQL.language_id=3 AND HQ.delete_status='0'"); //echo $select->__tostring(); die;
	  $result= $this->getAdapter()->fetchAll($select); 
	  $finalresult = array();
      foreach($result as $listvalue){
	    $company_name = $this->getCompanyname($listvalue['operators']);
	    $steps=$this->allsteps($listvalue['question_id']);
		$finalresult[]=array('question_id'=>$listvalue['question_id'], 'question_type'=>$listvalue['question_type'], 'operators'=>$listvalue['operators'], 'steps'=>$steps, 'company_name'=>$company_name);
	  }
	  return $finalresult;
	}
	 
    
	public function getCompanyname($operators){
	  for($i=0; $i<count($operators); $i++){
		  $operator = commonfunction::explode_string($operators);
	   for($j=0; $j<count($operator); $j++){
		$single_operator = $operator[$j];
		$company_name[]=$this->getCustomerDetails($single_operator);
	   }	
	 } 
	 return $company_name;
	}
	
	
	public function allsteps($question_id){
	  $step= '';
	  if($this->Useconfig['level_id']=='5'){
	    $step = "AND step_auth='1'";
	  }
	  $questionid= (isset($question_id))? $question_id : '';
	  $select= $this->_db->select()
	           ->from(array(HELPDESK_QUESTION_DETAILS), array('*'))
			   ->where("question_id='".$questionid."'".$step);	   
	  $result= $this->getAdapter()->fetchAll($select);
	  return $result;
	}
	
	
	public function showsteps(){
	  $step= '';
	  if($this->Useconfig['level_id']=='5'){
	    $step = "AND step_auth='1'";
	  }
	  $select= $this->_db->select()
	           ->from(array(HELPDESK_QUESTION_DETAILS), array('*'))
			   ->where("question_id='".$this->getData['question_id']."'".$step);
	  $finalresult = array();
	  $result= $this->getAdapter()->fetchAll($select);
	  return $result;
	}
	
	
	public function getparentstep($question_id,$steps,$parent_step,$last=false){
	  if($last){
	    $where = "step<='".$steps."'";
	  }
	  else{
	    $where = "step<'".$steps."'";
	  }
	  $select = $this->_db->select()
	          ->from(array(HELPDESK_QUESTION_DETAILS), array('*'))
			  ->where("question_id=".$question_id)
			  ->where($where);
	  $results = $this->getAdapter()->fetchAll($select);
	  $string = '';
	  foreach($results as $step){
	   $selected = '';
	   if($step['step']==$parent_step){
	     $selected = 'selected="selected"';
	   }
	   $string .= '<option value="'.$step['step'].','.$step['steps'].'" '.$selected.'>'.$step['steps'].'</option>';
	  }
	   return $string;
    }
	
	
	public function addnewquestion(){
	  $operators = commonfunction::implod_array($this->getData['operators']);
	  $create_by = $this->Useconfig['user_id'];
	  $create_ip = commonfunction::loggedinIP();
	  $question_eng = $this->getData['question']['1'];
	  
	  $data=array('question_type'=>$question_eng, 'operators'=>$operators, 'create_date'=>'', 'create_by'=>$create_by, 'create_ip'=>$create_ip);
	  $this->insertInToTable(HELPDESK_QUESTION, array($data));
	  
	  $lastinserted_id =  $this->_db->lastInsertId();
	  
	  $question_type = $this->getData['question'];
	  foreach($question_type as $key=> $question){
	   $data= array('question_type'=>$question, 'question_id'=>$lastinserted_id, 'language_id'=>$key);
	   $this->insertInToTable(HELPDESK_QUESTION_LANGUAGE, array($data));
	  }
	  
	  return $lastinserted_id;
	}
    
	
	public function updatequestions($data){
	  try{
		  $operators= commonfunction::implod_array($data['operators']);
		  $this->UpdateInToTable(HELPDESK_QUESTION, array(array('operators'=>$operators)), "question_id=".$data['question_id']);
		  $question_type = $this->getData['question'];
		  foreach($question_type as $key=>$questions){
			$select = $this->_db->select()
					->from(array(HELPDESK_QUESTION_LANGUAGE), array('COUNT(1) as CNT'))
					->where("question_id='".$data['question_id']."' AND language_id='".$key."'");
			$result = $this->getAdapter()->fetchRow($select);
			if($result['CNT']>0){
			  $this->UpdateInToTable(HELPDESK_QUESTION_LANGUAGE, array(array('question_type'=>$questions)), "question_id='".$data['question_id']."' AND language_id='".$key."'");
			}
			else{
			  $this->insertInToTable(HELPDESK_QUESTION_LANGUAGE, array(array('question_type'=>$questions,'question_id'=>$data['question_id'],'language_id'=>$key)));
			}
		 } 
	  }
	  
	  catch (Exception $e) {
      $this->_logger->info('Class-'.__CLASS__.',Function-'.__FUNCTION__.',Line-'.__LINE__.',Error-'.$e->getMessage());
     }
	
	}

    public function steplist(){
	 $select = $this->_db->select()
	           ->from(array(HELPDESK_STEPS), array('*'));
	 $result= $this->getAdapter()->fetchAll($select);
	 return $result;
	}
    
	
	public function addstepandgetnewrow($data){
	   $steps = commonfunction::explode_string($data['step']);
	   $parent_step = commonfunction::explode_string($data['parent_step']);
	   $insert_data= array('question_id'=>$data['question_id'], 'step'=>$steps['0'], 'steps'=>$steps['1'], 'parent_step'=>$parent_step['0'], 'step_name'=>$data['step_name'], 'instruction'=>$data['instruction'], 'documents_uploade'=>$data['document_upload'], 'parent_status'=>$data['parent_status'], 'step_auth'=>$data['step_auth'], 'count'=>$data['count']-1);
	   $this->insertInToTable(HELPDESK_QUESTION_DETAILS, array($insert_data));
	  
	   $select = $this->_db->select()
		                  ->from(array(HELPDESK_QUESTION_DETAILS),array('parent_step','step_name','steps','parent_status'))
						  ->where("question_id=".$data['question_id'])
						  ->where("step<='".$data['count']."'");
						  //echo $select->__tostring(); die;
		$result =$this->getAdapter()->fetchAll($select);	
		foreach($result as $results){
		$parent_step .= '<option value="'.$data['step'].'">'.$results['steps'].'</option>';
		}
		$value = '';
		$value .= '<tr id="row'.($data['count']+1).'">';
		$value .= '<td><select id="step'.($data['count']+1).'" name="step'.($data['count']+1).'" class="inputfield">
						 <option value="0">--Select Step--</option>';
		 $steplist= $this->steplist();
		 foreach($steplist as $stepdata){
		 $value .= '<option value="'.$stepdata['value'].'">'.$stepdata['steplist'].'</option>';
		 }		 
		$value .= '</select></td>';
		$value .= '<td><input type="text" class="inputfield" name="steps_name'.($data['count']+1).'" id="steps_name'.($data['count']+1).'"></td>';
		$value .= '<td><textarea cols="20" rows="3" name="instruction'.($data['count']+1).'" id="instruction'.($data['count']+1).'"></textarea></td>';
		$value .= '<td><input type="checkbox" name="document_upload'.($data['count']+1).'">Documents Required</td>';
		$value .= '<td><select name="parent_step'.($data['count']+1).'" class="inputfield" id="parent_step'.($data['count']+1).'">';
		$value .= $parent_step;
		$value .= '</select>';
		$value .= '<input type="radio" name="status'.($data['count']+1).'" id="status'.($data['count']+1).'"  value="1"/>Yes';
		$value .= '<input type="radio" name="status'.($data['count']+1).'" id="status'.($data['count']+1).'" value="0" />No';
		$value .= '</td>';
		$value .= '<td><input type="radio" name="step_auth'.($data['count']+1).'" id="step_auth'.($data['count']+1).'" value="1">Customer';
		$value .= '<input type="radio" name="step_auth'.($data['count']+1).'" id="step_auth'.($data['count']+1).'" value="0">Operator</td>';
		$value .= '<td><i class="fa fa-plus-square" onclick="add_more('.($data['count']+1).')"></i></td>';
		
		return $value;
	}
    
	public function updatesteps($data){
	  $steps = commonfunction::explode_string($data['step']);
	  $parent_step = commonfunction::explode_string($data['parent_step']);
	  $update_data = array('step'=>$steps['0'], 'steps'=>$steps['1'], 'parent_step'=>$parent_step['0'], 'step_name'=>$data['step_name'], 'instruction'=>$data['instruction'], 'documents_uploade'=>$data['document_upload'], 'parent_status'=>$data['parent_status'], 'step_auth'=>$data['step_auth']);
	  $this->UpdateInToTable(HELPDESK_QUESTION_DETAILS, array($update_data), "question_id='".$data['question_id']."' AND count='".$data['count']."'");
	}
	
	
	public function allheldeskstatus(){
	  $select = $this->_db->select()
	           ->from(array('HS'=>HELPDESK_STATUS), array('*'))
			   ->joinleft(array('MNT'=>MAIL_NOTIFY_TYPES), "HS.".NOTIFICATION_ID." = MNT.".NOTIFICATION_ID."", array('notification_name'))
				->where("HS.delete_status='0'"); 
	  $result= $this->getAdapter()->fetchAll($select);
	  return $result;
	}
	
    /**
     * Insert new heldesk status
	 * Function : addnewnotification()
     * @param helpdeskname;
	 * Date of creation 18/01/2017
  */
    public function addnewhelpdeskstatus(){
	  $response = $this->insertInToTable(HELPDESK_STATUS, array(array('helpdesk_status_name'=>$this->getData['helpdeskname'], 'create_date'=>'', 'created_by'=>$this->Useconfig['user_id'], 'created_ip'=>commonfunction::loggedinIP())));
    return $response;
	}
	
   /**
	 * Fetching email template on behalf of notifcaion id
	 * Function : fetchemailtemplate()
	 * Date of creation 11/01/2017
    **/
	public function fetchemailtemplate($data=array()){
	  $select = $this->_db->select()
	          ->from(array(MAIL_MANAGER), array('*'))
			  ->where("".NOTIFICATION_ID."='".$data[NOTIFICATION_ID]."'");
	  $result = $this->getAdapter()->fetchAll($select);
	  return $result;
	}
	
	/**
	 * Getting helpdesk information
	 * Function : helpdeskinformation()
	 * Date of creation 31/01/2017
    **/
	public function helpdeskinformation(){
	  /*$filter_data = '';
	  if(isset($this->getData['ticket_barcode']) && !empty($this->getData['ticket_barcode'])){
	    $filter_data .= " AND (HT.ticket_no='".$this->getData['ticket_barcode']."' || SBC.barcode='".$this->getData['ticket_barcode']."')";
	  }
	  if(isset($this->getData['search_status']) && !empty($this->getData['search_status'])){
	    $filter_data .= " AND HT.is_status='".Zend_Encript_Encription:: decode($this->getData['search_status'])."'";
	  }
	  if(isset($this->getData['forwarders']) && !empty($this->getData['forwarders'])){
	    $filter_data .= " AND SBC.forwarder_id='".Zend_Encript_Encription:: decode($this->getData['forwarders'])."'";
	  }
	  if(isset($this->getData['country_id']) && !empty($this->getData['country_id'])){
	    $filter_data .= " AND ST.country_id='".Zend_Encript_Encription:: decode($this->getData['country_id'])."'";
	  }
	  if(isset($this->getData['customers']) && !empty($this->getData['customers'])){
	    $filter_data .= " AND ST.country_id='".Zend_Encript_Encription:: decode($this->getData['customers'])."'";
	  }
	  
	  $userdata = $this->LevelClause();
	  
	  $select = $this->_db->select()
	          ->from(array('HT'=>HELPDESK_TICKET), array('COUNT(1) AS CNT'))
			  ->joinInner(array('HQS'=>HELPDESK_QUESTION), 'HT.question_id=HQS.question_id', array(''))
			  ->joinInner(array('AT'=>USERS_DETAILS), 'HT.user_id=AT.user_id', array(''))
			  ->joinleft(array('UDS'=>USERS_DETAILS), 'HT.forward_to=UDS.user_id', array(''))
			  ->joinInner(array('SBC'=>SHIPMENT_BARCODE), 'HT.barcode_id=SBC.barcode_id', array(''))
			  ->joinInner(array('ST'=>SHIPMENT), 'ST.shipment_id=SBC.shipment_id', array(''))
			  ->joinInner(array('HS'=>HELPDESK_STATUS), 'HT.is_status=HS.helpdesk_status_id', array(''))
			  ->where("HT.delete_status='0'")
			  ->where($filter_data.$userdata);
	  $total = $this->getAdapter()->fetchAll();*/
	  
	  $select = $this->_db->select()
	          ->from(array('HT'=>HELPDESK_TICKET), array('*'))
			  ->joinInner(array('HTD'=>HELPDESK_TICKET_DETAIL), 'HT.helpdesk_token=HTD.helpdesk_token', array('messages'))
			  ->joinInner(array('HQS'=>HELPDESK_QUESTION), 'HT.question_id=HQS.question_id', array('question_id','question_type'))
			  ->joinInner(array('AT'=>USERS_DETAILS), 'HT.user_id=AT.user_id', array('user_id','company_name','customer_name'))
			  ->joinInner(array('US'=>USERS_SETTINGS), 'US.user_id=AT.user_id', array('logo'))
			  ->where("HT.delete_status='0'")
			  ->group('HT.ticket_no')
			  ->limit('20'); //echo $select->__toString(); die;
	  $result = $this->getAdapter()->fetchAll($select);
	  return $result;
	}
	
	/**
	 * Fetching email template on behalf of notifcaion id
	 * Function : fetchemailtemplate()
	 * Date of creation 11/01/2017
    **/
	public function getstatuslist($status_id = false){
	  $where = '';
	  if(isset($status_id) && $status_id!=''){
	    $where = " AND HS.helpdesk_status_id='".$status_id."'"; 
	  }
	  $select = $this->_db->select()
	          ->from(array('HS'=>HELPDESK_STATUS), array('*'))
			  ->joinleft(array('MNT'=>MAIL_NOTIFY_TYPES), "HS.".NOTIFICATION_ID." = MNT.".NOTIFICATION_ID."", array('notification_name'))
			  ->where("HS.status='1' AND delete_status='0'".$where); //echo $select->__tostring(); die;
	  $result = $this->getAdapter()->fetchAll($select);
	  return $result; 
	}
	
    /**
	 * Fetching list of FAQ's
	 * Function : faqdetails()
	 * Date of creation 27/01/2017
    **/

    public function faqdetails(){
	  $select = $this->_db->select()
	          ->from(array(HELPDESK_FAQ_DETAILS), array('*'))
			  ->where("delete_status='0'");
	  $result = $this->getAdapter()->fetchAll($select);
	  return $result;
	}
	
	 /**
	 * Adding new FAQ's question and helpdesk question
	 * Function : faqdetails()
	 * Date of creation 27/01/2017
    **/
	public function addnewfaqquestion(){
	  $operators= commonfunction::implod_array($this->getData['operatortype']);
	  $response = $this->insertInToTable(HELPDESK_FAQ_DETAILS, array(array('operators'=>$operators, 'question'=>$this->getData['question'], 'answer'=>$this->getData['answer'], 'question_type'=>$this->getData['que_type'], 'create_date'=>'', 'created_by'=>$this->Useconfig['user_id'], 'created_ip'=>commonfunction::loggedinIP())));
	  return $response;
	}
    
	/**
	 * Fetching data of existing FAQ's question by question id
	 * Function : updatequedetails()
	 * @param que_id;
	 * Date of creation 28/01/2017
    **/
	public function updatequedetails(){
	 $faq_que_id = Zend_Encript_Encription:: decode($this->getData['que_id']);
	 $select = $this->_db->select()
	         ->from(array(HELPDESK_FAQ_DETAILS), array('*'))
			 ->where("".faq_id."='".$faq_que_id."'"); //echo $select->__tostring(); die;
	 $result = $this->getAdapter()->fetchAll($select);
	 return $result;
	}
	
	/**
	 * Update FAQ's and Helpdesk question, answer
	 * Function : updatefaqquestion()
	 * Date of creation 28/01/2017
    **/
	public function updatefaqquestion(){
	 $opertaors= commonfunction::implod_array($this->getData['operators']);
	 $response = $this->UpdateInToTable(HELPDESK_FAQ_DETAILS, array(array('operators'=>$opertaors,'question'=>$this->getData['question'], 'answer'=>$this->getData['answer'], 'modify_date'=>'', 'modify_by'=>$this->Useconfig['user_id'], 'modify_ip'=>commonfunction::loggedinIP())), "faq_id=".Zend_Encript_Encription:: decode($this->getData['que_id']));
	 return $response;
	}
	
	public function checkAddedTicket(){
	     $select = $this->_db->select()
								  ->from(array('HT'=>HELPDESK_TICKET), array('COUNT(1) AS CNT'))
								  /*->joinInner(array('HTD'=>HELPDESK_TICKET_DETAIL), 'HT.helpdesk_token=HTD.helpdesk_token', array('messages'))
								  ->joinInner(array('HQS'=>HELPDESK_QUESTION), 'HT.question_id=HQS.question_id', array('question_id','question_type'))
								  ->joinInner(array('AT'=>USERS_DETAILS), 'HT.user_id=AT.user_id', array('user_id','company_name','customer_name'))
								  ->joinInner(array('US'=>USERS_SETTINGS), 'US.user_id=AT.user_id', array('logo'))*/
								  ->where("HT.barcode_id='".$this->getData['barcode_id']."' AND HT.question_id='".$this->getData['question_id']."'"); 
								  //echo $select->__toString(); die;
	  $result = $this->getAdapter()->fetchRow($select);
	  if($result['CNT']==0){
	      echo '0';die;
	  }else{
	     echo '<td colspan="2">Ticket already added for this question: <a href="'.BASE_URL.'/Helpdesk/reply">Go to Reply</a></td>';die;
	  }
	}
	
	public function ParcelDetails(){
	   $select = $this->_db->select()
									->from(array('BT' =>SHIPMENT_BARCODE),array('*'))
									->joininner(array('BD'=>SHIPMENT_BARCODE_DETAIL),"BD.barcode_id=BT.barcode_id",array('rec_reference','checkin_date'))
									->joininner(array('BL'=>SHIPMENT),"BL.shipment_id=BT.shipment_id",array('country_id','user_id','rec_name','addservice_id','create_date','senderaddress_id','goods_id','create_by','rec_zipcode'))
									->joininner(array('AT' =>USERS_DETAILS),"AT.user_id=BL.user_id",array("AT.company_name"))
									->joininner(array('CT' =>COUNTRIES),"CT.country_id=BL.country_id",array("CT.country_name"))
									->joininner(array('FT' =>FORWARDERS),"FT.forwarder_id=BT.forwarder_id",array("FT.forwarder_name"))
									->joininner(array('ST' =>SERVICES),"ST.service_id=BT.service_id",array("ST.service_name"))
									->where("BT.barcode_id='".$this->getData['barcode_id']."'"); //print_r($select->__toString());die;
		return  $this->getAdapter()->fetchRow($select);
	}
	
	public function addNewTicket(){
	   if($this->getData['question_id']>0){
	    try{
		 $this->_db->insert(HELPDESK_TICKET,array(
		 													  'ticket_no'=>$this->ticketnumber(),
															  'user_id'=>$this->getData['user_id'],
															  'barcode_id'=>$this->getData['barcode_id'],
															  'question_id'=>$this->getData['question_id'],
															  'current_step'=>0,
															  'current_activity'=>1,
															  'is_status' =>1,
															  'create_date' => new Zend_Db_Expr('NOW()') 
																));
			$tocken_id = $this->getAdapter()->lastInsertId();
			$this->_db->insert(HELPDESK_TICKET_DETAIL, array('helpdesk_token'=>$tocken_id,
															 'activity_id'=>1,
															 'messages'=>$this->getData['question'],
															 'activity_date'=>new Zend_Db_Expr('NOW()'),
															 'activity_by'=>$this->Useconfig['user_id'],
															 'activity_ip'=>commonfunction::loggedinIP()));	
		}catch(Exception $e){ $this->_logger->info('Class-'.__CLASS__.',Function-'.__FUNCTION__.',Line-'.__LINE__.',Error-'.$e->getMessage());}												
	   }
	}
	
	public function ticketnumber(){
        $length= 10;
        $random = "";
		srand((double)microtime()*1000000000);
		$data = "1234567890";
		for($i= 0; $i < $length; $i++) {
			 $random .= substr($data, (rand()%(strlen($data))), 1); 
		 }
       return $random +1;
  }

}
?>