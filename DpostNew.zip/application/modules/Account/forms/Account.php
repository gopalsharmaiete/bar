<?php

class Account_Form_Account extends Application_Form_CommonDecorator
{
	public $listCountry = '';
	public $AdminLevelId = '';
	public $LevelId = '';
	public $privilege = '';
	public $btwCharge = '';
	public $invoiceSeries = '';
	
	public $listDepot = '';
	public $languageList = '';
	public $CurrencyList = '';
	public $customerlist = '';
	public $listHubuser = '';
	public $mode = '';
	public $parentId = '';
	public $drivername = '';
	//public $InvoiceSeries = ''
	 
	//public $decoratorObj = '';
    
	public function init() 
    {
		//$this->decoratorObj = new Application_Form_CommonDecorator();
    }
	
	
	public function setLevelId(){
		$levelId = $this->CreateElement('hidden', 'level_id')
					->setValue($this->LevelId);
		$levelId->removeDecorator('label');
		$levelId->removeDecorator('HtmlTag');
		
		return $levelId;
	}
	
	public function setdepotList(){
		$DepotList = new Zend_Form_Element_Select('parent_id');
        $DepotList->setLabel('Select Depot')
				  ->addMultiOptions(array('' => '--Select Depot--'))
				  ->addMultiOptions($this->listDepot)	
				  ->setAttrib('title', 'Please Select Depot')
				  ->setAttrib('class', 'inputfield')
				  ->setRequired(true)
				  ->addValidator('NotEmpty')
				  ->setDecorators($this->decorator);
		
		return $DepotList;		  
	}
	
	public function showcountryList(){
		$CountyList = new Zend_Form_Element_Select('country_id');
        $CountyList->setLabel('Country')
				  ->addMultiOptions(array('' => '--Select Country--'))
				  ->addMultiOptions($this->listCountry)	
				  ->setAttrib('title', 'Please Select Country')
				  ->setAttrib('class', 'inputfield')
				  ->setRequired(true)
				  ->addValidator('NotEmpty')
				  ->setDecorators($this->decorator);
				  
		return $CountyList;
	}
	
	public function showcurrencyList(){
		$CurrencyList = new Zend_Form_Element_Select('currency');
        $CurrencyList->setLabel('Currency')
					 ->addMultiOptions(array('' => '--Select Currency--'))
					 ->addMultiOptions($this->CurrencyList)	
					 ->setAttrib('title', 'Please Select Currency')
					 ->setAttrib('class', 'inputfield')
					 ->setDecorators($this->decorator);
		
		return $CurrencyList;
	}
	
	public function showlanguageList(){
	
		$Language = new Zend_Form_Element_Select('language_id');
        $Language->setLabel('Language')
				  ->addMultiOptions(array('' => '--Select Language--'))
				  ->addMultiOptions($this->languageList)	
				  ->setAttrib('title', 'Please Select Language')
				  ->setAttrib('class', 'inputfield')
				  ->setRequired(true)
				  ->addValidator('NotEmpty')
				  ->setDecorators($this->decorator);
				  
		return $Language;	
	}
	
	public function showcustomerList(){
		$CustomerList = new Zend_Form_Element_Select('parent_id');
        $CustomerList->setLabel('Customer')
				  ->addMultiOptions(array('' => '--Select Customer--'))
				 // ->addMultiOptions($this->customerlist)	
				  ->setAttrib('title', 'Please Select Depot')
				  ->setAttrib('class', 'inputfield')
				  ->setRequired(true)
				  ->addValidator('NotEmpty')
				  ->setDecorators($this->decorator);
		
		return $CustomerList;	
	}
	
	public function fieldusername(){
		$Username = new Zend_Form_Element_Text('username');
        $Username->setLabel('Username')
				  ->addFilter('StringTrim')	
				  ->setAttrib('title', 'Please Fill Username')
				  ->setAttrib('class', 'inputfield')
                  ->setRequired(true)
                  ->addValidator('NotEmpty')
				  ->setAttrib('onchange',"userExist()")
				  ->setDecorators($this->decorator);		  
		
		return $Username;		 
	}
	
	public function fieldpassword(){
		$Password = new Zend_Form_Element_text('password');
        $Password->setLabel('Password')
				  ->addFilter('StringTrim')	
				  ->setAttrib('title', 'Please Fill Password')
				  ->setAttrib('class', 'inputfield')
                  ->setRequired(true)
                  ->addValidator('NotEmpty')
				  ->setDecorators($this->decorator);		  
		
		return $Password;	
	}
	
	public function fieldrepassword(){
		$Confirm = new Zend_Form_Element_text('retypepass');
        $Confirm->setLabel('Confirm Password')
				  ->addFilter('StringTrim')
				  ->setAttrib('title', 'Confirm Password')
				  ->setAttrib('class', 'inputfield')
                  ->setRequired(true)
                  ->addValidator('NotEmpty')
				  ->setAttrib('onchange',"confirmpassword()")
				  ->setDecorators($this->decorator);	
				  
		return $Confirm;		  
	}
	
	public function fieldfirstname(){
		$Firstname = new Zend_Form_Element_Text('first_name');
        $Firstname->setLabel('First Name')
				  ->addFilter('StringTrim')	
				  ->setAttrib('title', 'Please Fill firstname')
				  ->setAttrib('class', 'inputfield')
                  ->setRequired(true)
                  ->addValidator('NotEmpty')
				  ->setDecorators($this->decorator);
		
		return $Firstname;
	}
	
	public function fieldmiddlename(){
		$MiddleName = new Zend_Form_Element_Text('middle_name');
        $MiddleName->setLabel('Middle Name')
				  ->addFilter('StringTrim')
				  ->setAttrib('class', 'inputfield')
				   ->setDecorators($this->decorator);
		
		return $MiddleName;		
	}
	
	public function fieldlastname(){
		$Lastname = new Zend_Form_Element_Text('last_name');
        $Lastname->setLabel('Last Name')
				  ->addFilter('StringTrim')	
				  ->setAttrib('title', 'Please Fill LastName')
				  ->setAttrib('class', 'inputfield')
                  ->setRequired(true)
                  ->addValidator('NotEmpty')
				  ->setDecorators($this->decorator);		  		  		  	  
		
		return $Lastname;		 
	}
	
	public function fieldemail(){
		$Email = new Zend_Form_Element_Text('email');
        $Email->setLabel('Email Address')
				  ->addFilter('StringTrim')	
				  ->setAttrib('title', 'Please Fill Email')
				  ->setAttrib('class', 'inputfield')
                  ->setRequired(true)
                  ->addValidator('NotEmpty')
				  ->addValidator('EmailAddress')
				  ->setAttrib('onblur',"emailvalidation()")
				  ->setDecorators($this->decorator);
				
		return $Email;		
	}
	
	public function fieldinvoicemail(){
		$InvoiceEmail = new Zend_Form_Element_Text('invoice_email');
        $InvoiceEmail->setLabel('Invoice Email')
				  ->addFilter('StringTrim')	
				  ->setAttrib('title', 'Please Fill Invoice Email')
				  ->setAttrib('class', 'inputfield')
                  ->setRequired(true)
                  ->addValidator('NotEmpty')
				  ->addValidator('EmailAddress')
				  ->setAttrib('onblur',"emailinvoicevalidation()")
				  ->setDecorators($this->decorator);			   	
		
		return $InvoiceEmail;
	}
	
	public function fieldcompanyname(){
		$Company = new Zend_Form_Element_Text('company_name');
        $Company->setLabel('Company')
				  ->addFilter('StringTrim')	
				  ->setAttrib('title', 'Please Fill Company Name')
				  ->setAttrib('class', 'inputfield')
                  ->setRequired(true)
                  ->addValidator('NotEmpty')
				  ->setDecorators($this->decorator);
		
		return $Company;
	}
	
	public function fieldvatnumber(){
		$Vat = new Zend_Form_Element_Text('vat_no');
        $Vat->setLabel('Vat Number')
				  ->addFilter('StringTrim')	
				  ->setAttrib('title', 'Please Fill Vat Number')
				  ->setAttrib('class', 'inputfield')
                  ->setRequired(true)
                  ->addValidator('NotEmpty')
				  ->addValidator('Digits')
				  ->setDecorators($this->decorator);
		
		return $Vat;
	}
	
	public function fieldbtwnumber(){
		$BTW = new Zend_Form_Element_Text('btw_number');
        $BTW->setLabel('BTW')
				  ->addFilter('StringTrim')	
				  ->setAttrib('title', 'Please Fill BTW')
				  ->setAttrib('class', 'inputfield')
          		  ->setDecorators($this->decorator);
				  
		return $BTW;
	}
	
	public function fieldbtwcharge(){
		$chargeBtw = new Zend_Form_Element_Radio('btw_status');
    	$chargeBtw->setLabel('Btw Charge')
					->addMultiOptions(array(
        				'1' => 'BTW Charge',
        				'0' => "Don't Charge BTW"
      				  ))
					->setSeparator(' ')
					->setDecorators($this->decorator);  	  
			
		return $chargeBtw;
	}
	
	public function fieldshowprice(){
		$showprice = new Zend_Form_Element_Radio('show_price');
    	$showprice->setLabel('Show Price')
					->addMultiOptions(array(
        				'1' => 'On',
        				'0' => 'Off'
      				  ))
					->setSeparator(' ')  
					->setDecorators($this->decorator);  	  
		
		return $showprice;
	}
	
	public function fieldphone(){
		$PhoneNumber = new Zend_Form_Element_Text('phoneno');
        $PhoneNumber->setLabel('Phone Number')
				  ->addFilter('StringTrim')	
				  ->setAttrib('title', 'Please Fill Phone Number')
				  ->setAttrib('class', 'inputfield')
                  ->setRequired(true)
                  ->addValidator('NotEmpty')
				  ->setDecorators($this->decorator);
		
		return $PhoneNumber;	
	}
	
	public function fieldaddress1(){
		$AddressOne = new Zend_Form_Element_Text('address1');
        $AddressOne->setLabel("Address1")
				  ->addFilter('StringTrim')	
				  ->setAttrib('title', 'Please Fill Address')
				  ->setAttrib('class', 'inputfield')
                  ->setRequired(true)
                  ->addValidator('NotEmpty')
				  ->setDecorators($this->decorator);
		
		return $AddressOne;		  
	}
	
	public function fieldaddress2(){
		$AddressTwo = new Zend_Form_Element_Text('address2');
        $AddressTwo->setLabel('Address2')
				  ->setAttrib('title', 'Please Fill Address 2')
				  ->setAttrib('class', 'inputfield')
                  ->setDecorators($this->decorator);		  			  		  		  
		
		return $AddressTwo;	
	}
	
	public function fieldpincode(){
		$ZipCode = new Zend_Form_Element_Text('postalcode');
        $ZipCode->setLabel('Zip Code')
				  ->addFilter('StringTrim')	
				  ->setAttrib('title', 'Please Fill zipcode')
				  ->setAttrib('class', 'inputfield')
                  ->setRequired(true)
                  ->addValidator('NotEmpty')
				  ->setDecorators($this->decorator);
		
		return $ZipCode;	
	}
	
	public function fieldcity(){
		$City = new Zend_Form_Element_Text('city');
        $City->setLabel('City')
				  ->addFilter('StringTrim')	
				  ->setAttrib('title', 'Please Fill city')
				  ->setAttrib('class', 'inputfield')
                  ->setRequired(true)
                  ->addValidator('NotEmpty')
				  ->setDecorators($this->decorator);		  
		
		return $City;
	}
	
	public function fieldadminlogo(){
		$adminLogo = new Zend_Form_Element_File('logo');
        $adminLogo->setLabel('Admin Logo<br>(Dimension 210 X 62)</br>')
				  ->addFilter('StringTrim')
				  ->setAttrib('title','Please Select Admin Logo')
				  ->setRequired(true)
                  ->addValidator('NotEmpty')
				  ->setDecorators($this->filedecorator);
		
		return $adminLogo;
	}
	
	public function fieldheadercolor(){
		$headerColor = new Zend_Form_Element_Text('header_color');
		$headerColor->setRequired(true)
					->setDescription('required')
					->setLabel('Header Background Color')
					->setAttrib('title', 'Please Fill Header Color')
					->setAttrib('class', 'inputfield look izzyColor')
					->setAttrib('style', 'width:220px')
					->setDecorators($this->decorator);
		
		return $headerColor;
	}
	
	public function fieldtextcolor(){
		$TextColor = new Zend_Form_Element_Text('font_color');
		$TextColor->setRequired(true)
					->setDescription('required')
					->setLabel('Header Text Color')
					->setAttrib('title', 'Please Fill Header Text Color')
					->setAttrib('class', 'inputfield look izzyColor')
					->setAttrib('style', 'width:220px')
					->setDecorators($this->decorator);
				
		return $TextColor;		
	}
	
	public function fieldinvoicelogo(){
		$InvoiceLogo = new Zend_Form_Element_File('invoice_logo');
		$InvoiceLogo->setLabel('Invoice Logo<br>(Dimension 210 X 62)</br>')
					->setRequired(true)
					->addFilter('StringTrim')
					->setAttrib('title', 'Please Select Invoice Logo')
					->setAttrib('style', 'width:100%')
					->setDecorators($this->filedecorator);
		
		return $InvoiceLogo;
	}
	
	public function fieldlabeloption(){
		$labelOption = new Zend_Form_Element_Select('label_position');
        $labelOption->setLabel('Label Options')
				  ->addMultiOptions(array('' => '--Select--'))
				  ->addMultiOptions(array('a1'=>'A4 - 1Position',
				  						  'a4'=>'A4 - 4Position',
										  'a6'=>'A6 - Position'))	
				  ->setAttrib('title', 'Please Select Label Position')
				  ->setAttrib('class', 'inputfield')
				  ->setDecorators($this->decorator);
		
		return $labelOption;
	}
	
	public function fieldsubmit(){
		$submit = new Zend_Form_Element_Submit('submit');
        $submit->setLabel('Submit')
				->setAttrib('class', 'btn btn-danger btn-round')
				->setAttrib('style', 'margin-left:auto;margin-right:auto;display:block;');
				
		return $submit;		
	}
	
	public function fieldmode(){
		$Mode = $this->CreateElement('hidden', 'modevalue')
					->setValue($this->mode);
		$Mode->removeDecorator('label');
		$Mode->removeDecorator('HtmlTag');
		
		return $Mode;
	}
	
// end all form's common function...


	public function DepotForm(){
		
        $this->setMethod('post');
   		$this->setName('addeditdepot');
 	 	$this->setAttrib('class', 'inputbox');
		
		$Mode = $this->fieldmode();
		
		$levelId = $this->setLevelId();
		
		$parent_id = $this->CreateElement('hidden', 'parent_id')
					->setValue($this->parentId);
		$parent_id->removeDecorator('label');
		$parent_id->removeDecorator('HtmlTag');
		
		$type = new Zend_Form_Element_Text('administrator');
		$type->setLabel("Administrator's type")
				->setValue('Depot')
				->setAttrib('disable', 'disable')
				->setAttrib('style', 'font-weight:bold')
				->setDecorators($this->decorator);
								
		$CountyList = $this->showcountryList();
				  
		$CurrencyList = $this->showcurrencyList();
					 		  
		$Username = $this->fieldusername();	  
				  
		$Password = $this->fieldpassword();
		
		$Confirm = $this->fieldrepassword();	
				  
		$Firstname = $this->fieldfirstname();
		
		$MiddleName = $this->fieldmiddlename();
				  
		$Lastname = $this->fieldlastname();		  		  		  	  
				  
		$Email = $this->fieldemail();
				   
		$InvoiceEmail = $this->fieldinvoicemail();		   	
		
		$Company = $this->fieldcompanyname();
		
		$Vat = $this->fieldvatnumber();
				  
		$BTW = $this->fieldbtwnumber();
				  
		$chargeBtw = $this->fieldbtwcharge();
		
		$showprice = $this->fieldshowprice();
		
		$PhoneNumber = $this->fieldphone();
				  
		$AddressOne = $this->fieldaddress1();
		
		$AddressTwo = $this->fieldaddress2();
		
		$ZipCode = $this->fieldpincode();
				  
		$City = $this->fieldcity();		  
		
		$adminLogo = $this->fieldadminlogo();
		
		$headerColor = $this->fieldheadercolor();
		
		$TextColor = $this->fieldtextcolor();
		
		$InvoiceLogo = $this->fieldinvoicelogo();
		
		$labelOption = $this->fieldlabeloption();
		
		$Invoice = new Zend_Form_Element_Text('invoice');
		$Invoice->setLabel("Invoice Series")
				->setValue(date('Y').$this->invoiceSeries.'XXXXXX')
				->setAttrib('disable', 'disable')
				->setAttrib('style', 'font-weight:bold')
				->setDecorators($this->decorator);
				
		
		$InvoiceSeries = $this->CreateElement('hidden', 'invoice_series')
					  ->setValue(date('Y').$this->invoiceSeries.'XXXXXX');
		$InvoiceSeries->removeDecorator('label');
		$InvoiceSeries->removeDecorator('HtmlTag');				 
			
		
		/*$privilege = new Zc_Form_Element_Privilege('priv');
		$privilege->setLabel('Set privilege :')
				   ->setvalue($this->privilege)
				   ->setDecorators($this->defineDecorator(''));*/
		//$this->clear4fix;
				   									    		  		   		   		  
		$submit = $this->fieldsubmit();
		if($this->mode=='edit'){
			$Invoice = new Zend_Form_Element_Text('invoice_series');
			$Invoice->setLabel("Invoice Series")
					->setValue('')
					->setAttrib('disable', 'disable')
					->setAttrib('style', 'font-weight:bold')
					->setDecorators($this->decorator);
			
			$this->addElements(array($Mode,$levelId,$parent_id,$type,$CountyList,$CurrencyList,$Username,$Firstname, $MiddleName,$Lastname,$Email,$InvoiceEmail,$Company,$Vat,$BTW,$PhoneNumber,$chargeBtw,$showprice,$AddressOne,$AddressTwo,$ZipCode,$City,$adminLogo,$InvoiceLogo,$headerColor, $TextColor,$labelOption,$Invoice,$submit));	
		}
		else{
			$this->addElements(array($levelId,$parent_id,$type,$CountyList,$CurrencyList,$Username,$Password,$Confirm,$Firstname, $MiddleName,$Lastname,$Email,$InvoiceEmail,$Company,$Vat,$BTW,$PhoneNumber,$chargeBtw,$showprice,$AddressOne,$AddressTwo,$ZipCode,$City,$adminLogo,$InvoiceLogo,$headerColor, $TextColor,$labelOption,$Invoice,$InvoiceSeries,$submit));
		}
		return $this;		  			  
	}
	
	public function CustomerForm(){
		
        $this->setMethod('post');
   		$this->setName('addeditcustomer');
 	 	$this->setAttrib('class', 'inputbox');
		
		$Mode = $this->fieldmode();
		
		$levelId = $this->setLevelId();
		
		$CountyList = $this->showcountryList();
		
		$DepotList = $this->setdepotList();
				  
		$Language = $this->showlanguageList();
				  		  
		$Username = $this->fieldusername();		  
				  
		$Password = $this->fieldpassword();		  
				  
		$Confirm = $this->fieldrepassword();
				  
		$Firstname = $this->fieldfirstname();
		
		$MiddleName = $this->fieldmiddlename();
				  
		$Lastname = $this->fieldlastname();		  		  		  	  
				  
		$Email = $this->fieldemail();
				   
		$InvoiceEmail = $this->fieldinvoicemail();		   	
		
		$Company = $this->fieldcompanyname();
		
		$Customer = new Zend_Form_Element_Text('customer_code');
        $Customer->setLabel('Customer Number')
				  ->addFilter('StringTrim')	
				  ->setAttrib('title','Please Fill Customer Number')
				  ->setAttrib('class','inputfield')
                  ->setRequired(true)
                  ->addValidator('NotEmpty')
				  ->setDecorators($this->decorator);
				  
		$glscustomerno = new Zend_Form_Element_Text('glscustomer_no');
        $glscustomerno->setLabel('GLS Customer Number')
				  ->setAttrib('class','inputfield')
                  ->setDecorators($this->decorator);		  
		
		$glsDepotNo = new Zend_Form_Element_Text('glsdepot_no');
        $glsDepotNo->setLabel('GLS Depot Number')
				  ->setAttrib('class','inputfield')
                  ->setDecorators($this->decorator);		  
		
		$glsEmailID = new Zend_Form_Element_Text('gls_emailid');
        $glsEmailID->setLabel('GLS EmailID')
				  ->setAttrib('class','inputfield')
                  ->setDecorators($this->decorator);		  
								  
		$BTW = $this->fieldbtwnumber();
				  
		$PhoneNumber = $this->fieldphone();
				  
		$AddressOne = $this->fieldaddress1();
				  
		$AddressTwo = $this->fieldaddress2();		  			  		  		  
		
		$ZipCode = $this->fieldpincode();
				  
		$City = $this->fieldcity();	  
		
		$adminLogo = $this->fieldadminlogo();
		
		$headerColor = $this->fieldheadercolor();
		
		$TextColor = $this->fieldtextcolor();
		
		$InvoiceLogo = $this->fieldinvoicelogo();
		   									    		  		   		   		  
		$submit = $this->fieldsubmit();
		
		$this->addElements(array($levelId,$CountyList,$DepotList,$Language,$Username,$Password,$Confirm,$Firstname, $MiddleName,$Lastname,$Email,$InvoiceEmail,$Company,$Customer,$glscustomerno,$glsDepotNo,$glsEmailID,$BTW,$PhoneNumber,$AddressOne,$AddressTwo,$ZipCode,$City,$adminLogo,$InvoiceLogo,$headerColor,$TextColor,$submit));	
		
		return $this;		  			  
	}
	
	public function OperatorForm(){
		
        $this->setMethod('post');
   		$this->setName('addeditoperator');
 	 	$this->setAttrib('class', 'inputbox');
		
		$Mode = $this->fieldmode();
		
		$levelId = $this->setLevelId();
		
		$type = new Zend_Form_Element_Text('administrator');
		$type->setLabel("Administrator's type")
				->setValue('Operator')
				->setAttrib('disable', 'disable')
				//->setAttrib('class', 'inputfield')
				->setAttrib('style', 'font-weight:bold')
				->setDecorators($this->decorator);
				
		$DepotList = $this->setdepotList();
			  
		$Username = $this->fieldusername();		  
				  
		$Password = $this->fieldpassword();		  
				  
		$Confirm = $this->fieldrepassword();
				  
		$Firstname = $this->fieldfirstname();
		
		$MiddleName = $this->fieldmiddlename();
				  
		$Lastname = $this->fieldlastname();		  		  		  	  
				  
		$Email = $this->fieldemail();
				   
		$InvoiceEmail = $this->fieldinvoicemail();		   	
		
		$Company = $this->fieldcompanyname();
		
		$PhoneNumber = $this->fieldphone();
				  
		$AddressOne = $this->fieldaddress1();
				  
		$AddressTwo = $this->fieldaddress2();		  			  		  		  
		
		$ZipCode = $this->fieldpincode();
				  
		$City = $this->fieldcity();		  
		
		$headerColor = $this->fieldheadercolor();
		
		$TextColor = $this->fieldtextcolor();
		
		$labelOption = $this->fieldlabeloption();
		
		/*$privilege = new Zc_Form_Element_Privilege('priv');
		$privilege->setLabel('Set privilege :')
				   ->setvalue($this->privilege)
				   ->setDecorators($this->defineDecorator(''));*/
		//$this->clear4fix;
				   									    		  		   		   		  
		$submit = $this->fieldsubmit();
		
		$this->addElements(array($Mode,$levelId,$type,$DepotList,$Username,$Password,$Confirm,$Firstname,$MiddleName,$Lastname,$Email,$InvoiceEmail,$Company,$PhoneNumber,$AddressOne,$AddressTwo,$ZipCode,$City,$headerColor,$TextColor,$labelOption,$submit));	
		
		return $this;		  			  
	}
	
	public function CustomerOperatorForm(){
		
        $this->setMethod('post');
   		$this->setName('addeditcustomeroperator');
 	 	$this->setAttrib('class', 'inputbox');
		
		$levelId = $this->setLevelId();
		
		$type = new Zend_Form_Element_Text('administrator');
		$type->setLabel("Administrator's type")
				->setValue('Customer Operator')
				->setAttrib('disable', 'disable')
				//->setAttrib('class', 'inputfield')
				->setAttrib('style', 'font-weight:bold')
				->setDecorators($this->decorator);
				
		$CustomerList = $this->showcustomerList();
				  		  
		$Username = $this->fieldusername();		  
				  
		$Password = $this->fieldpassword();	  
				  
		$Confirm = $this->fieldrepassword();
				  
		$Firstname = $this->fieldfirstname();
		
		$MiddleName = $this->fieldmiddlename();
				  
		$Lastname = $this->fieldlastname();		  		  		  	  
				  
		$Email = $this->fieldemail();
				   
		$Company = $this->fieldcompanyname();
							  
		$PhoneNumber = $this->fieldphone();
				  
		$AddressOne = $this->fieldaddress1();
				  
		$AddressTwo = $this->fieldaddress2();		  			  		  		  
		
		$ZipCode = $this->fieldpincode();
				  
		$City = $this->fieldcity();		  
		
		$adminLogo = $this->fieldadminlogo();
		
		$headerColor = $this->fieldheadercolor();
		
		$TextColor = $this->fieldtextcolor();
		
		$labelOption = $this->fieldlabeloption();
		
		/*$privilege = new Zc_Form_Element_Privilege('priv');
		$privilege->setLabel('Set privilege :')
				   ->setvalue($this->privilege)
				   ->setDecorators($this->defineDecorator(''));*/
		//$this->clear4fix;
				   									    		  		   		   		  
		$submit = $this->fieldsubmit();
				  
		$this->addElements(array($levelId,$type,$CustomerList,$Username,$Password,$Confirm,$Firstname,$MiddleName,$Lastname,$Email,$Company,$PhoneNumber,$AddressOne,$AddressTwo,$ZipCode,$City,$adminLogo,$headerColor,$TextColor,$labelOption,$submit));	
		return $this;		  			  
	}
	
	public function HubuserForm(){
		
        $this->setMethod('post');
   		$this->setName('addedithubuser');
 	 	$this->setAttrib('class', 'inputbox');
		
		$levelId = $this->setLevelId();
		
		$type = new Zend_Form_Element_Text('administrator');
		$type->setLabel("Administrator's type")
				->setValue('Hub User')
				->setAttrib('disable', 'disable')
				//->setAttrib('class', 'inputfield')
				->setAttrib('style', 'font-weight:bold')
				->setDecorators($this->decorator);
							
		$CountyList = $this->showcountryList();
				  	  
		$Language = $this->showlanguageList();
				  
		$Username = $this->fieldusername();		  
				  
		$Password = $this->fieldpassword();		  
				  
		$Confirm = $this->fieldrepassword();	
				  
		$Firstname = $this->fieldfirstname();
		
		$MiddleName = $this->fieldmiddlename();
				  
		$Lastname = $this->fieldlastname();		  		  		  	  
				  
		$Email = $this->fieldemail();
				   
		$InvoiceEmail = $this->fieldinvoicemail();		   	
		
		$Company = $this->fieldcompanyname();
		
		$Vat = $this->fieldvatnumber();
		
		$PhoneNumber = $this->fieldphone();
				  
		$AddressOne = $this->fieldaddress1();
				  
		$AddressTwo = $this->fieldaddress2();		  			  		  		  
		
		$ZipCode = $this->fieldpincode();
				  
		$City = $this->fieldcity();		  
		
		$adminLogo = $this->fieldadminlogo();
		
		$headerColor = $this->fieldheadercolor();
		
		$TextColor = $this->fieldtextcolor();
				   									    		  		   		   		  
		$submit = $this->fieldsubmit();
				  
		$this->addElements(array($levelId,$type,$CountyList,$Language,$Username,$Password,$Confirm,$Firstname, $MiddleName,$Lastname,$Email,$InvoiceEmail,$Company,$Vat,$PhoneNumber,$AddressOne,$AddressTwo,$ZipCode,$City,$adminLogo,$headerColor, $TextColor,$submit));	
		
		return $this;		  			  
	}
	
	public function HubOperatorForm(){
		//print_r($this->mode);die;
        $this->setMethod('post');
   		$this->setName('addedithuboperator');
 	 	$this->setAttrib('class','inputbox');
		
		$Mode = $this->fieldmode();
		
		$levelId = $this->setLevelId();
		
		$HubUsers = new Zend_Form_Element_Select('user_id');
        $HubUsers->setLabel('Hub User')
				  ->addMultiOptions(array('' => '--Select Hub User--'))
				  ->addMultiOptions($this->listHubuser)	
				  ->setAttrib('title', 'Please Select Hub User')
				  ->setAttrib('class', 'inputfield')
				  ->setRequired(true)
				  ->addValidator('NotEmpty')
				  ->setDecorators($this->decorator);
				  
				  
		$CountyList = $this->showcountryList();
				  	  
		$Language = $this->showlanguageList();
				  
		$Username = $this->fieldusername();		  
				  
		$Password = $this->fieldpassword();
		
		$Confirm = $this->fieldrepassword();
				  
		$Firstname = $this->fieldfirstname();
		
		$MiddleName = $this->fieldmiddlename();
				  
		$Lastname = $this->fieldlastname();		  		  		  	  
				  
		$Email = $this->fieldemail();
				   
		$InvoiceEmail = $this->fieldinvoicemail();	   	
		
		$Company = $this->fieldcompanyname();
		
		$PhoneNumber = $this->fieldphone();
				  
		$AddressOne = $this->fieldaddress1();
				  
		$AddressTwo = $this->fieldaddress2();		  			  		  		  
		
		$ZipCode = $this->fieldpincode();
				  
		$City = $this->fieldcity();		  
		
		$headerColor = $this->fieldheadercolor();
		
		$TextColor = $this->fieldtextcolor();
				   									    		  		   		   		  
		$submit = $this->fieldsubmit();
				  
		$this->addElements(array($Mode,$levelId,$HubUsers,$CountyList,$Language,$Username,$Password,$Confirm,$Firstname,$MiddleName,$Lastname,$Email,$InvoiceEmail,$Company,$PhoneNumber,$AddressOne,$AddressTwo,$ZipCode,$City,$headerColor,$TextColor,$submit));	
		return $this;		  			  
	}
	
	public function driverForm(){
		
        $this->setMethod('post');
   		$this->setName('addeditdriver');
 	 	$this->setAttrib('class', 'inputbox');
		
		$Mode = $this->fieldmode();
		$levelId = $this->setLevelId();
		 
		$DepotList = $this->setdepotList();
		
		$Username = $this->fieldusername();	
		
		$Password = $this->fieldpassword();		  
		
		$Confirm = $this->fieldrepassword();
			
		$CountyList = $this->showcountryList();
				  	  
		$DriverType = new Zend_Form_Element_Select('driver_work_type');
        $DriverType->setLabel('Driver Type')
				  ->addMultiOptions(array('' => '--Select Driver Type--'))
				  ->addMultiOptions(array(1=>'Contract',2=>'Flexible Contract'))	
				  ->setAttrib('title', 'Please Select Driver Type')
				  ->setAttrib('class', 'inputfield')
				  ->setRequired(true)
				  ->addValidator('NotEmpty')
				  ->setDecorators($this->decorator);
				  
		
		$workinghours = new Zend_Form_Element_Text('total_workhour');
        $workinghours->setLabel('Workin Hours')
				  ->addFilter('StringTrim')	
				  ->setAttrib('title', 'Please Fill Working Hours')
				  ->setAttrib('class', 'inputfield')
				  ->setDecorators($this->decorator);
		
				  
		$driverName = new Zend_Form_Element_Text('driver_name');
        $driverName->setLabel('Driver Name')
				  ->addFilter('StringTrim')	
				  ->setAttrib('title', 'Please Fill drivername')
				  ->setAttrib('class', 'inputfield')
                  ->setRequired(true)
                  ->addValidator('NotEmpty')
				  ->setDecorators($this->decorator);
		
		
		$driverCode = new Zend_Form_Element_Text('driver_code');
        $driverCode->setLabel('Driver Code')
				  ->addFilter('StringTrim')	
				  ->setAttrib('title', 'Please Fill drivercode')
				  ->setAttrib('class', 'inputfield')
                  ->setRequired(true)
                  ->addValidator('NotEmpty')
				  ->setDecorators($this->decorator);
		
		$licenseNo = new Zend_Form_Element_Text('license_number');
        $licenseNo->setLabel('License Number')
				  ->addFilter('StringTrim')	
				  ->setAttrib('title', 'Please Fill License Number')
				  ->setAttrib('class', 'inputfield')
                  ->setRequired(true)
                  ->addValidator('NotEmpty')
				  ->setDecorators($this->decorator);	  		  		  	  
				  
		$Issuedate = new Zend_Form_Element_Text('license_issue_date');
        $Issuedate->setLabel('License Issue Date')
				  ->addFilter('StringTrim')	
				  ->setAttrib('title', 'Please Fill License Issue Date')
				  //->setAttrib('class', 'inputfield')
				  ->setAttrib('style', 'width:260px')
				  ->setRequired(true)
                  ->addValidator('NotEmpty')
				  ->setDecorators($this->decorator);
		
		$Expirydate = new Zend_Form_Element_Text('license_expiry_date');
        $Expirydate->setLabel('License Expiry Date')
				  ->addFilter('StringTrim')	
				  ->setAttrib('title', 'Please Fill License Expiry Date')
				  //->setAttrib('class', 'inputfield')
				   ->setAttrib('style', 'width:260px')
                  ->setRequired(true)
                  ->addValidator('NotEmpty')
				  ->setDecorators($this->decorator);
				  
		$VehicleType = new Zend_Form_Element_Text('type_of_vehicle');
        $VehicleType->setLabel('Type Of Vehicle')
				  ->addFilter('StringTrim')	
				  ->setAttrib('title', 'Please Fill Vehicle Type')
				  ->setAttrib('class', 'inputfield')
                  ->setRequired(true)
                  ->addValidator('NotEmpty')
				  ->setDecorators($this->decorator);		  	   	
		
		
		$PhoneNumber = $this->fieldphone();
				  
		$Street = new Zend_Form_Element_Text('street');
        $Street->setLabel('Street')
				  ->addFilter('StringTrim')	
				  ->setAttrib('title', 'Please Fill Street')
				  ->setAttrib('class', 'inputfield')
                  ->setRequired(true)
                  ->addValidator('NotEmpty')
				  ->setDecorators($this->decorator);
				  
		$ZipCode = $this->fieldpincode();
				  
		$City = $this->fieldcity();
		
		$Email = new Zend_Form_Element_Text('email');
        $Email->setLabel('Email')
				  ->addFilter('StringTrim')	
				  ->setAttrib('title', 'Please Fill Email')
				  ->setAttrib('class', 'inputfield')
                  ->setDecorators($this->decorator);
		
		$Mallingadd = new Zend_Form_Element_Text('mailing_address');
        $Mallingadd->setLabel('Mailing Address')
				  ->addFilter('StringTrim')	
				  ->setAttrib('title', 'Please Fill Mailing Address')
				  ->setAttrib('class', 'inputfield')
                  ->setDecorators($this->decorator);
						   									    		  		   		   		  
		$submit = $this->fieldsubmit();
		
		if($this->mode=='edit'){
			$UserId = $this->CreateElement('hidden', 'user');
			$UserId->removeDecorator('label');
			$UserId->removeDecorator('HtmlTag');
				  
			$this->addElements(array($UserId,$Mode,$levelId,$DepotList,$Username,$CountyList,$DriverType,$workinghours,$driverName, $driverCode,$licenseNo,$Issuedate,$Expirydate,$VehicleType,$PhoneNumber,$Street,$ZipCode,$City,$Email,$Mallingadd,$submit));
		}
		else{
			$this->addElements(array($Mode,$levelId,$DepotList,$Username,$Password,$Confirm,$CountyList,$DriverType,$workinghours,$driverName, $driverCode,$licenseNo,$Issuedate,$Expirydate,$VehicleType,$PhoneNumber,$Street,$ZipCode,$City,$Email,$Mallingadd,$submit));
		}
		
		return $this;		  			  
	}
	
	
	public function changepasswordForm(){
		
		$this->setMethod('post');
   		$this->setName('changepassword');
 	 	$this->setAttrib('class','inputbox');
		
		
		$OldPassword = new Zend_Form_Element_text('oldpassword');
        $OldPassword->setLabel('Old Password')
				  ->addFilter('StringTrim')	
				  ->setAttrib('title', 'Please Fill Old Password')
				  ->setAttrib('class', 'inputfield')
                  ->setRequired(true)
                  ->addValidator('NotEmpty')
				  ->setDecorators($this->decorator);		  
		
		
		$Password = new Zend_Form_Element_text('password');
        $Password->setLabel('New Password')
				  ->addFilter('StringTrim')	
				  ->setAttrib('title', 'Please Fill Password')
				  ->setAttrib('class', 'inputfield')
                  ->setRequired(true)
                  ->addValidator('NotEmpty')
				  ->setDecorators($this->decorator);		  
		
		$Confirm = new Zend_Form_Element_text('retypepass');
        $Confirm->setLabel('Confirm Password')
				  ->addFilter('StringTrim')
				  ->setAttrib('title', 'Confirm Password')
				  ->setAttrib('class', 'inputfield')
                  ->setRequired(true)
                  ->addValidator('NotEmpty')
				  ->setAttrib('onchange',"confirmpassword()")
				  ->setDecorators($this->decorator);	
		
		$submit = $this->fieldsubmit();	

		$this->addElements(array($OldPassword,$Password,$Confirm,$submit));
		
		return $this;
	}
	
	
	public function drivercofigForm(){
		
		
		$this->setMethod('post');
   		$this->setName('driverconfig');
 	 	$this->setAttrib('class','inputbox');
		
		$type = new Zend_Form_Element_Text('driver_name');
		$type->setLabel("Driver Name")
				->setValue($this->drivername)
				->setAttrib('disable', 'disable')
				//->setAttrib('style', 'font-weight:bold')
				->setDecorators($this->decorator);
			
		
		$WorkingType = new Zend_Form_Element_Select('driver_work_type');
        $WorkingType->setLabel('Working Type')
				  ->addMultiOptions(array('' => '--Select Working Type--'))
				  ->addMultiOptions(array(1=>'Weekly working hours',2=>'Flexible worker'))	
				  ->setAttrib('title', 'Please Select Working Type')
				  ->setAttrib('class', 'inputfield')
				  ->setDecorators($this->decorator);		  
		
		
		$Totalhours = new Zend_Form_Element_text('total_workhour');
        $Totalhours->setLabel('Total Working Hours')
				  ->addFilter('StringTrim')	
				  ->setAttrib('title', 'Please Fill Total Working Hours')
				  ->setAttrib('class', 'inputfield')
                  ->setDecorators($this->decorator);		  
		
		$Leave = new Zend_Form_Element_text('assigned_leaves');
        $Leave->setLabel('Leave Allowed in Year')
				  ->addFilter('StringTrim')
				  ->setAttrib('title', 'Please Fill Assigned Leave')
				  ->setAttrib('class', 'inputfield')
                  ->setDecorators($this->decorator);	
		
		$submit = $this->fieldsubmit();	

		$this->addElements(array($type,$WorkingType,$Totalhours,$Leave,$submit));
		
		return $this;
	}

}