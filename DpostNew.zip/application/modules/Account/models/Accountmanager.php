<?php

class Account_Model_Accountmanager extends Zend_Custom
{
	/**
	 * administratorList() method, fetch administrator details.
	 * @access	public
	 * @param	Null
	 * @return	array
	 */
	public function administratorList($data=array()){
		
		$filterCustomerCompany=(!empty($data['company']))?"UD.company_name LIKE '" . $data['company'] . "%'" :'1';
		
		$filterCustomerName = (!empty($data['username']))? "UT.username LIKE '" . $data['username'] . "%'" : '1';
		
		$filterPostcode = (!empty($data['postcode']))? " UD.postalcode LIKE '" . $data['postcode'] . "%'" : '1';
			
		$select = $this->_db->select()
					->from(array('UT'=>USERS), array('user_id','username','password_text','user_status'))
					->joininner(array('UD'=>USERS_DETAILS), 'UT.user_id=UD.user_id', array('company_name','first_name','last_name','email',''))
					->joininner(array('US'=>USERS_SETTINGS), 'UT.user_id=US.user_id', array('*'))
					->joininner(array('CT'=>COUNTRIES) ,' CT.country_id=UD.country_id',array('country_name'))
					->where('UT.user_id IN(1,2,3)')
					->where('UT.delete_status=?', "0")
					->where($filterCustomerCompany)
					->where($filterCustomerName)
				    ->where($filterPostcode)
					->order('UT.level_id');	//echo $select->__tostring(); //die;
			$result = $this->getAdapter()->fetchAll($select);
			//echo"<pre>";print_r($result);die;
			return $result;
	}
	
	
	/**
	 * depotList() method, fetch depot users details.
	 * @access	public
	 * @param	Null
	 * @return	array
	 */
	public function depotList($data=array()){ 
		try{
			$filterCustomerCompany=(!empty($data['company']))?"UD.company_name LIKE '". $data['company'] . "%'":'1';
			
			$filterCustomerName = (!empty($data['username']))? "UT.username LIKE '". $data['username'] . "%'" : '1';
			
			$filterPostcode = (!empty($data['postcode']))? " UD.postalcode LIKE '". $data['postcode'] . "%'" : '1';
			$filterdepot = (!empty($data['filterdepot']))? " UT.user_id LIKE '". $data['filterdepot'] . "%'" : '1';
			
			$userId = (!empty($data['user_id']))? " UT.user_id=".$data['user_id'] : '1';
				
			$select = $this->_db->select()
					->from(array('UT'=>USERS), array(ADMIN_ID,'username','password_text','user_status'))
					->joininner(array('UD'=>USERS_DETAILS),'UT.user_id=UD.user_id', array('*'))
					->joininner(array('US'=>USERS_SETTINGS), 'UT.user_id=US.user_id',array('*'))
					->joininner(array('CT'=>COUNTRIES) ,' CT.country_id=UD.country_id',array('country_id','country_name'))
					->where('UT.level_id=4')
					->where('UT.delete_status=?',"0")
					->where($filterCustomerCompany)
					->where($filterCustomerName)
				    ->where($filterPostcode)
					->where($filterdepot)
					->where($userId)
					->order('UD.company_name');	//echo $select->__tostring(); die;
			$result = $this->getAdapter()->fetchAll($select);
			return $result;
		}
		catch(Exception $e){
			die('Something is wrong: ' . $e->getMessage());
		}	
	}
	
	
	/**
	 * customerList() method, fetch customers details.
	 * @access	public
	 * @param	Null
	 * @return	array
	 */
	public function customerList($data=array()){	//echo"<pre>";print_r($data);die;
		try{
			$filterCustomerCompany=(!empty($data['company']))?"UD.company_name LIKE '" . $data['company'] . "%'":'1';
			$filterCustomerName = (!empty($data['username']))? "UT.username LIKE '" . $data['username'] . "%'" : '1';
			$filterPostcode = (!empty($data['postcode']))? " UD.postalcode LIKE '" . $data['postcode'] . "%'" : '1';
			$filterdepot = (!empty($data['filterdepot']))? " UD.parent_id LIKE '". $data['filterdepot'] . "%'" : '1';
			$userId = (!empty($data['user_id']))? " UT.user_id=".$data['user_id'] : '1';
				
			$select = $this->_db->select()
					->from(array('UT'=>USERS), array('user_id','username','password_text','user_status'))
					->joininner(array('UD'=>USERS_DETAILS), 'UT.user_id=UD.user_id', array('company_name','first_name','last_name','email',''))
					->joininner(array('US'=>USERS_SETTINGS), 'UT.user_id=US.user_id',array('*'))
					->joininner(array('CT'=>COUNTRIES) ,' CT.country_id=UD.country_id',array('country_name'))
					->where('UT.level_id=5')
					->where('UT.delete_status=?',"0")
					->where($filterCustomerCompany)
					->where($filterCustomerName)
				    ->where($filterPostcode)
					->where($filterdepot)
					->where($userId)
					->order('UD.company_name')
					->limit(100);	//echo $select->__tostring(); die;
			$result = $this->getAdapter()->fetchAll($select);
			//echo"<pre>";print_r($result);die;
			return $result;
		
		}
		catch(Exception $e){
			die('Something is wrong: ' . $e->getMessage());
		}
	}
	
	
	public function customeroperatorList(){
		try{
			$filterCustomerCompany=(!empty($data['company']))?"UD.company_name LIKE '" . $data['company'] . "%'":'1';
			$filterCustomerName = (!empty($data['username']))? "UT.username LIKE '" . $data['username'] . "%'" : '1';
			$filterPostcode = (!empty($data['postcode']))? " UD.postalcode LIKE '" . $data['postcode'] . "%'" : '1';
			$userId = (!empty($data['user_id']))? " UT.user_id=".$data['user_id'] : '1';
			
			/*if($this->Useconfig['level_id']== 4) {
                $customer_id = $this->getCustomerofOperator($this->Useconfig['user_id']);
				$where = 'UD.parent_id IN(' . $customer_id .')';
			}
			elseif($this->Useconfig['level_id'] == 6) {
				$depot_id = $this->getDepotOfOperator();
				$customer_id = $this->getCustomerofOperator($depot_id);
				$where = 'UD.parent_id IN('. $customer_id . ')';
			}
			elseif($this->Useconfig['level_id'] == 5) {
				$where = 'UD.parent_id='. $this->Useconfig['user_id'];
			}
			elseif($this->Useconfig['level_id'] == 10) {
				$where = ' UD.user_id='. $this->Useconfig['user_id'];
			}
			else {
				$where = " 1 ";
			}*/
			
			$select = $this->_db->select()
					->from(array('UT'=>USERS), array('user_id','username','password_text','user_status'))
					->joininner(array('UD'=>USERS_DETAILS), 'UT.user_id=UD.user_id', array('company_name','first_name','last_name','email',''))
					->joininner(array('US'=>USERS_SETTINGS), 'UT.user_id=US.user_id',array('*'))
					->joininner(array('CT'=>COUNTRIES) ,' CT.country_id=UD.country_id',array('country_name'))
					->where('UT.level_id=10')
					//->where($where)
					->where('UT.delete_status=?',"0")
					->where($filterCustomerCompany)
					->where($filterCustomerName)
				    ->where($filterPostcode)
					->where($userId)
					->order('UD.company_name');	//echo $select->__tostring(); //die;
			$result = $this->getAdapter()->fetchAll($select);
			//echo"<pre>";print_r($result);die;
			return $result;
		}
		catch(Exception $e){
			die('Something is wrong: ' . $e->getMessage());
		}
	
	}
	
	/**
	 * operatorList() method, fetch operators details.
	 * @access	public
	 * @param	Null
	 * @return	array
	 */
	public function operatorList($data=array()){
		try{
			$filterCustomerCompany=(!empty($data['company']))?"UD.company_name LIKE '" . $data['company'] . "%'":'1';
			$filterCustomerName = (!empty($data['username']))? "UT.username LIKE '" . $data['username'] . "%'" : '1';
			$filterPostcode = (!empty($data['postcode']))? " UD.postalcode LIKE '" . $data['postcode'] . "%'" : '1';
			$userId = (!empty($data['user_id']))? " UT.user_id=".$data['user_id'] : '1';
					
			$select = $this->_db->select()
					->from(array('UT'=>USERS), array('user_id','username','password_text','user_status'))
					->joininner(array('UD'=>USERS_DETAILS), 'UT.user_id=UD.user_id', array('company_name','first_name','last_name','email',''))
					->joininner(array('US'=>USERS_SETTINGS), 'UT.user_id=US.user_id',array('*'))
					->joininner(array('CT'=>COUNTRIES) ,' CT.country_id=UD.country_id',array('country_name'))
					->where('UT.level_id=6')
					->where('UT.delete_status=?',"0")
					->where($filterCustomerCompany)
					->where($filterCustomerName)
				    ->where($filterPostcode)
					->where($userId)
					->order('UD.company_name');	//echo $select->__tostring(); //die;
			$result = $this->getAdapter()->fetchAll($select);
			//echo"<pre>";print_r($result);die;
			return $result;
		}
		catch(Exception $e){
			die('Something is wrong: ' . $e->getMessage());
		}
	}
	
	/**
	 * hubuserList() method, fetch HubUsers details.
	 * @access	public
	 * @param	Null
	 * @return	array
	 */
	public function hubuserList($data=array()){
		try{
			$filterCustomerCompany=(!empty($data['company']))?"UD.company_name LIKE '" . $data['company'] . "%'":'1';
			$filterCustomerName = (!empty($data['username']))? "UT.username LIKE '" . $data['username'] . "%'" : '1';
			$filterPostcode = (!empty($data['postcode']))? " UD.postalcode LIKE '" . $data['postcode'] . "%'" : '1';
				
			$select = $this->_db->select()
					->from(array('UT'=>USERS), array('user_id','username','password_text','user_status'))
					->joininner(array('UD'=>USERS_DETAILS), 'UT.user_id=UD.user_id', array('company_name','first_name','last_name','email',''))
					->joininner(array('US'=>USERS_SETTINGS), 'UT.user_id=US.user_id',array('*'))
					->joininner(array('CT'=>COUNTRIES) ,' CT.country_id=UD.country_id',array('country_name'))
					->where('UT.level_id=7')
					->where('UT.delete_status=?',"0")
					->where($filterCustomerCompany)
					->where($filterCustomerName)
				    ->where($filterPostcode)
					->order('UD.company_name');	//echo $select->__tostring(); //die;
			$result = $this->getAdapter()->fetchAll($select);
			//echo"<pre>";print_r($result);die;
			return $result;
		}
		catch(Exception $e){
			die('Something is wrong: ' . $e->getMessage());
		}
	}
	
	/**
	 * hubOperatorList() method, fetch HubOperators details.
	 * @access	public
	 * @param	Null
	 * @return	array
	 */
	public function hubOperatorList($data=array()){
		try{
			
			$filterCustomerCompany=(!empty($data['company']))?"UD.company_name LIKE '" . $data['company'] . "%'":'1';
			$filterCustomerName = (!empty($data['username']))? "UT.username LIKE '" . $data['username'] . "%'" : '1';
			$filterPostcode = (!empty($data['postcode']))? " UD.postalcode LIKE '" . $data['postcode'] . "%'" : '1';
			$userId = (!empty($data['user_id']))? " UT.user_id=".$data['user_id'] : '1';
				
			$select = $this->_db->select()
					->from(array('UT'=>USERS), array('user_id','username','password_text','user_status'))
					->joininner(array('UD'=>USERS_DETAILS), 'UT.user_id=UD.user_id', array('company_name','first_name','last_name','email',''))
					->joininner(array('US'=>USERS_SETTINGS), 'UT.user_id=US.user_id',array('*'))
					->joininner(array('CT'=>COUNTRIES) ,' CT.country_id=UD.country_id',array('country_name'))
					->where('UT.level_id=8')
					->where('UT.delete_status=?',"0")
					->where($filterCustomerCompany)
					->where($filterCustomerName)
				    ->where($filterPostcode)
					->where($userId)
					->order('UD.company_name');	//echo $select->__tostring(); //die;
			$result = $this->getAdapter()->fetchAll($select);
			//echo"<pre>";print_r($result);die;
			return $result;
		
		} 
		catch(Exception $e){
			die('Something is wrong: ' . $e->getMessage());
		}
	}
	
	
	public function addNewUser($data){	
		
		$uploadFiles 	= array('logo','invoice_logo');
	    $uploadedFiles 	= $this->uploadFiles($uploadFiles);
		
		$data['logo']  	= $uploadedFiles['logo'];
		$data['invoice_logo'] = $uploadedFiles['invoice_logo'];
		$data['password_text']= $data['password'];
		$data['password'] = md5($data['password']);
		$data['create_date']= new Zend_Db_Expr('NOW()');
		$data['create_by'] = $this->Useconfig['user_id'];
		$data['create_ip'] = commonfunction::loggedinIP();
		
		$data['user_id'] = $this->insertInToTable(USERS,array($data));
		if($data['user_id']>0){
			$this->insertInToTable(USERS_DETAILS,array($data));
			$this->insertInToTable(USERS_SETTINGS,array($data));
		}
		return $data['user_id'];
	}
	
	
	/**
	 * userNameAvailability() method, find username existance in system for user.
	 * @access	public
	 * @param	$data, array hold user details
	 * @return	integer
	 */
	public function userNameAvailability($data){
			
	   $admin_id = ($data['formaction']==1) ? "user_id=".$data['token'] : 1;
	   $select = $this->_db->select()
	             ->from(USERS,array('exist'=>'COUNT(username)'))
				 ->where('username=?',$data['username'])
				 ->where($admin_id);
	   $result = $this->getAdapter()->fetchRow($select);
	   if ($result['exist']>=1){
          return 0;
       } 
	   else {
	      return 1;
       }
	}
	
	
	/**
	 * uploadFiles() method, used to upload files.
	 * @access	public
	 * @param	$uploadArr, array hold field name
	 * @return	array
	 */
	public function uploadFiles($uploadArr){
        $adapter = new Zend_File_Transfer_Adapter_Http();
		$files = $adapter->getFileInfo();	//echo"<pre>";print_r($files);die;
		for($i=0;$i<=count($uploadArr);$i++){
			foreach($files as $key=>$value){
			    if($key==$uploadArr[$i]){
				    $time = time();
					$fileName = $files[$key]['name'];
					if($fileName!=''){
					   $adapter->addFilter('Rename',array('target' => LOGO_UPLODE_LINK . '/' .$time.'.'.$fileName));
					   $adapter->receive($fileName);
					  // Zend_FPDF_Image_Support::imageValidation(LOGO_UPLODE_LINK . '/' .$time.'.'.$fileName);
					   $fileinfo[$key] = $time.'.'.$fileName;
					}
					unset($files[$key]);
				}
			}
		}
		return $fileinfo;
	}
	
	
	public function getNextInvoiceSeries(){	
	   $select = $this->_db->select()
	             ->from(array('US'=>USERS_SETTINGS),array('MAX(invoice_series) as invoice_series'))
				 ->joininner(array('UD'=>USERS_DETAILS),' UD.user_id=US.user_id',array(''))
				 ->where('UD.parent_id=1');		//echo $select->__tostring(); die;
	   $result = $this->getAdapter()->fetchRow($select);
	   //print_r($result['invoice_series']+1);die;
	   return $result['invoice_series']+1;
	}
	
	
	public function edituser($data=array()){
		$data['update_date']= new Zend_Db_Expr('NOW()');
		$data['update_by']	= $this->Useconfig['user_id'];	// update by session loginid
		$data['update_ip']	= commonfunction::loggedinIP();
		
		$userId = Zend_Encript_Encription:: decode($data['token']);
		
		$this->UpdateInToTable(USERS,array($data),'user_id='.$userId);
		$this->UpdateInToTable(USERS_DETAILS,array($data),'user_id='.$userId);
		$this->UpdateInToTable(USERS_SETTINGS,array($data),'user_id='.$userId);
		
		return true;
		//echo"<pre>";print_r($data);die;
	}
	
	
	public function driverlist($data=array()){
		$userId = (!empty($data['driver_id'])) ? " DDT.driver_id=".$data['driver_id'] : '1';
			
		$select = $this->_db->select()
	            ->from(array('DDT'=>DRIVER_DETAIL_TABLE),array('*'))
				 ->joininner(array('UD'=>USERS_DETAILS),'UD.user_id=DDT.parent_id',array('company_name','user_id'))
				 ->where("DDT.delete_status='0'")
				 ->where('DDT.level_id=9')
				 ->where($userId);		//echo $select->__tostring(); die;
	   $result = $this->getAdapter()->fetchAll($select);
	   
	   return $result;
	}
	
	public function addnewdriver($data=array()){	//echo"<pre>";print_r($data);die;
	  // $data['license_issue_date'] = date('Y:m:d',strtotime($data['license_issue_date']));
	  // $data['license_expiry_date'] = date('Y:m:d',strtotime($data['license_expiry_date']));
	  
	   $data['create_date'] = new Zend_Db_Expr('NOW()');
	   $data['create_ip']	= commonfunction::loggedinIP();
		
	   $data['password_text'] = $data['password'];
	   $data['password'] = md5($data['password']);
	  
	   $data['user_id'] = $this->insertInToTable(USERS,$data);
	   
	   if(!empty($data['user_id'])){
	   	 $this->insertInToTable(USERS_DETAILS,$data);
	     $this->insertInToTable(DRIVER_DETAIL_TABLE,$data);
		 
		 return true;
	   }
	   return false;
	}
	
	public function editdriver($data=array()){
		
		$data['update_date']= new Zend_Db_Expr('NOW()');
		$data['update_by']	= $this->Useconfig['user_id'];	
		$data['update_ip']	= commonfunction::loggedinIP();
		
		$DriverId = Zend_Encript_Encription:: decode($data['token']);
		
		$this->UpdateInToTable(DRIVER_DETAIL_TABLE,array($data),'driver_id='.$DriverId);
		$this->UpdateInToTable(USERS_DETAILS,array($data),'user_id='.$data['user']);
		
		if(isset($data['user_name'])){
			$this->UpdateInToTable(USERS,array($data),'user_id='.$data['user']);
		}
		return true;
	}
	
	public function changepassword($data=array()){
		
		$data['update_date']= new Zend_Db_Expr('NOW()');
		$data['update_by']	= $this->Useconfig['user_id'];	
		$data['update_ip']	= commonfunction::loggedinIP();
		
		$data['password_text'] = $data['password'];
	    $data['password'] = md5($data['password']);
	  
		$this->UpdateInToTable(USERS,array($data),'user_id='.Zend_Encript_Encription::decode($data['token']));
		$this->UpdateInToTable(USERS_DETAILS,array($data),'user_id='.Zend_Encript_Encription::decode($data['token']));
		
		return true;
	}
	
	public function deleteUser($data){ 
		
		$data['delete_date']= new Zend_Db_Expr('NOW()');
		$data['delete_by']	= $this->Useconfig['user_id'];	
		$data['delete_ip']	= commonfunction::loggedinIP();
		$data['delete_status'] = '1';
		
		$this->UpdateInToTable(USERS,array($data),'user_id='.$data['user_id']);
		$this->UpdateInToTable(USERS_DETAILS,array($data),'user_id='.$data['user_id']);
		
		if(isset($data['driver_id'])){
			$this->UpdateInToTable(DRIVER_DETAIL_TABLE,array($data),'driver_id='.$data['driver_id']);
		}
		return true;
	}

}

