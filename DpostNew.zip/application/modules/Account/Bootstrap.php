<?php
class Account_Bootstrap extends Zend_Application_Module_Bootstrap	
{
   
 	function _initApplication(){ 
	 
	}

	public function _initLayout() {
   	/* try{
	 $this->bootstrap('layout');
	 }catch(Exception $e){
	   echo $e->getMessage();die;
	 }
	 $this->bootstrap('layout');*/
	//$layout = $this->getResource('layout');
	}

	protected function _initNavigation() { 
		

	}
	
 
    /**
     * return the default bootstrap of the app
     * @return Zend_Application_Bootstrap_Bootstrap
     */
    protected function _getBootstrap()
    {
        $frontController = Zend_Controller_Front::getInstance();
        $bootstrap =  $frontController->getParam('bootstrap');	//deb($bootstrap);
        return $bootstrap;
    }
	
	public function _initRouter()
	{
		$this->FrontController = Zend_Controller_Front::getInstance();
		$this->router = $this->FrontController->getRouter();  
		$this->appRoutes=array();
		   
 	}

	
	
	protected  function _initSiteRouters(){	
		   $this->appRoutes['acc_administrator']= new Zend_Controller_Router_Route('Account/myprofile',array('module'=>'Account','controller' => 'Account','action' => 'myprofile'));
		
		$this->appRoutes['acc_depotmanager']= new Zend_Controller_Router_Route('Account/depotmanager',array('module'=>'Account','controller' => 'Account','action' => 'depotmanager'));
		
		$this->appRoutes['acc_customer']= new Zend_Controller_Router_Route('Account/customer',array('module'=>'Account','controller' => 'Account','action' => 'customer'));
		
		$this->appRoutes['acc_customerOperator']= new Zend_Controller_Router_Route('Account/customeroperator',array('module'=>'Account','controller' => 'Account','action' => 'customeroperator'));
		
		$this->appRoutes['acc_operator']= new Zend_Controller_Router_Route('Account/operator',array('module'=>'Account','controller' => 'Account','action' => 'operator'));
		
		$this->appRoutes['acc_hubuser']= new Zend_Controller_Router_Route('Account/hubuser',array('module'=>'Account','controller' => 'Account','action' => 'hubuser'));
		
		$this->appRoutes['acc_huboperator']= new Zend_Controller_Router_Route('Account/huboperator',array('module'=>'Account','controller' => 'Account','action' => 'huboperator'));
		
		$this->appRoutes['acc_depotform']= new Zend_Controller_Router_Route('Account/depotform',array('module'=>'Account','controller' => 'Account','action' => 'depotform'));
		
		$this->appRoutes['acc_customerform']= new Zend_Controller_Router_Route('Account/customerform',array('module'=>'Account','controller' => 'Account','action' => 'customerform'));
		
		$this->appRoutes['acc_operatorform']= new Zend_Controller_Router_Route('Account/operatorform',array('module'=>'Account','controller' => 'Account','action' => 'operatorform'));
		
		$this->appRoutes['acc_customeroperatorform']= new Zend_Controller_Router_Route('Account/customeroperatorform',array('module'=>'Account','controller' => 'Account','action' => 'customeroperatorform'));
		
		$this->appRoutes['acc_hubuserform']= new Zend_Controller_Router_Route('Account/hubuserform',array('module'=>'Account','controller' => 'Account','action' => 'hubuserform'));
		
		$this->appRoutes['acc_huboperatorform']= new Zend_Controller_Router_Route('Account/huboperatorform',array('module'=>'Account','controller' => 'Account','action' => 'huboperatorform'));
		
		$this->appRoutes['acc_driversettings']= new Zend_Controller_Router_Route('Account/driversettings',array('module'=>'Account','controller' => 'Account','action' => 'driversettings'));
		
		$this->appRoutes['acc_driverform']= new Zend_Controller_Router_Route('Account/driverform',array('module'=>'Account','controller' => 'Account','action' => 'driverform'));
		
		$this->appRoutes['acc_changepassword']= new Zend_Controller_Router_Route('Account/changepassword',array('module'=>'Account','controller' => 'Account','action' => 'changepassword'));
		
		$this->appRoutes['acc_delete']= new Zend_Controller_Router_Route('Account/delete',array('module'=>'Account','controller' => 'Account','action' => 'delete'));
		
		$this->appRoutes['acc_driverconfig']= new Zend_Controller_Router_Route('Account/driverconfig',array('module'=>'Account','controller' => 'Account','action' => 'driverconfig'));
	}
	 protected  function _initSetupRouting(){	
			
			foreach($this->appRoutes as $key=>$cRouter){
			
				$this->router->addRoute( $key,  $cRouter );
			}
			
	}
	
	
    /**
     * return the bootstrap object for the active module
     * @return Offshoot_Application_Module_Bootstrap
     */
	 
    public function _getActiveBootstrap($activeModuleName)
    { print_r($activeModuleName);die;
        $moduleList = $this->_getBootstrap()->getResource('modules');
        if (isset($moduleList[$activeModuleName])) {
        }
 
        return null;
    }



}








