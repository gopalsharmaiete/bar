<?php
class settings_Form_Settings extends Application_Form_CommonDecorator
{

    public $ModelObj;
	public $conmmonDecObj;
	public $StatusModelObj;
	
    public function init()
    {
        $this->ModelObj = new settings_Model_Settings();
		$this->StatusModelObj = new settings_Model_Statuscode();
		//$this = new settings_Form_CommonDecorator();
		
    }
	public function addCountryForm()
    { 
		
        $this->addElement('text', 'country_name', array(
            'label'      => 'Country Name:',
			'class'  => 'inputfield',
            'required'   => true
        ));
		$this->addElement($this->createElement('select', 'continent_id')
											->setLabel('Continent Name: ')
											->setAttrib("class","inputfield")
											//->addMultiOptions(array('0'=>'Select Continent'))
											//->addMultiOptions(commonfunction::scalarToAssociative($this->ModelObj->getContinentList(),array('continent_id','continent_name')))
											->addMultiOptions(array(''=>'Select Continent'))
											->addMultiOptions(commonfunction::scalarToAssociative($this->ModelObj->getContinentList(),array('continent_id','continent_name')))
											);
		$this->addElement('text', 'cncode', array(
            'label'      => '2 DIGIT CNCODE:',
			'class'  => 'inputfield',
			'maxlength' => '2',
			'minlength' => '2'
        ));
		
		$this->addElement('text', 'cncode3', array(
            'label'      => '3 DIGIT CNCODE:',
			'class'  => 'inputfield',
			'maxlength' => '3',
			'minlength' => '3'
        ));
		
		$this->addElement('text', 'iso_code', array(
            'label'      => '3 Digit ISO Numeric CODE:',
			'class'  => 'inputfield',
			'maxlength' => '3',
			'minlength' => '3'
        ));
		
 		$this->addElement('text', 'area_code', array(
            'label'      => 'Dialing Number:',
			'class'  => 'inputfield',
			'maxlength' => '4',
			'minlength' => '3'
			/*'validators' => array(
                array(
                    'validator'=>'between',
                    'options'=>array(
                        'min'=>8,
                        'max'=>10,
                        'messages'=>array(
                            Zend_Validate_Between::NOT_BETWEEN => 'This is for %min% to %max% years old.'
                        )
                    )
                ),
            ),*/
        ));
		$this->addElement('text', 'postcode_length', array(
            'label'      => 'Post Code Length:',
			'class'  => 'inputfield',
			'maxlength' => '2',
        ));
		  $this->addElement('text', 'no_of_cn23', array(
            'label'      => 'No. Of CN23 :',
		   'class'  => 'inputfield',
				));
		  $this->addElement('textarea', 'local_info_service', array(
					'label'      => 'Local Info :',
		   'class'  => 'inputfield',
		   'ROWS' =>'2',
				));
		$this->addElement('submit', 'submit', array(
            'ignore'   => true,
            'label'    => 'Add New',
			'class'  => 'btn btn-danger btn-round',
        ));
		
		return $this;
    }
	
	public function printSettingForm()
    {     
		$this->addElement('radio', 'label_position', array(
            'label'      => 'Label Print Option:',
			'label_class' => 'control control--radio',
			'decorators' => $this->radio6Dec,
			'separator' =>'',
			'class'  => 'printlabel',
            'required'   => true,
			'multiOptions'=>array(
                'a1' => 'A4-1Position',
				'a4' => 'A4-4Position',
				'a6' => 'A6-Format'
            ),
			'value' => $this->ModelObj->Useconfig['label_position'],
        ));
		 $this->addElement('submit', 'submit', array(
            'ignore'   => true,
            'label'    => 'Update',
			'class'  => 'btn btn-danger btn-block',
        ));
		 return $this;
    }
     /**
     * Function : addPacketShopForm()
	 * Params : NULL
     * Setting PostCode Length of country
     * */
    public function addPacketShopForm(){
		$this->setName('addpacketshop');
		$this->setAttrib('class', 'inputbox');
        $this->setAction('');
		$this->setAttrib('id', 'addpacketshop');
        $this->setMethod('post');
		$this->setDecorators(
			$this->form12Dec
		 );
        $CountryList = $this->createElement('select', 'country_id')
											->setLabel('Country: ')
											->setAttrib("class","inputfield")
											->addMultiOptions(array(''=>'Select Country'))
											->addMultiOptions(commonfunction::scalarToAssociative($this->ModelObj->getCountryList(),array('country_id','country_name')))
											->setRequired(true)
											->addValidator('NotEmpty')
											->setDecorators($this->element3Dec);
		
        $shopname = $this->createElement('text', 'shope_name')
											->setLabel('Shop Name :')
											->setAttrib("class","inputfield")
											->setRequired(true)
											->addValidator('NotEmpty')
											->setDecorators($this->element3Dec);
		$city = $this->createElement('text', 'city')
											->setLabel('City :')
											->setAttrib("class","inputfield")
											->setRequired(true)
											->addValidator('NotEmpty')
											->setDecorators($this->element3Dec);
		$postalcode = $this->createElement('text', 'postal_code')
											->setLabel('Postal Code:')
											->setAttrib("class","inputfield")
											->setAttrib("onblur","getLatlong(this.value)")
											->setRequired(true)
											->addValidator('NotEmpty')
											->setDecorators($this->element3Dec);
		$street = $this->createElement('text', 'street')
											->setLabel('Street:')
											->setAttrib ( 'placeholder', 'Street' )
											->setAttrib("class","inputfield")
											->setRequired(true)
											->addValidator('NotEmpty')
											->setDecorators($this->element3Dec);
		$streetno = $this->createElement('text', 'streetno')
											->setLabel('Sreet No :')
											->setAttrib("class","inputfield")
											->setAttrib ( 'placeholder', 'Street No' )
											->setRequired(true)
											->addValidator('NotEmpty')
											->setDecorators($this->element3Dec);
		$address = $this->createElement('text', 'address')
											->setLabel('Address :')
											->setAttrib ( 'placeholder', 'Address' )
											->setAttrib("class","inputfield")
											->setRequired(true)
											->addValidator('NotEmpty')
											->setDecorators($this->element3Dec);
		$clearfix = $this->createElement('text','clearfix',$this->clearfix)->setAttrib('readonly', 'readonly');

      	 $days = 		 $this->createElement('hidden', 'days')
											->setLabel('Weekdays -:')
											->setAttrib("class","inputfield")
											->setDecorators($this->element12Dec);
	    $this->addElements(array($CountryList,$shopname,$city,$postalcode,$street,$streetno,$address,$clearfix,$days));
				$days =array('0'=>'Sunday','1'=>'Monday','2'=>'Tuesday','3'=>'Wednesday','4'=>'Thursday','5'=>'Friday','6'=>'Saturday');
		for($i=0;$i<count($days);$i++){
			$this->addElements(array($this->createElement('hidden', 'weekday_'.$days[$i])
											->setLabel($days[$i].':')
											->setAttrib("class","inputfield")
											->setAttrib ( 'placeholder', 'Start Time' )
											->setValue($days[$i])
											->setDecorators($this->element2Dec),
			$this->createElement('text', 'start_time_'.$days[$i])
											->setLabel(' ')
											->setAttrib("class","inputfield")
											->setAttrib ( 'placeholder', 'Start Time' )
											->setAttrib ( 'required',true )
											->setAttrib ( 'onmouseover', 'clickTimePicker(this.id)' )
											->setDecorators($this->element2Dec),
			$this->createElement('text', 'end_time_'.$days[$i])
											->setLabel(' ')
											->setAttrib ( 'placeholder', 'End Time' )
											->setAttrib ( 'required',true )
											->setAttrib ( 'onmouseover', 'clickTimePicker(this.id)' )
											->setAttrib("class","inputfield")
											->setDecorators($this->element2Dec)));
			
		 }
		 
		 $clearfix1 = $this->createElement('text','clearfix1',$this->clearfix)
		 									->setAttrib('readonly', 'readonly');
		 $this->addElement("hidden", "latitude");
		 $this->addElement("hidden", "longitude");
		 $Update = $this->createElement('submit', 'addpacketshop')
										->setAttrib("class","btn btn-danger btn-round")
										->setLabel('New Packet Shop')
										->setIgnore(true)
										->setDecorators($this->submit3Dec);
		 $this->addElements(array($clearfix1,$Update));
        	return $this;
    }
	
	 /**
     * Function : addPacketShopForm()
	 * Params : NULL
     * Setting PostCode Length of country
     * */
    public function addWeightScalForm(){
		$this->setName('addweightscallers');
		$this->setAttrib('class', 'inputbox');
        $this->setMethod('post');
		$this->setDecorators(
			$this->form12Dec
		 );
		
        $machineurl = $this->createElement('text', 'machine_url')
											->setLabel('IP Address')
											->setAttrib("class","inputfield")
											->setRequired(true)
											->addValidator('NotEmpty')
											->setDecorators($this->element3Dec);
		$serialno = $this->createElement('text', 'serial_no')
											->setLabel(' Serial number')
											->setAttrib("class","inputfield")
											->setRequired(true)
											->addValidator('NotEmpty')
											->setDecorators($this->element3Dec);
		$machinename = $this->createElement('text', 'machine_name')
											->setLabel('Machine Name')
											->setAttrib("class","inputfield")
											->setAttrib("onblur","getLatlong(this.value)")
											->setRequired(true)
											->addValidator('NotEmpty')
											->setDecorators($this->element3Dec);

		 $submit = $this->createElement('submit', 'submit')
										->setAttrib("class","btn btn-danger btn-round")
										->setLabel('Add Scaler')
										->setIgnore(true)
										->setDecorators($this->submit3Dec);
		 $this->addElements(array($machineurl,$serialno,$machinename,$submit));
        	return $this;
    }

	/**
     * Function : addPacketShopForm()
	 * Params : NULL
     * Setting PostCode Length of country
     * */
    public function addEditVehicleSettingForm(){
		$this->setName('addeditvehiclesetting');
		$this->setAttrib('class', 'inputbox');
        $this->setMethod('post');
		$this->setDecorators(
			$this->form9Dec
		 );
		 
        $vehicle_name = $this->createElement('text', 'vehicle_name')
											->setLabel('Vehicle Name')
											->setAttrib("class","inputfield")
											->setRequired(true)
											->addValidator('NotEmpty')
											->setDecorators($this->element6Dec);
		$vehicle_number = $this->createElement('text', 'vehicle_number')
											->setLabel('Liceplat No.')
											->setAttrib("class","inputfield")
											->setRequired(true)
											->addValidator('NotEmpty')
											->setDecorators($this->element6Dec);
		$vehicle_distance = $this->createElement('text', 'vehicle_distance')
											->setLabel('Killometer on Techo')
											->setAttrib("class","inputfield")
											->setRequired(true)
											->addValidator('NotEmpty')
											->setDecorators($this->element6Dec);

		 $submit = $this->createElement('submit', 'submit')
										->setAttrib("class","btn btn-danger btn-round")
										->setLabel('Add Vehicle')
										->setIgnore(true)
										->setDecorators($this->submit3Dec);
		 $this->addElements(array($vehicle_name,$vehicle_number,$vehicle_distance,$submit));
        	return $this;
    }


	/**
     * Function : addPortForm()
	 * Params : NULL
     * Setting PostCode Length of country
	 * Date : 11/11/2016
     * */
    public function addPortSettingForm(){
		 
        $CountryList = $this->createElement('select', 'country_id')
											->setLabel('Select Country')
											->setAttrib("class","inputfield")
											->addMultiOptions(commonfunction::scalarToAssociative($this->ModelObj->getCountryList(),array('country_id','country_name')))
											->setRequired(true)
											->addValidator('NotEmpty');
		$port_name = $this->createElement('text', 'port_name[]')
											->setLabel('Port Name')
											->setAttrib("class","inputfield")
											->setRequired(true)
											->addValidator('NotEmpty');
		$port_code = $this->createElement('text', 'port_code[]')
											->setLabel('Port Code')
											->setAttrib("class","inputfield")
											->setRequired(true)
											->addValidator('NotEmpty');

		 $submit = $this->createElement('submit', 'submit')
										->setAttrib("class","btn btn-danger btn-round")
										->setLabel('Add Port')
										->setIgnore(true);
		 $this->addElements(array($CountryList,$port_name,$port_code,$submit));
        	return $this;
    }
	
		 /**

     * Function : emailnotification()

     * Email Format Setting for Notification

     **/

        public function emailnotification($data) {
		   $customer=array();
		   $country=array();
				 $mailtext = (isset($data['notification_id']))?$this->ModelObj->getdynamicfield($data['notification_id']):array();
			  $notification_id=(isset($data['notification_id']))?$data['notification_id']:null;
		   $emailnotification = $this->createElement('select', 'notification_id')
				   ->setLabel('Notification Type: ')
				   ->setAttrib("class","inputfield")
				   ->setAttrib("onchange","this.form.submit()")
				   ->addMultiOptions(array(''=>'Select Notification'))
				   ->addMultiOptions(commonfunction::scalarToAssociative($this->ModelObj->notificationtype(),array('notofication_id','notification_name')))
				   ->setDecorators($this->element6Dec);
				   
							
		  if($notification_id!='1' && $notification_id!='4' && $this->ModelObj->Useconfig['level_id']!='5'){
			  if($this->ModelObj->Useconfig['level_id']=='1' && $notification_id=='3'){
			$customer = $this->createElement('select', 'user_id')
					 ->setLabel('Depot: ')
					 ->setAttrib("class","inputfield")
					 ->setAttrib("onchange","this.form.submit()")
					 ->addMultiOptions(array(''=>'Select Depot'))
					 ->addMultiOptions(commonfunction::scalarToAssociative($this->ModelObj->getDepotList(),array('user_id','username')))
					 ->setDecorators($this->element6Dec);
		   }
			
		   else{         
			$customer = $this->createElement('select', 'user_id')
					 ->setLabel('Customer: ')
					 ->setAttrib("class","inputfield")
					 ->setAttrib("onchange","this.form.submit()")
					 ->addMultiOptions(array(''=>'Select Customer'))
					 ->addMultiOptions(commonfunction::scalarToAssociative($this->ModelObj->getCustomerList(),array('user_id','username')))
					 ->setDecorators($this->element6Dec);
		   }
				   
		  }
					   
		  if($notification_id!='3'){
		   $country = $this->createElement('select', 'country_id')
					->setLabel('Country: ')
					->setAttrib("class","inputfield")
					->setAttrib("onchange","this.form.submit()")
					->addMultiOptions(array(''=>'Select Country'))
					->addMultiOptions(commonfunction::scalarToAssociative($this->ModelObj->getCountryList(),array('country_id','country_name')))
					->setDecorators($this->element6Dec);
		  }
		  
		  
		   
		   $dynamicfield = $this->createElement('select', 'dynamic_field')
				   ->setLabel('Dynamic Field: ')
				   ->setAttrib("class","inputfield")
				   ->setAttrib("onchange","AssignTofck()")
				   ->addMultiOptions($this->ModelObj->getdyanmicfielddata($mailtext))
				   ->setDecorators($this->element6Dec);
			   
				   
			$this->addElements(array($emailnotification,$customer,$country,$dynamicfield));
			$this->addElement('text', 'subject', array(
					'label'      => 'Subject:',
		   'class'  => 'inputfield',
		   'decorators' => $this->element12Dec
				));
		   
		   return $this;
		   
		  }
	/**
     * Function : blockipForm()
	 * Params : NULL
     * block ip form 
     * */
    public function blockipForm(){
		$this->setName('blockipform');
		$this->setAttrib('class', 'inputbox');
        $this->setMethod('post');
		$this->setDecorators(
			$this->form12Dec
		 );
		$blockip = $this->createElement('text', 'blockip')
											->setLabel('Block Ip')
											->setAttrib("class","input__field input__field--kaede")
											->setRequired(true)
											->addValidator('NotEmpty')
											->setDecorators($this->element3Dec);

		 $submit = $this->createElement('submit', 'submit')
										->setAttrib("class","btn btn-danger btn-round")
										->setLabel('Add Block Ip')
										->setIgnore(true)
										->setDecorators($this->submit3Dec);
		 $this->addElements(array($blockip,$submit));
        	return $this;
    }
	 /**
     * Function : languageForm()
  * Params : NULL
     * Setting language form in setting
  * Date : 23/12/2016
     * */
    public function languageForm(){
		$this->setName('languageform');
		$this->setAttrib('class', 'inputbox');
		$this->setMethod('post');
		$this->setDecorators(
				$this->form12Dec
		);
	  $language_name = $this->createElement('text', 'language_name')
			   ->setLabel('Language Name')
			   ->setAttrib("class","inputfield")
			   ->setRequired(true)
			   ->addValidator('NotEmpty')
			   ->setDecorators($this->element6Dec);
	  $language_code = $this->createElement('text', 'language_code')
			   ->setLabel('Language Code')
			   ->setAttrib("class","inputfield")
			   ->setRequired(true)
			   ->addValidator('NotEmpty')
			   ->setDecorators($this->element6Dec);
	
	   $submit = $this->createElement('submit', 'submit')
			  ->setAttrib("class","btn btn-danger btn-round")
			  ->setLabel('Add Language')
			  ->setIgnore(true)
			  ->setDecorators($this->submit3Dec);
	   $this->addElements(array($language_name,$language_code,$submit));
			 return $this;
    }
	/**
     * Function : serviceForm()
  * Params : NULL
     * block ip form 
     * */
   public function serviceForm(){
	  $this->setName('serviceform');
	  $this->setAttrib('class', 'inputbox');
			$this->setMethod('post');
	  $this->setDecorators(
	   $this->form12Dec
	   );
	  $service_name = $this->createElement('text', 'service_name')
			   ->setLabel('Service Name')
			   ->setAttrib("class","inputfield")
			   ->setRequired(true)
			   ->addValidator('NotEmpty')
			   ->setDecorators($this->element6Dec);
	  $internalcode = $this->createElement('text', 'internal_code')
			   ->setLabel('Internal Code')
			   ->setAttrib("class","inputfield")
			   ->setRequired(true)
			   ->addValidator('NotEmpty')
			   ->setDecorators($this->element6Dec);
	  $service_icon = $this->createElement('text', 'service_icon')
			   ->setLabel('Service Icon')
			   ->setAttrib("class","inputfield")
			   ->setDecorators($this->element6Dec);
	  $this->addElements(array($service_name,$internalcode,$service_icon));
	  $this->addElement('radio', 'signature', array(
				   'label'      => 'Signature',
				   'label_class' => 'control control--radio',
				   'decorators' => $this->radio12Dec,
				   'separator' =>'',
				   'class'  => 'printlabel',
				   'required'   => true,
				   'multiOptions'=>array(
				   '0'=>'No','1'=>'Yes'
				   ),
				   'value' => '0',
			   ));
	 $this->addElement('radio', 'tracking', array(
				   'label'      => 'Tracking',
				   'label_class' => 'control control--radio',
				   'decorators' => $this->radio12Dec,
				   'separator' =>'',
				   'class'  => 'printlabel',
				   'required'   => true,
				   'multiOptions'=>array(
				   '0'=>'No','1'=>'Yes'
				   ),
				   'value' => '0',
			   ));
			   
	  $description = $this->createElement('textarea', 'description')
			   ->setLabel('Description')
			   ->setAttrib('COLS', '25')
			   ->setAttrib('ROWS', '2')
			   ->setAttrib("class","inputfield")
			   ->setDecorators($this->element6Dec);
	   $submit = $this->createElement('submit', 'submit')
			  ->setAttrib("class","btn btn-danger btn-round")
			  ->setLabel('Add Service')
			  ->setIgnore(true)
			  ->setDecorators($this->submit3Dec);
   $this->addElements(array($description,$submit));
         return $this;
    }
	
	/**
     * Function : addeditstatuscodeForm()
	 * Params : NULL
     * Setting add edit status code form in setting
	 * Date : 23/12/2016
     * */
    public function addeditstatuscodeForm(){
			$this->setName('addeditstatuscode');
			$this->setAttrib('class', 'inputbox');
			$this->setMethod('post');
			$this->setDecorators(
			$this->form12Dec
			);
			$code_numeric = $this->createElement('text', 'code_numeric')
					->setLabel('Code Numeric :')
					->setAttrib("class","inputfield")
					->setAttrib('readonly', 'true')
					->setDecorators($this->element4Dec);
			$status_name = $this->createElement('textarea', 'status_name')
					->setLabel('Status Name :')
					->setAttrib('COLS', '20')
					->setAttrib('ROWS', '1')
					->setRequired(true)
					->addValidator('NotEmpty')
					->setAttrib("class","inputfield")
					->setDecorators($this->element4Dec);
			$display_reason = $this->createElement('textarea', 'display_reason')
					->setLabel('Display Reason :')
					->setAttrib('COLS', '20')
					->setAttrib('ROWS', '1')
					->setAttrib("class","inputfield")
					->setDecorators($this->element4Dec);

			$this->addElements(array($code_numeric,$status_name,$display_reason));

			$this->addElement('radio', 'error_type', array(
			'label'      => 'Error Type :',
			'label_class' => 'control control--radio',
			'decorators' => $this->radio6Dec,
			'separator' =>'',
			'class'  => 'printlabel',
			'required'   => true,
			'multiOptions'=>array(
			'0'=>'ERROR','1'=>'DELIVERED','2'=>'INFORMATION'
			),
			'value' => '0',
			));
			$this->addElement('radio', 'status', array(
			'label'      => 'Status Mode :',
			'label_class' => 'control control--radio',
			'decorators' => $this->radio6Dec,
			'separator' =>'',
			'class'  => 'printlabel',
			'required'   => true,
			'multiOptions'=>array(
			'0'=>'In-Active','1'=>'Active'
			),
			'value' => '1',
			));
			$this->addElement('radio', 'emailstatus', array(
			'label'      => 'Email Notification Option :',
			'label_class' => 'control control--radio',
			'decorators' => array('ViewHelper','Errors','Description',
			array('decorator' => array('FooBar' => 'HtmlTag'), 'options' => array('tag' => 'div', 'class' => 'control-group')),
			'label',array('HtmlTag', array('tag' => 'div', 'class' => 'col-sm-12 col_paddingtop'))),
			'separator' =>'',
			'class'  => 'printlabel',
			'multiOptions'=>array(
			'1'=>'Used Existing Notification','0'=>'Create New Notification'
			)
			));
			$CountryList = $this->createElement('select', 'notification_id')
					->setLabel('Exist Notification List: ')
					->setAttrib("class","inputfield")
					->addMultiOptions(array(''=>'Select Notification'))
					->addMultiOptions(commonfunction::scalarToAssociative($this->StatusModelObj->getNotifications(array('templatecategory_id'=>'3')),array('ID','Name')))
					->setDecorators(array('ViewHelper','Errors','Description',array('Label',array('requiredSuffix' => '<b style="color:#FF0000">*</b>','escape' => false)),
			array('HtmlTag',array('tag' => 'div','id'=>'exist_notification', 'class' => 'col-sm-4 col_paddingtop'))));
			$notification_name = $this->createElement('text', 'new_notification_name')
					->setLabel('New Notification Name :')
					->setAttrib("class","inputfield")
					->setDecorators(array('ViewHelper','Errors','Description',array('Label',array('requiredSuffix' => '<b style="color:#FF0000">*</b>','escape' => false)),
			array('HtmlTag',array('tag' => 'div', 'id'=>'new_notification', 'class' => 'col-sm-4 col_paddingtop'))));
			$this->addElements(array($CountryList,$notification_name));
			$this->addElement('radio', 'notification_sta', array(
			'label'      => 'Notification Status :',
			'label_class' => 'control control--radio',
			'decorators' => array('ViewHelper','Errors','Description',
			array('decorator' => array('FooBar' => 'HtmlTag'), 'options' => array('tag' => 'div', 'class' => 'control-group')),
			'label',array('HtmlTag', array('tag' => 'div','id'=>'notification_status', 'class' => 'col-sm-12 col_paddingtop'))),
			'separator' =>'',
			'class'  => 'printlabel',
			'multiOptions'=>array(
			'1'=>'ON','0'=>'OFF'
			),
			'value' => '0',
			));
			$submit = $this->createElement('submit', 'submit')
				->setAttrib("class","btn btn-danger btn-round")
				->setLabel('Add Status')
				->setIgnore(true)
				->setDecorators($this->submit3Dec);
			$this->addElements(array($submit));
			return $this;
    }
	
	
	/**
     * Function : associateforwarderForm()
	 * Params : NULL
     * Setting associate forwarder
	 * Date : 28/12/2016
     * */
    public function associateforwarderForm($data){
			$this->setName('associateforwarder');
			$this->setAttrib('class', 'inputbox');
			$this->setMethod('post');
			$this->setDecorators(
			$this->form12Dec
			);
			$this->addElement ('multiCheckbox', 'error_id',array (
				'multiOptions' => commonfunction::scalarToAssociative($this->StatusModelObj->getForwarderStatusCodeList($data),array('error_id','associateForwarderDeatil')),
				'style' => 'margin:10px'
				)
				
			);

			$submit = $this->createElement('submit', 'submit')
				->setAttrib("class","btn btn-danger btn-round")
				->setLabel('Associate Status')
				->setIgnore(true)
				->setDecorators($this->submit3Dec);
			$this->addElements(array($submit));
			return $this;
    }
	/**
     * Function : transitdetailForm()
  * Params : NULL
     * Setting transit detail
  * Date : 03/01/2017
     * */
    public function transitdetailForm(){
		   $this->setName('transitdetail');
		   $this->setAttrib('class', 'inputbox');
		   $this->setMethod('post');
		   $this->setDecorators(
		   $this->form12Dec
		   );
		   $country_info = $this->createElement('textarea', 'local_info_service')
			 ->setLabel('Country Local Info :')
			 ->setAttrib('ROWS', '3')
			 ->setAttrib('placeholder', 'Enter Local Info')
			 ->setAttrib("class","inputfield")
			 ->setDecorators($this->element12Dec);
		   $invoiceheader = new Zend_Form_Element_Note('header');
		   $invoiceheader->setvalue('Service Transit Time')
				->setDecorators($this->headerdecorator);
		   $this->addElements(array($country_info,$invoiceheader));
		   $services = $this->ModelObj->getAllServices();
		   foreach($services as $service){
		   
			if($service['parent_service']=='0'){
			 $mainservice = '';
			 }else{
				$parent = $this->ModelObj->getAllServices('0','',$service['parent_service']);
			 if(count($parent)>0){
			 $mainservice = $parent[0]['service_name'].'--';
			}
			 }
			 
			 $this->addElement('text', $service['service_id'], array(
			'label'      => $mainservice.$service['service_name'].' :',
			'class'  => 'inputfield',
			'placeholder' => 'Enter no. of Days ',
			'decorators' =>$this->element4Dec
			));
		   }
		   $submit = $this->createElement('submit', 'submit')
			->setAttrib("class","btn btn-danger btn-round")
			->setLabel('Save Datail')
			->setIgnore(true)
			->setDecorators($this->submit3Dec);
		   $this->addElements(array($submit));
		   return $this;
    }
		/**
     * Function : countrysettingForm()
	 * Params : NULL
     * Setting
	 * Date : 23/12/2016
     * */
    public function countrysettingForm(){
			$this->setName('countrysetting');
			$this->setAttrib('class', 'inputbox');
			$this->setMethod('post');
			$this->setDecorators(
			$this->form12Dec
			);
			$this->addElement('radio', 'postcode_validation', array(
			'label'      => 'Postcode Validation :',
			'label_class' => 'control control--radio',
			'decorators' => $this->decorator,
			'separator' =>'',
			'class'  => 'printlabel',
			'multiOptions'=>array(
			'1'=>'ON','0'=>'OFF'
			),
			'value' => '1',
			));
			$notification_name = $this->createElement('text', 'website_link')
					->setLabel('Website Link :')
					->setAttrib("class","inputfield")
					->setDecorators($this->decorator);
			$submit = $this->createElement('submit', 'submit')
				->setAttrib("class","btn btn-danger btn-round")
				->setLabel('Country Setting')
				->setIgnore(true)
				->setDecorators($this->submit3Dec);
			$this->addElements(array($notification_name,$submit));
			return $this;
    }
}

