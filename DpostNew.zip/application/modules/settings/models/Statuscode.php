<?php
class settings_Model_Statuscode extends Zend_Custom
{
     /**
         * get master status code list 
         * Function : getmastererror()
		 * Date : 29/12/2016
         * Here we get master status list
    **/	 
	 public  function getmastererror(){
		try{
		$where_filter =1;
			   if(isset($this->getData['token']) != "") {
					  $where_filter = "SM.master_id ='".Zend_Encript_Encription:: decode($this->getData['token'])."'";
				}
			$select = $this->_db->select()
							->from(array('SM'=>STATUS_MASTER),array('SM.*'))
							->joinleft(array('MNT' =>MAIL_NOTIFY_TYPES),'MNT.notification_id=SM.notification_id AND MNT.templatecategory_id =3',array('MNT.notification_name'))
							->where($where_filter)
							->order('SM.status_name ASC');			
			//echo $select->__tostring(); die;				
			$result =  $this->getAdapter()->fetchAll($select);
			return $result;
			}catch (Exception $e) {
					 $this->_logger->info('Class-'.__CLASS__.',Function-'.__FUNCTION__.',Line-'.__LINE__.',Error-'.$e->getMessage());
			}
	  
	  }
  /**
	 * set master status code 
	 * Function : setMasterstatus()
	 * Date : 26/12/2016
	 * Here we update master status error type
  **/	  
	public function setStatusType(){
	  try{
	  print_r($this->getData);
	  die;
			$this->getData['modify_by'] = $this->Useconfig['user_id'];
			$this->getData['modify_ip'] = commonfunction::loggedinIP();
			$this->getData['modify_date'] = '';
		if(isset($this->getData['table']) && $this->getData['table'] == '0'){
				$where = 'master_id ='.Zend_Encript_Encription:: decode($this->getData['errorID']);
				return ($this->UpdateInToTable(STATUS_MASTER,array($this->getData),$where)) ? TRUE : FALSE;
		}elseif(isset($this->getData['table']) && $this->getData['table'] == STATUS_LIST){
				$where = 'error_id ='.Zend_Encript_Encription:: decode($this->getData['errorID']);
				return ($this->UpdateInToTable(STATUS_LIST,array($this->getData),$where)) ? TRUE : FALSE;
		}else{
				return false;
			
		}
	  }catch (Exception $e) {
					 $this->_logger->info('Class-'.__CLASS__.',Function-'.__FUNCTION__.',Line-'.__LINE__.',Error-'.$e->getMessage());
			}
   }
  
     /**
	 * add edit status 
	 * Function : addeditstatuscode()
	 * Date : 27/12/2016
	 * Here we can add and edit Status Code
    **/	 
    public function AddEditStatusCode(){
		try{
			if(isset($this->getData['emailstatus'])){
					if($this->getData['emailstatus'] == '0' && isset($this->getData['new_notification_name']) && $this->getData['new_notification_name'] != ''){
						$inserted = $this->_db->insert(MAIL_NOTIFY_TYPES,array('notification_name' => $this->getData['new_notification_name'],'notification_staus' => $this->getData['notification_sta'],'admin_display'=>'1','templatecategory_id'=>3));
						$this->getData['notification_id'] = ($inserted)?$this->_db->lastInsertId():'0';
					}
				}else{
					unset($this->getData['notification_id']);
				}
			if(isset($this->getData['mode']) && $this->getData['mode'] == 'add'){
				return ($this->insertInToTable(STATUS_MASTER,array($this->getData))) ? TRUE : FALSE;
			}else{
				$where = 'master_id ='.Zend_Encript_Encription:: decode($this->getData['token']);
				$this->getData['modify_by'] = $this->Useconfig['user_id'];
				$this->getData['modify_ip'] = commonfunction::loggedinIP();
				$this->getData['modify_date'] = '';
				return ($this->UpdateInToTable(STATUS_MASTER,array($this->getData),$where)) ? TRUE : FALSE;
			}
		}catch (Exception $e) {
				 $this->_logger->info('Class-'.__CLASS__.',Function-'.__FUNCTION__.',Line-'.__LINE__.',Error-'.$e->getMessage());
		}
       }
     /**
	 * Get notification list 
	 * Function : getNotifications()
	 * Date : 28/12/2016
	 * Here we get notification list 
    **/	  
	public function getNotifications($data=array()){
		$where_filter = "1 ";
		 if(!empty($data['templatecategory_id'])){
			 $where_filter = "NT.templatecategory_id ='3'";
		 }
		$select = $this->_db->select()
					->from(array('NT'=>MAIL_NOTIFY_TYPES),array('ID'=>"NT.notification_id",'Name'=>'NT.notification_name','category_id'=>'NT.templatecategory_id'))
					 ->where('NT.notification_staus ="1" AND '.$where_filter)
					->order('NT.notification_name ASC');
						//echo $select->__tostring();die;
		return $this->getAdapter()->fetchAll($select);
	}
     /**
	 * Get notification list 
	 * Function : getNewStatusCode()
	 * Date : 28/12/2016
	 * Here we get new status code
    **/	
	  public function getNewStatusCode()
	  {
		$select = $this->_db->select() 
				 ->from(array('MS'=>STATUS_MASTER),array("MS.code_numeric"))
				 ->order('master_id DESC')
				 ->limit('1');
				 //echo $select->__tostring();die;
		 $result =  $this->getAdapter()->fetchrow($select);
		 $start     = substr($result['code_numeric'],0,2);
							 $newCode   = (substr($result['code_numeric'],2)+1); 
							 $newStatus = (strlen($newCode)<3) ? $start.'0'.$newCode : $start.$newCode; 
		 return $newStatus;
	  }
     /**
	 * Get Forwarder Status Code List
	 * Function : getForwarderStatusCodeList()
	 * Date : 28/12/2016
    **/	
	  public function getForwarderStatusCodeList($data = array())
	  {		$where = '1';
			if(isset($data['mode']) && $data['mode'] = 'associeateforwarder'){
				$where = 'PEL.error_status = "1" AND PEL.delete_status = "0"';
			}
			$select = $this->_db->select()
					->from(array('PEL' =>STATUS_LIST),array('PEL.*','concat(FT.forwarder_name," -- ",PEL.error_desc) as associateForwarderDeatil'))
					->joininner(array('FT' =>FORWARDERS),'FT.forwarder_id = PEL.forwarder_id',array('FT.forwarder_name'))
					->joinleft(array('MS' =>STATUS_MASTER),'MS.master_id = PEL.master_id',array('MS.status_name as masterStatus'))
					->where($where);				
            return $this->getAdapter()->fetchAll($select);
	  }
	  
	 /**
	 * Get selected Forwarder Status Code List
	 * Function : getSelectedForwarderStatus()
	 * Date : 28/12/2016
    **/	
	  public function getSelectedForwarderStatus()
	  {		$where = '1';
			if(isset($this->getData['mode']) && $this->getData['mode'] = 'associeateForwarder' && isset($this->getData['token'])){
				$where = 'PEL.error_status = "1" AND delete_status = "0" AND PEL.master_id = "'.Zend_Encript_Encription:: decode($this->getData['token']).'"';
			}
			$select = $this->_db->select()
					->from(array('PEL' =>STATUS_LIST),array('error_id'))
					->where($where);	
				//echo $select->__tostring();die;					
            return $this->getAdapter()->fetchAll($select);
	  }
	 /**
	 * Update Associate Forwarder Code
	 * Function : UpdateAssociateForwarderCode()
	 * Date : 28/12/2016
    **/	
	public function UpdateAssociateForwarderCode(){
		try{
			$wheredata = $this->getData['error_id'];
			$this->getData['master_id'] = Zend_Encript_Encription:: decode($this->getData['token']);
			$this->getData['modify_by'] = $this->Useconfig['user_id'];
			$this->getData['modify_ip'] = commonfunction::loggedinIP();
			$this->getData['modify_date'] = '';
			//echo "<pre>"; print_r($this->getData); die;
			unset($this->getData['error_id']);
			foreach($wheredata as $where){
				$update = $this->UpdateInToTable(STATUS_LIST,array($this->getData),'error_id="'.$where.'"');
			}
			return ($update)?true : false;
		}catch(Exception $e) {
				 $this->_logger->info('Class-'.__CLASS__.',Function-'.__FUNCTION__.',Line-'.__LINE__.',Error-'.$e->getMessage());
		}
	}
	  	
}

?>