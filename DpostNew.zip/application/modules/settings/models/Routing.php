<?php
class settings_Model_Routing extends Zend_Custom
{ 

   public function getweightClass(){
       $where = $this->LevelAsDepots();
	   if(isset($this->getData['country_id']) && $this->getData['country_id']>0){
	      $where .= " AND WC.country_id='".$this->getData['country_id']."'";
	   }
	   if(isset($this->getData['user_id']) && $this->getData['user_id']!=''){
	     $where .= " AND WC.user_id='".Zend_Encript_Encription::decode($this->getData['user_id'])."'";
	   }
	   
	   $select = $this->_db->select()
	   					->from(array('WC'=>ROUTING_WEIGHT_CLASS),array('service_id','country_id','GROUP_CONCAT(CONCAT(min_weight,"--to--",max_weight)) as weight_class','GROUP_CONCAT(class_id) as class_ids'))
						->joininner(array('CT'=>COUNTRIES),"CT.country_id=WC.country_id",array('country_name'))
						->joininner(array('ST'=>SERVICES),"ST.service_id=WC.service_id",array('service_name'))
						->joininner(array('AT'=>USERS_DETAILS),"AT.user_id=WC.user_id",array('company_name'))
						->joinleft(array('PSV'=>SERVICES),"PSV.service_id=ST.parent_service", array('service_name AS parent_name'))
						->where("1".$where)
						->group("WC.country_id")
						->group("WC.service_id")
						->group("WC.user_id")
						->order(new Zend_Db_Expr("CASE WHEN ST.parent_service=0 THEN ST.service_id ELSE ST.parent_service END"))
						->order("ST.service_id");
			//echo $select->__toString();die;
		return $this->getAdapter()->fetchAll($select);				
   }
   public function CreateWeightClass(){ //echo "<pre>";print_r($this->getData);die;
	  global $objSession;
	  $this->getData['user_id']  = Zend_Encript_Encription::decode($this->getData['user_id']);
	  foreach($this->getData['country_id'] as $key=>$country_id){
	    foreach($this->getData['service_id'] as $servicekey=>$service_id){
	     foreach($this->getData['min_weight'] as $weightkey=>$min_weight){
	         if($min_weight!='' && $this->getData['max_weight'][$weightkey]!=''){
				 $select = $this->_db->select()
									->from(array('WC'=>ROUTING_WEIGHT_CLASS),array('COUNT(1) AS CNT'))
									->where("WC.country_id='".$country_id."' AND WC.service_id='".$service_id."' AND user_id ='".$this->getData['user_id']."'")
									->where("((WC.min_weight='".($min_weight)."' AND WC.max_weight='".$this->getData['max_weight'][$weightkey]."') OR  (WC.min_weight BETWEEN '".($min_weight+0.0001)."' AND '".($this->getData['max_weight'][$weightkey]-0.0001)."') OR (WC.max_weight BETWEEN '".($min_weight+0.0001)."' AND '".($this->getData['max_weight'][$weightkey]-0.0001)."'))");
				 //echo $select->__toString();die;
				 $validate = $this->getAdapter()->fetchRow($select);
				 if($validate['CNT']<=0){	
				   $this->_db->insert(ROUTING_WEIGHT_CLASS,array('country_id'=>$country_id,'service_id'=>$service_id,'min_weight'=>$min_weight,'max_weight'=>$this->getData['max_weight'][$weightkey],'user_id'=>$this->getData['user_id']));
				   $objSession->successMsg .= 'Weight class '.$min_weight.'-'.$this->getData['max_weight'][$weightkey].' Added<br>';
				 }else{
					$objSession->errorMsg .= 'Weight class '.$min_weight.'-'.$this->getData['max_weight'][$weightkey].' Already Exist<br>';
				 }
		   } 
	     }
		}  
	  }
   }
   
   public function AddRouting(){ //echo "<pre>";print_r($this->getData);die;
        global $objSession;
		$this->getData['user_id']  = Zend_Encript_Encription::decode($this->getData['user_id']);
		foreach($this->getData['routingdata'] as $weightclass=>$routingprices){
		      $explodeweight = explode('-',$weightclass);
			  foreach($routingprices as $routingprice){
						 if($routingprice['price']>0 && $routingprice['forwarder_id']>0){
						    $select = $this->_db->select()
													->from(array('RT'=>ROUTING),array('COUNT(1) AS CNT'))
													->joininner(array('RP'=>ROUTING_POSTCODE),"RT.routing_id=RP.routing_id",array())
													->where("RT.country_id='".$this->getData['country_id']."' AND user_id ='".$this->getData['user_id']."'")
													->where("RP.beginPostCode IN('".commonfunction::implod_array($this->getData['beginPostCode'],"','")."') AND RP.endPostCode IN('".commonfunction::implod_array($this->getData['endPostCode'],"','")."')")
													->where("RT.service_id='".$routingprice['service_id']."'")
													->where("((RT.min_weight=".$explodeweight[0]." AND RT.max_weight=".$explodeweight[1].") OR  (RT.min_weight BETWEEN ".($explodeweight[0]+0.0001)." AND ".($explodeweight[1]-0.0001).") OR (RT.max_weight BETWEEN ".($explodeweight[0]+0.0001)." AND ".($explodeweight[1]-0.0001)."))");
											//echo $select->__toString();die;
							$validate = $this->getAdapter()->fetchRow($select);
							$services = $this->getServiceDetails($routingprice['service_id'],1);
							$forwarder_name = $this->ForwarderName($routingprice['forwarder_id']);
						if($validate['CNT']<=0){
							$this->_db->insert(ROUTING,array('user_id'=>$this->getData['user_id'],
															'country_id'=>$this->getData['country_id'],
															'min_weight'=>$explodeweight[0],
															'max_weight'=>$explodeweight[1],
															'service_id'=>$routingprice['service_id'],
															'forwarder_id'=>$routingprice['forwarder_id'],
															'depot_price'=>$routingprice['price'],
															'created_date'=>new Zend_Db_Expr('NOW()'),
															'created_by'=>$this->Useconfig['user_id'],
															'created_ip'=>commonfunction::loggedinIP())); 
															
							$routing_id = $this->getAdapter()->lastInsertId();
							foreach($this->getData['beginPostCode'] as $key=>$beginPostcode){
							    if($key==0 && $beginPostcode!='' && $this->getData['endPostCode'][$key]!=''){
								   $this->_db->update(ROUTING,array('special_routing'=>1),"routing_id='".$routing_id."'");
								} 
								$this->_db->insert(ROUTING_POSTCODE,array('routing_id'=>$routing_id,
																			'beginPostCode'=>$beginPostcode,
																			'endPostCode'=>$this->getData['endPostCode'][$key]));
							}
							$objSession->successMsg .= '<br>Routing Added Details: '.$services['service_name'].' Added for weight-'.$explodeweight[0].'-to-'.$explodeweight[1].' with forwarder-'.$forwarder_name;
						   }else{
						     $objSession->errorMsg .= '<br>Routing Not added: '.$services['service_name'].' for weight-'.$explodeweight[0].'-to-'.$explodeweight[1].' due to duplicacy';
						   }	
					  } 
				}
		  }		
   }
   
   public function getRoutings(){
   		$where = $this->LevelAsDepots();
		   if(isset($this->getData['country_id']) && $this->getData['country_id']>0){
			  $where .= " AND RT.country_id='".$this->getData['country_id']."'";
		   }
		   if(isset($this->getData['user_id']) && $this->getData['user_id']!=''){
			 $where .= " AND RT.user_id='".Zend_Encript_Encription::decode($this->getData['user_id'])."'";
		   }
		   if(isset($this->getData['service_id']) && $this->getData['service_id']>0){
			 $where .= " AND RT.service_id='".$this->getData['service_id']."'";
		   }
		   if(isset($this->getData['forwarder_id']) && $this->getData['forwarder_id']>0){
			 $where .= " AND RT.forwarder_id='".$this->getData['forwarder_id']."'";
		   }
		   if(isset($this->getData['min_weight'])  && isset($this->getData['max_weight']) && $this->getData['min_weight']!='' && $this->getData['max_weight']!=''){
			 $where .= " AND (RT.min_weight>='".$this->getData['min_weight']."' AND RT.max_weight<='".$this->getData['max_weight']."')";
		   }
        $select = $this->_db->select()
	   					->from(array('RT'=>ROUTING),array('min_weight','max_weight','GROUP_CONCAT(RT.routing_id) AS routing_id'))
						->joininner(array('RP'=>ROUTING_POSTCODE),"RT.routing_id=RP.routing_id",array('GROUP_CONCAT(DISTINCT beginPostCode) AS beginPostCode','GROUP_CONCAT(DISTINCT endPostCode) AS endPostCode'))
						->joininner(array('CT'=>COUNTRIES),"CT.country_id=RT.country_id",array('country_name'))
						->joininner(array('FT'=>FORWARDERS),"FT.forwarder_id=RT.forwarder_id",array(''))
						->joininner(array('ST'=>SERVICES),"ST.service_id=RT.service_id",array(''))
						->joininner(array('AT'=>USERS_DETAILS),"AT.user_id=RT.user_id",array('company_name'))
						->joinleft(array('PS'=>SERVICES),"PS.service_id=ST.parent_service",array(''))
						->where("1".$where)
						->group(array('RT.country_id','RT.user_id','RT.min_weight','RT.max_weight','RT.special_routing'))
						->order("RT.max_weight ASC")
						->order("RT.min_weight ASC")
						->order("CT.country_name ASC")
						->order("AT.company_name ASC");
						//echo $select->__toString();die;
		return $this->getAdapter()->fetchAll($select);
   }
   public function getRoutingServices($routing_id){
          $select = $this->_db->select()
	   					->from(array('RT'=>ROUTING),array('customer_price','depot_price'))
						->joininner(array('FT'=>FORWARDERS),"FT.forwarder_id=RT.forwarder_id",array('forwarder_name'))
						->joininner(array('ST'=>SERVICES),"ST.service_id=RT.service_id",array('service_name'))
						->joinleft(array('PS'=>SERVICES),"PS.service_id=ST.parent_service",array('service_name AS parent_service'))
						->where("RT.routing_id IN(".$routing_id.")");
						//echo $select->__toString();die;
		return $this->getAdapter()->fetchAll($select);
		 
   }
   public function getRoutingByRoutingID(){
        $select = $this->_db->select()
						->from(array('RT'=>ROUTING),array('*'))
						->joininner(array('CT'=>COUNTRIES),"CT.country_id=RT.country_id",array('country_name'))
						->joininner(array('UD'=>USERS_DETAILS),"UD.user_id=RT.user_id",array('company_name'))
						->where("RT.routing_id IN(".$this->getData['routing_id'].")")
						->group("RT.routing_id");//echo $select->__toString();die;
		$routings =  $this->getAdapter()->fetchRow($select);
		
		$select = $this->_db->select()
						->from(array('RT'=>ROUTING),array('*',new Zend_Db_Expr('(SELECT GROUP_CONCAT(CONCAT(RP.beginPostCode,"-",RP.endPostCode)) FROM '.ROUTING_POSTCODE.' AS RP WHERE RP.routing_id=RT.routing_id GROUP BY RP.routing_id)  AS begin_endPostCode')))
						->joininner(array('ST'=>SERVICES),"ST.service_id=RT.service_id",array('service_name'))
						->joinleft(array('PS'=>SERVICES),"PS.service_id=ST.parent_service",array('service_name AS parent_service'))
						->where("RT.routing_id IN(".$this->getData['routing_id'].")");//echo $select->__toString();die;
		$Services =  $this->getAdapter()->fetchAll($select);
		//echo "<pre>";print_r(array('Routing'=>$routings,'Services'=>$services));die;
		return array('Routing'=>$routings,'Services'=>$Services);
   }
   public function EditRouting(){
       //echo "<pre>";print_r($this->getData);die;
	    global $objSession;
		   foreach($this->getData['routingdata'] as $routings){ 
			 foreach($routings as $routingprices){
			  if($routingprices['forwarder_id']>0){
			     $this->_db->update(ROUTING,array('forwarder_id'=>$routingprices['forwarder_id'],'depot_price'=>$routingprices['price']),"routing_id='".$routingprices['routing_id']."'");
			   }else{
			       $objSession->errorMsg = 'Can not update Routing without Forwarder!!';
				   return true;
			   }
		 	 }	
	    }
		$objSession->successMsg = 'Routing updated successfully!!';	
   }
   
   public function UpdateCustomer(){
	    global $objSession;
	   foreach($this->getData['routingdata'] as $routings){
	     foreach($routings as $routingprices){
		      $this->_db->update(ROUTING,array('customer_price'=>$routingprices['price']),"routing_id='".$routingprices['routing_id']."' AND service_id='".$routingprices['service_id']."'");
			 } 
		}
		$objSession->successMsg = 'Customer Price updated successfully!!';
   }
   public function getSpecialPriceCustomers(){
       $select = $this->_db->select()
						  ->from(array('UT'=>USERS),array('*'))
						  ->joininner(array('UD'=>USERS_DETAILS),"UT.user_id=UD.user_id",array('user_id','company_name','postalcode','city'))
						  ->joininner(array('US'=>USERS_SETTINGS),"US.user_id=UD.user_id",array(''))
						  ->where('UT.user_status=?', '1')
						  ->where('UT.delete_status=?', '0')
						  ->where('UT.level_id=?', 5)
						  ->where('US.special_price=?', '1');
		 switch($this->Useconfig['level_id']){
		    case 4:
			  $select->where('UD.parent_id=?',$this->Useconfig['user_id']);
			break;
			case 5:
			   $select->where('UD.user_id=?',$this->Useconfig['user_id']);
			break;
			case 6:
			$depot_id = $this->getDepotID($this->user_session['user_id']);
			$this->select->where->equalTo('UD.parent_id', $depot_id);
			break;
			case 10:
			$parent_id = $this->getDepotID($this->user_session['user_id']);
			$this->select->where->equalTo('UD.user_id', $parent_id);
			break;
		}
		
		 $select->order("UD.company_name ASC");				  
		return $this->getAdapter()->fetchAll($select);
   }
   
   public function UpdateSpecial(){ //echo "<pre>";print_r($this->getData['routingdata']);die;
       global $objSession;
       foreach($this->getData['routingdata'] as $routings){
		    foreach($routings as $specialprices){
			 $select = $this->_db->select()
	   					->from(array('SP'=>ROUTING_SPECIAL_PRICE),array('*'))
						->where("SP.routing_id='".$specialprices['routing_id']."' AND  SP.user_id='".$this->getData['user_id']."' AND  SP.service_id='".$specialprices['service_id']."'");
		     $specialPrice =  $this->getAdapter()->fetchRow($select);
			 if(!empty($specialPrice)){
			    $this->_db->update(ROUTING_SPECIAL_PRICE,array('special_price'=>$specialprices['price']),"routing_id='".$specialprices['routing_id']."' AND service_id='".$specialprices['service_id']."' AND user_id='".$this->getData['user_id']."'");
			 }else{
			   $this->_db->insert(ROUTING_SPECIAL_PRICE,array_filter(array('routing_id'=>$specialprices['routing_id'],'user_id'=>$this->getData['user_id'],'service_id'=>$specialprices['service_id'],'special_price'=>$specialprices['price'])));
			 }
		  }	  
		}
		$objSession->successMsg = 'Scpecial Price updated successfully!!';
   }
   
   public function getSpecialPrices(){ 
        $select = $this->_db->select()
	   					->from(array('SP'=>ROUTING_SPECIAL_PRICE),array('*'))
						->where("SP.routing_id IN(".$this->getData['routing_id'].") AND  SP.user_id='".$this->getData['user_id']."'");
		$services =  $this->getAdapter()->fetchAll($select);
		$dataPrice = array();
		foreach($services as $servicepri){
		  $dataPrice[$servicepri['service_id']][$servicepri['routing_id']]  = $servicepri['special_price'];
		}
		return $dataPrice;
   }
   
   public function getAllServicesList(){
       try{
	    $select = $this->_db->select()
                ->from(array('SV'=>SERVICES), array('*'))
				->joinleft(array('PSV'=>SERVICES),"PSV.service_id=SV.parent_service", array('service_name AS parent_name'))
				->where("SV.status='1'")
				->order("SV.service_id ASC");//print_r($select->__toString());die;
       }catch(Exception $e){
	     echo $e->getMessage();die;
	   }
	  return $this->getAdapter()->fetchAll($select);
	   
   }
   
   public function deleteclass(){
        global $objSession;
		if(isset($this->getData['class_ids']) && $this->getData['class_ids']!=''){
			$this->_db->delete(ROUTING_WEIGHT_CLASS,"class_id IN(".$this->getData['class_ids'].")");
			$objSession->successMsg .= 'Weight Class(s) Deleted successfully!';
		}
		return true;
   }
   
   public function deleterouting(){
        global $objSession;
	   $select = $this->_db->select()
								->from(array('RT'=>ROUTING),array('*'))
								->where("routing_id IN(".$this->getData['routing_id'].")");
							//echo $select->__toString();die;
		$routings = $this->getAdapter()->fetchAll($select);
		foreach($routings as $routing){
			$routing['deleted_by'] = $this->Useconfig['user_id'];
		    $routing['deleted_date'] = commonfunction::DateNow();
			$routing['deleted_ip'] = commonfunction::loggedinIP();
			$this->insertInToTable(ROUTING_DELETED,array($routing));
			$this->_db->delete(ROUTING,"routing_id='".$routing['routing_id']."'");
			$this->_db->delete(ROUTING_POSTCODE,"routing_id='".$routing['routing_id']."'");
			$objSession->successMsg = 'Routing Deleted successfully!!';
		}
   }
   
   public function serviceweightClass(){
       $where = $this->LevelAsDepots();
	   $select = $this->_db->select()
	   					->from(array('RT'=>ROUTING),array('*'))
						->joininner(array('RP'=>ROUTING_POSTCODE),"RT.routing_id=RP.routing_id",array('GROUP_CONCAT(DISTINCT beginPostCode) AS beginPostCode','GROUP_CONCAT(DISTINCT endPostCode) AS endPostCode'))
						->joininner(array('CT'=>COUNTRIES),"CT.country_id=RT.country_id",array('country_name'))
						->joininner(array('FT'=>FORWARDERS),"FT.forwarder_id=RT.forwarder_id",array('forwarder_name'))
						->joininner(array('ST'=>SERVICES),"ST.service_id=RT.service_id",array(''))
						->joininner(array('AT'=>USERS_DETAILS),"AT.user_id=RT.user_id",array('company_name'))
						->joinleft(array('PS'=>SERVICES),"PS.service_id=ST.parent_service",array(''))
						->where("RT.country_id='".$this->getData['country_id']."' AND RT.service_id='".$this->getData['service_id']."'".$where)
						->group("RT.routing_id")
						->order("RT.max_weight ASC")
						->order("RT.min_weight ASC");
						//echo $select->__toString();die;
		return $this->getAdapter()->fetchAll($select);
   }
   public function servicespecialPrice(){
       $where = $this->LevelAsDepots();
	   $select = $this->_db->select()
	   					->from(array('RT'=>ROUTING),array('*'))
						->joininner(array('RP'=>ROUTING_POSTCODE),"RT.routing_id=RP.routing_id",array('GROUP_CONCAT(DISTINCT beginPostCode) AS beginPostCode','GROUP_CONCAT(DISTINCT endPostCode) AS endPostCode'))
						->joinleft(array('SP'=>ROUTING_SPECIAL_PRICE),"SP.routing_id=RT.routing_id AND SP.service_id=RT.service_id AND SP.user_id='".$this->getData['user_id']."'",array('special_price'))
						->joininner(array('CT'=>COUNTRIES),"CT.country_id=RT.country_id",array('country_name'))
						->joininner(array('FT'=>FORWARDERS),"FT.forwarder_id=RT.forwarder_id",array('forwarder_name'))
						->joininner(array('ST'=>SERVICES),"ST.service_id=RT.service_id",array(''))
						->joininner(array('AT'=>USERS_DETAILS),"AT.user_id=RT.user_id",array('company_name'))
						->joinleft(array('PS'=>SERVICES),"PS.service_id=ST.parent_service",array(''))
						->where("RT.country_id='".$this->getData['country_id']."' AND RT.service_id='".$this->getData['service_id']."'".$where)
						->group("RT.routing_id")
						->order("RT.max_weight ASC")
						->order("RT.min_weight ASC");
						//echo $select->__toString();die;
		return $this->getAdapter()->fetchAll($select);
   }
}

