<?php
ini_set('display_errors','1');
class Settings_StatuscodeController extends Zend_Controller_Action
{

     public $Request = array();
     public $ModelObj = null;
	 public $formObj  = NULL;
	
     /**
	 * Auto load NameSpace and create objects 
	 * Function : init()
	 * Auto call and loads the default namespace and create object of model and form
	 **/
     public function init()
     { 
		try{
			$this->Request = $this->_request->getParams();
			$this->ModelObj = new settings_Model_Statuscode();
			$this->formObj = new settings_Form_Settings();
			$this->ModelObj->getData  = $this->Request;
			$this->view->ModelObj = $this->ModelObj;
			$this->_helper->layout->setLayout('main');
	   }catch(Exception $e){
	    echo $e->getMessage();
	   }
     }

    /**
         * Show Master Listing 
         * Function : codelistAction()
         * Here we can add master Status
    **/
	public function codelistAction(){
	     $this->view->errors = $this->ModelObj->getmastererror();
    }
      /**
         * set master status code 
         * Function : setmasterstatus()
		 * Date : 26/12/2016
         * Here we update master status error type
	  **/
		 
		public function setmasterstatusAction(){
            print_r($this->ModelObj->setStatusType());
			exit;
        }     
    /**
         * add edit status 
         * Function : addeditstatuscodeAction()
		 * Date : 27/12/2016
         * Here we can add and edit Status Code
    **/	 
     public function addeditstatuscodeAction(){
	    $this->_helper->layout->setLayout('popup');
		   global $objSession;
		   $this->formObj->addeditstatuscodeForm();
		   if($this->Request['mode'] == 'add' && !isset($this->Request['token'])){
			  $this->view->title = 'Add Status Code';
			  $this->formObj->addeditstatuscodeForm()->code_numeric->setValue($this->ModelObj->getNewStatusCode());
			  if($this->_request->isPost() && !empty($this->Request['submit'])){
			 if($this->formObj->isValid($this->Request)){
			  $result=$this->ModelObj->AddEditStatusCode();
			  if($result){
				$objSession->successMsg = "Status Code Added Successfully !!";
			  }else{
			    $objSession->successMsg = "Something is wrong !!";
			  }
			  echo '<script type="text/javascript">parent.window.location.reload();
				  parent.jQuery.fancybox.close();</script>';
				  exit(); 
			 }else{
			  $this->formObj->populate($this->Request);
			 }
			}
			  
		   }elseif($this->Request['mode'] == 'edit' && isset($this->Request['token'])){
			$this->view->title = 'Edit Status Code';
			$this->formObj->addeditstatuscodeForm()->submit->setLabel('Update Status Code');
			if($this->_request->isPost() && !empty($this->Request['submit'])){
			 if($this->formObj->isValid($this->Request)){
			  $result=$this->ModelObj->AddEditStatusCode();
			  if($result){
				$objSession->successMsg = "Status Code Updated Successfully !!";
			  }else{
			    $objSession->successMsg = "Something is wrong !!";
			  }
			  echo '<script type="text/javascript">parent.window.location.reload();
				  parent.jQuery.fancybox.close();</script>';
				  exit(); 
			 }else{
			  $this->formObj->populate($this->Request);
			 }
			}else{
			 $fatchRowData = $this->ModelObj->getmastererror();
			 $this->formObj->populate($fatchRowData[0]);
			}
		   }
		   $this->view->addeditstatuscode = $this->formObj;
     }
	 
	 /**
	 * Show forwarder status code list
	 * Function : forwarderstatuslistAction()
	 * Date : 29/12/2016
     **/
	public function forwarderstatuslistAction(){
	     $this->view->forwarderstatusList = $this->ModelObj->getForwarderStatusCodeList();
    }
	
	/**
	 * Associate master status with forwarder status
	 * Function : associateforwarderAction()
	 * Date : 29/12/2016
     **/
	public function associateforwarderAction(){
		$this->_helper->layout->setLayout('popup');
		global $objSession;
		   $this->formObj->associateforwarderForm($this->Request);
		   if($this->Request['mode'] == 'associeateforwarder' && isset($this->Request['token'])){
		  
			if($this->_request->isPost() && !empty($this->Request['submit'])){
			 if($this->formObj->isValid($this->Request)){
			  $result = $this->ModelObj->UpdateAssociateForwarderCode();
			  if($result){
				$objSession->successMsg = "Associate Forwarder Status Code Updated Successfully !!";
			  }else{
			    $objSession->successMsg = "Something is wrong !!";
			  }
			  echo '<script type="text/javascript">parent.window.location.reload();
				  parent.jQuery.fancybox.close();</script>';
				  exit(); 
			 }else{
			  $this->formObj->populate($this->Request);
			 }
			}else{
			 $populateData['error_id'] = array_map('current',$this->ModelObj->getSelectedForwarderStatus());
			 $this->formObj->populate($populateData);
			}
		   }
	      $this->view->associateforwarder =  $this->formObj;
    }
  
}







