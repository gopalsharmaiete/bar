<?php

class Hubcheckin_Model_Hubcheckin extends Zend_Custom
{


}

