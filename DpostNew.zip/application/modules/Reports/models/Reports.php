<?php

class Reports_Model_Reports extends Zend_Custom
{


}

