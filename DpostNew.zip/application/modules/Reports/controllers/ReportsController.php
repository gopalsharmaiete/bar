<?php

class Reports_ReportsController extends Zend_Controller_Action
{
	public $Request = array();
    public function init()
    {
        try{	
			$this->Request = $this->_request->getParams();
			$this->ModelObj = new Reports_Model_Reports();
			$this->ModelObj->getData  = $this->Request;
			$this->view->ModelObj = $this->ModelObj;
			$this->_helper->layout->setLayout('main');
	 }catch(Exception $e){
	    echo $e->getMessage();die;
	 }	
    }

    public function indexAction()
    {
        // action body
    }

    public function graphicalreportAction()
    {
        // action body
    }

    public function differencesAction()
    {
        // action body
    }

    public function forwarderreportAction()
    {
        // action body
    }

    public function wrongaddressAction()
    {
        // action body
    }


}









