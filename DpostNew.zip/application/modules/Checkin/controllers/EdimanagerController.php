<?php
ini_set('display_errors','1');
class Checkin_EdimanagerController extends Zend_Controller_Action
{

    public $Request = array();

    public $ModelObj = null;

    public function init()
    {
       try{	
			$this->Request = $this->_request->getParams();
			$this->ModelObj = new Checkin_Model_Edimanager();
			$this->ModelObj->getData  = $this->Request;
			$this->view->ModelObj = $this->ModelObj;
			$this->_helper->layout->setLayout('main');
			$this->view->Request = $this->Request;
	  }catch(Exception $e){
	    echo $e->getMessage();die;
	  }
    }

    public function indexAction()
    {
        // action body
    }

    public function forwardermanifestAction()
    {
	   global $objSession,$labelObj;
	   if(isset($objSession->ManifestFile)){
		 $labelObj->_filePath = $objSession->ManifestFile; 
		 unset($objSession->ManifestFile);
		 $labelObj->printLabel();
	  }	
       if($this->_request->isPost() && (isset($this->Request['forwarder_manifest']) || isset($this->Request['hub_manifest']))){
	      $this->ModelObj->GenerateEDIAndManifest();
		  $this->_redirect($this->_request->getControllerName().'/'.$this->_request->getActionName());
	   }
	   $this->view->records  = $this->ModelObj->forwarderManifest();
	   $this->view->forwarder =  $this->ModelObj->getForwarderList();
	   $this->view->depotlist =  $this->ModelObj->getDepotList();
    }

    public function forwardermanifestviewAction()
    {
	    global $objSession,$labelObj;
	   if(isset($objSession->ManifestFile)){
		 $labelObj->_filePath = $objSession->ManifestFile; 
		 unset($objSession->ManifestFile);
		 $labelObj->printLabel();
	  }	
		$this->_helper->layout->setLayout('popup');
		 if($this->_request->isPost() && (isset($this->Request['forwarder_manifest']) || isset($this->Request['hub_manifest']))){
		     $this->ModelObj->GenerateEDIAndManifest();
			 $this->_redirect($this->_request->getControllerName().'/'.$this->_request->getActionName());
		 }
		$this->view->records  = $this->ModelObj->forwarderManifest(false);
		$this->view->depotlist =  $this->ModelObj->getDepotList();
    }

    public function edihistoryAction()
    {
         $this->view->records  = $this->ModelObj->ediHistory();
		$this->view->forwarder =  $this->ModelObj->getForwarderList();
    }
	
	public function ediupdownAction(){
		 switch($this->Request['mode']){
		    case 'Download':
			    $this->ModelObj->DownloadEDI();  
			break;
			case 'Upload':
				$this->ModelObj->UploadEDI();
				$this->_redirect($this->_request->getControllerName().'/edihistory');
			break;
		 }
	}

}





