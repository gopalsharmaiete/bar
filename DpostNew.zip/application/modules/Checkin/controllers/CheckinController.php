<?php 
ini_set('display_errors','1');
class Checkin_CheckinController extends Zend_Controller_Action
{

    public $Request = array();

    public $ModelObj = null;

    public function init()
    {
       try{	
			$this->Request = $this->_request->getParams();
			$this->ModelObj = new Checkin_Model_CheckinManager();
			$this->ModelObj->getData  = $this->Request;
			$this->view->ModelObj = $this->ModelObj;
			$this->view->Request = $this->Request;
			$this->_helper->layout->setLayout('main');
	  }catch(Exception $e){
	    echo $e->getMessage();die;
	  }
    }

    public function indexAction()
    {
        // action body
    }

    public function checkinAction()
    {
    }

    public function batchcheckinAction()
    {
       if((isset($this->Request['shipment_mode']) && $this->Request['shipment_mode']!='' && !empty($this->Request['barcode_id'])) || (isset($this->Request['shipment_mode1']) && $this->Request['shipment_mode1']!='')){
	         $this->ModelObj->batchCheckin();
			 $this->_redirect($this->_request->getControllerName().'/'.$this->_request->getActionName()); 
	   }
	   $this->view->records = $this->ModelObj->getParcelList();
	   $this->view->filters = $this->ModelObj->getfilters();
	   $this->view->servicelist = $this->ModelObj->getCustomServiceList();
	   $this->view->addedtype = $this->ModelObj->ParcelAddedType();
    }

    public function parceldetailAction()
    {   // $this->ModelObj->getData['search_barcode'] = '75560200627000';
	   if(isset($this->Request['search_barcode'])){
         $this->view->parceldetails = $this->ModelObj->getParcelDetails();
	     }
	   //echo "<pre>";print_r( $this->view->parceldetails);die;
    }
	
	public function csvcheckinAction(){
	     if($this->_request->isPost()){
		    $this->ModelObj->CheckinCSV();  
		 }
	}
	
	public function referencecheckinAction(){
	    
	}
}







