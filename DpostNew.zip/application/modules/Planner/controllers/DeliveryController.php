<?php
ini_set('display_errors','1');
class Planner_DeliveryController extends Zend_Controller_Action
{
    public $Request = array();

    public $ModelObj = null;
    public function init()
    {
       try{	
			$this->Request = $this->_request->getParams();
			$this->ModelObj = new Planner_Model_Delivery();
			$this->formObj = new Planner_Form_Planner();
			$this->ModelObj->getData  = $this->Request;
			$this->view->ModelObj = $this->ModelObj;
			$this->_helper->layout->setLayout('main');
	  }catch(Exception $e){
	    echo $e->getMessage();die;
	  }
    }

	public function scheduledeliveryAction() {
		global $objSession;
		if($this->_request->isPost() && isset($this->Request['driver_id']) && !empty($this->Request['driver_id'])){
		$result = $this->ModelObj->assignToDriver();
			  if($result){
				$objSession->successMsg = "Driver Assignment Successfully !!";
			  }else{
			    $objSession->errorMsg = "Something is wrong !!";
			  }
			$this->_redirect($this->_request->getControllerName().'/scheduledelivery');
		}
        $record = $this->ModelObj->getscheduledelivery();
	    $eventreturn = $this->ModelObj->getEventReturnParcel();
		if(!empty($eventreturn)){
		  $record = array_merge($record,$eventreturn);
		}
		$this->view->records = $record;
		$driverlist = new Planner_Model_Scheduleroute();
        $this->view->driver_list = $driverlist->getDriverList();
		//echo "<pre>";print_r($this->ModelObj->getCustomerList()); die;
		$this->view->customerList = $this->ModelObj->getCustomerList();
	}

	public function setdatetimeAction() {
		global $objSession;
		$this->_helper->layout->setLayout('popup');
		if($this->_request->isPost() && isset($this->Request['submit'])){
			  $result = $this->ModelObj->setDateTimeDelivery();
			  if($result){
				$objSession->successMsg = "Date Time Upadated Successfully !!";
			  }else{
			    $objSession->errorMsg = "Something is wrong !!";
			  }
			  echo '<script type="text/javascript">parent.window.location.reload();
				  parent.jQuery.fancybox.close();</script>';
				  exit(); 
		
		}
	}
	
	public function assigneddeliveryAction(){
		global $objSession;
		if(isset($this->Request['barcode_id']) && !empty($this->Request['barcode_id'])){
		$result = $this->ModelObj->ReassignToDriver();
			  if($result){
				$objSession->successMsg = "Driver Assignment Successfully !!";
			  }else{
			    $objSession->errorMsg = "Something is wrong !!";
			  }
			$this->_redirect($this->_request->getControllerName().'/assigneddelivery');
		}
        $record = $this->ModelObj->getassigndelivery();
	    $eventreturn = $this->ModelObj->getEventReturnParcel(true);
		if(!empty($eventreturn)){
		  $record = array_merge($record,$eventreturn);
		}
		$this->view->records = $record;
		$driverlist = new Planner_Model_Scheduleroute();
        $this->view->driver_list = $driverlist->getDriverList();
		//echo "<pre>";print_r($this->ModelObj->getCustomerList()); die;
		$this->view->customerList = $this->ModelObj->getCustomerList();
	}
}

