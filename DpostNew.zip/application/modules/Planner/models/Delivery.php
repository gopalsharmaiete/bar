<?php

class Planner_Model_Delivery extends Zend_Custom
{
	public function getscheduledelivery() {
	   try {
			$filterString = '';
				if (isset($this->getData['filter_customer']) && $this->getData['filter_customer'] != '') {
					$filterString = ' AND SCL.user_id=' . Zend_Encript_Encription:: decode($this->getData['filter_customer']);
				}

				if (isset($this->getData['filter_barcode']) && $this->getData['filter_barcode'] != '') {
					$filterString .=" AND BT.barcode LIKE '%" . $this->getData['filter_barcode'] . "%'";
				}

				if (isset($this->getData['filter_postcode']) && $this->getData['filter_postcode'] != '') {
					$zipCode = substr($this->getData['filter_postcode'], 0, 4);
					$filterString .=" AND SUBSTRING(SCL.rec_zipcode,1,4)like'" . $zipCode . "%'";
				}
			$OrderLimit = commonfunction::OdrderByAndLimit($this->getData,'BD.checkin_date','DESC');
			$user_id = $this->LevelClause();
            $select = $this->_db->select()
						    ->from(array('BT' => SHIPMENT_BARCODE), array('BT.barcode'))
							->joininner(array('BD' => SHIPMENT_BARCODE_DETAIL), 'BD.barcode_id = BT.barcode_id', array('DATE(BD.checkin_date) AS checkin_date','shipment_type'=>new Zend_Db_Expr('1')))
						    ->joininner(array('SCL' => SHIPMENT_BARCODE_LOG), 'BT.barcode_id = SCL.barcode_id', array('BT.weight','BT.barcode','BT.barcode_id'))
							->joininner(array('AT' => USERS_DETAILS), 'SCL.user_id = AT.user_id', array('company_name'))
							->joininner(array('PT' => USERS_DETAILS), 'PT.user_id = AT.parent_id', array('company_name AS depot_name'))
							->joininner(array('CT' => COUNTRIES), 'SCL.country_id=CT.country_id',
									array('delivery_address' => "CONCAT(SCL.rec_name,'^',SCL.rec_contact,'^',CONCAT(SCL.rec_street,' ',SCL.rec_streetnr),'^',SCL.rec_address,'^',CONCAT(SCL.rec_zipcode,' ',SCL.rec_city),'^',CT.country_name)"))
							->where("BT.checkin_status='1' AND BT.forwarder_id=22 AND BT.delivery_status='0' AND SCL.driver_id=0 AND SCL.expected_delivery<= CURDATE()")
							->where('BD.checkin_date > NOW() - INTERVAL 6 MONTH')
							->order($OrderLimit['OrderBy'].' '.$OrderLimit['OrderType'])
							->limit($OrderLimit['Toshow'],$OrderLimit['Offset']);
							//print_r($select->__tostring());die;
				return $this->getAdapter()->fetchAll($select);
		}catch (Exception $e){
            $this->_logger->info('Class-'.__CLASS__.',Function-'.__FUNCTION__.',Line-'.__LINE__.',Error-'.$e->getMessage());
        }

    }
	
	public function getEventReturnParcel($assigned=false) {
	   try {
			$filterString = '';
				if (isset($this->getData['filter_customer']) && $this->getData['filter_customer'] != '') {
					$filterString = ' AND ST.user_id=' . Zend_Encript_Encription:: decode($this->getData['filter_customer']);
				}

				if (isset($this->getData['filter_barcode']) && $this->getData['filter_barcode'] != '') {
					$filterString.=" AND BT.barcode LIKE '%" . $this->getData['filter_barcode'] . "%'";
				}

				if (isset($this->getData['filter_postcode']) && $this->getData['filter_postcode'] != '') {
					$zipCode = substr($this->getData['filter_postcode'], 0, 4);
					$filterString.=" AND SUBSTRING(ST.rec_zipcode,1,4)like'" . $zipCode . "%'";
				}
				if (isset($this->getData['filter_driver']) && $this->getData['filter_driver'] != '') {
					$filterString.=" AND DDT.driver_id ='".Zend_Encript_Encription:: decode($this->getData['filter_driver'])."'";
				}
			$conditions  = '';
			if($assigned){
			   $conditions  = "SCL.driver_id >0 AND SCL.delivery_status='0' AND SCL.delivery_date != '0000-00-00' AND SCL.assign_date = CURDATE()";
			}else{
			   $conditions  = "SCL.driver_id=0 AND SCL.delivery_status='0'";
			}
			$OrderLimit = commonfunction::OdrderByAndLimit($this->getData,'create_date','DESC');
			$user_id = $this->LevelClause();
            $select = $this->_db->select()
							->from(array('BT' => SHIPMENT_BARCODE), array('BT.weight','BT.barcode','BT.barcode_id'))
							->joininner(array('ST' => SHIPMENT), 'ST.shipment_id = BT.shipment_id', array('create_date'=>'DATE_FORMAT(ST.create_date,"%d-%m-%Y")','ST.user_id'))
                            ->joininner(array('SCL' => SHIPMENT_EVENT_HISTORIES), 'SCL.barcode_id = BT.barcode_id ',array('SCL.event_action','SCL.assign_date','SCL.delivery_date','SCL.delivery_time','shipment_type'=>new Zend_Db_Expr('2')))
							->joininner(array('AT' => USERS_DETAILS), 'ST.user_id = ' . 'AT.' . ADMIN_ID . $user_id, array('company' => 'company_name'))
							->joininner(array('AT1'=>USERS_DETAILS),'AT1.'.ADMIN_ID.'=AT.'.PARENT_ID,array('depotCompany'=>'AT1.company_name'))
							->joininner(array('CT' => COUNTRIES), 'ST.country_id=CT.country_id',
									array('delivery_address' => "CONCAT(ST.rec_name,'^',ST.rec_contact,'^',CONCAT(ST.rec_street,' ',ST.rec_streetnr),'^',ST.rec_address,'^',CONCAT(ST.rec_zipcode,' ',ST.rec_city),'^',CT.country_name)"))
							->joinleft(array('DDT' => DRIVER_DETAIL_TABLE), 'DDT.driver_id=' . 'SCL.driver_id', array('DDT.driver_name'))
                            ->where('BT.'.CHECKIN_STATUS . '=?', '1')
							->where($conditions.$filterString)
							->where("SCL.delivery_date <= CURDATE()")
							->group("BT.shipment_id")
							->where('ST.create_date > NOW() - INTERVAL 6 MONTH')
							->order($OrderLimit['OrderBy'].' '.$OrderLimit['OrderType'])
							->limit($OrderLimit['Toshow'],$OrderLimit['Offset']);
							//print_r($select->__tostring());die;
				return $this->getAdapter()->fetchAll($select);
		}catch (Exception $e){
            $this->_logger->info('Class-'.__CLASS__.',Function-'.__FUNCTION__.',Line-'.__LINE__.',Error-'.$e->getMessage());
        }

    }
	
	public function getBarcodeCount($barcodeID){
	            $select = $this->_db->select()
						   ->from(array('PSD'=>PLANNER_SCHEDULE_DELIVERY), array('COUNT'=>'count(*)'))
							->where('PSD.barcode_id=?',$barcodeID );
				return $this->getAdapter()->fetchRow($select);
	}
	public function setDateTimeDelivery() {
	   try {	
				$barcodeID= Zend_Encript_Encription:: decode($this->getData['token']);
				$this->getData['delivery_date'] = ($this->getData['delivery_date']=='' || strtotime($this->getData['delivery_date']) == '0') ? date("Y-m-d"): $this->getData['delivery_date'];	
				if(isset($this->getData['shipment_type']) && $this->getData['shipment_type'] == '2'){
					$result = $this->UpdateInToTable(SHIPMENT_EVENT_HISTORIES,array($this->getData),'barcode_id='.$barcodeID);
				}else{
					$count = $this->getBarcodeCount($barcodeID);
					if($count['COUNT']>0){
					$result = $this->UpdateInToTable(PLANNER_SCHEDULE_DELIVERY,array($this->getData),'barcode_id='.$barcodeID);
					}else{				
					$this->getData['barcode_id'] = $barcodeID;			
					$result = $this->insertInToTable(PLANNER_SCHEDULE_DELIVERY,array($this->getData));
					}
				}
				return $result;
		}catch (Exception $e){
            $this->_logger->info('Class-'.__CLASS__.',Function-'.__FUNCTION__.',Line-'.__LINE__.',Error-'.$e->getMessage());
        }
    }

	public function assignToDriver(){
	  try {
		if(isset($this->getData['barcode_id'])){
		  $dataArray = array();
		  $dataArray['assign_date'] = date("Y-m-d");
		  $dataArray['driver_id'] = Zend_Encript_Encription:: decode($this->getData['driver_id']);
		  foreach($this->getData['barcode_id'] as $value){
				$expData = commonfunction::explode_string($value,'&');
				$barcodeid = $expData['0'];
				$dataArray['shipment_type'] = $expData['1'];
				$dataArray['user_id'] = $expData['2'];
				$dataArray['delivery_date'] = $expData['3'];
				$dataArray['delivery_time'] = $expData['4'];
			if($dataArray['shipment_type']=='2'){ 
			     $this->UpdateInToTable(SHIPMENT_EVENT_HISTORIES,array($dataArray),'barcode_id='.$barcodeid);
				
			}else{
				$count = $this->getBarcodeCount($barcodeid);
				if($count['COUNT']>0){
				  $this->UpdateInToTable(PLANNER_SCHEDULE_DELIVERY,array($dataArray),'barcode_id='.$barcodeid);
				}else{
				  $dataArray['barcode_id'] = $barcodeid;				  
				  $this->insertInToTable(PLANNER_SCHEDULE_DELIVERY,array($dataArray));
				}
			  }
		  }
		  return true;
		}
	  }catch (Exception $e){
            $this->_logger->info('Class-'.__CLASS__.',Function-'.__FUNCTION__.',Line-'.__LINE__.',Error-'.$e->getMessage());
      }
	}

	
	public function getassigndelivery() {
	   try {
			$filterString = '';
				if (isset($this->getData['filter_customer']) && $this->getData['filter_customer'] != '') {
					$filterString = ' AND SCL.user_id=' . Zend_Encript_Encription:: decode($this->getData['filter_customer']);
				}

				if (isset($this->getData['filter_driver']) && $this->getData['filter_driver'] != '') {
					$filterString .=" AND DDT.driver_id ='".Zend_Encript_Encription:: decode($this->getData['filter_driver'])."'";
				}
			$OrderLimit = commonfunction::OdrderByAndLimit($this->getData,'create_date','DESC');
			$user_id = $this->LevelClause();
            $select = $this->_db->select()
						   ->from(array('BT' => SHIPMENT_BARCODE), array('create_date'=>'DATE_FORMAT(SCL.create_date,"%d-%m-%Y")','SCL.user_id'))
						   ->joininner(array('SCL' => SHIPMENT), 'BT.shipment_id = SCL.shipment_id ', array('BT.weight','BT.barcode','BT.barcode_id'))
							->joininner(array('AT' => USERS_DETAILS), 'SCL.user_id = ' . 'AT.' . ADMIN_ID . $user_id, array('company' => 'company_name'))
							->joininner(array('AT1'=>USERS_DETAILS),'AT1.'.ADMIN_ID.'=AT.'.PARENT_ID,array('depotCompany'=>'AT1.company_name'))
							->joininner(array('CT' => COUNTRIES), 'SCL.country_id=CT.country_id',
									array('delivery_address' => "CONCAT(SCL.rec_name,'^',SCL.rec_contact,'^',CONCAT(SCL.rec_street,' ',SCL.rec_streetnr),'^',SCL.rec_address,'^',CONCAT(SCL.rec_zipcode,' ',SCL.rec_city),'^',CT.country_name)"))
							->joinleft(array('PSD'=>PLANNER_SCHEDULE_DELIVERY),'PSD.barcode_id=BT.barcode_id',array('PSD.delivery_date','PSD.delivery_time','PSD.assign_date','shipment_type'=>new Zend_Db_Expr('1')))
							->joininner(array('DDT' => DRIVER_DETAIL_TABLE), 'DDT.driver_id=' . 'PSD.driver_id', array('DDT.driver_name'))
							->where('BT.'.CHECKIN_STATUS . '=?', '1')
							->where("BT.forwarder_id=22".$filterString)
							->where("PSD.driver_id > '0'")
							->where("PSD.delivery_date <= CURDATE() AND PSD.delivery_date != '0000-00-00' AND PSD.assign_date = CURDATE()")
							->group("BT.shipment_id")
							->where('SCL.create_date > NOW() - INTERVAL 6 MONTH')
							->order($OrderLimit['OrderBy'].' '.$OrderLimit['OrderType'])
							->limit($OrderLimit['Toshow'],$OrderLimit['Offset']);
							//print_r($select->__tostring());die;
				return $this->getAdapter()->fetchAll($select);
		}catch (Exception $e){
            $this->_logger->info('Class-'.__CLASS__.',Function-'.__FUNCTION__.',Line-'.__LINE__.',Error-'.$e->getMessage());
        }

    }

	public function ReassignToDriver(){
	  try {
		if(isset($this->getData['barcode_id'])){
		  $dataArray = array();
		  $dataArray['assign_date'] = date("Y-m-d");
		  $dataArray['driver_id'] = Zend_Encript_Encription:: decode($this->getData['driver_id']);
		  foreach($this->getData['barcode_id'] as $value){
			$expData = commonfunction::explode_string($value,'&');
			$barcodeid = $expData['0'];
			$dataArray['shipment_type'] = $expData['1'];
			if($dataArray['shipment_type']=='2'){ 
			     $this->UpdateInToTable(SHIPMENT_EVENT_HISTORIES,array($dataArray),'barcode_id='.$barcodeid);
				
			}else{
				  $this->UpdateInToTable(PLANNER_SCHEDULE_DELIVERY,array($dataArray),'barcode_id='.$barcodeid);
			}
			
		 }
		 return true;
		}
	   }catch (Exception $e){
            $this->_logger->info('Class-'.__CLASS__.',Function-'.__FUNCTION__.',Line-'.__LINE__.',Error-'.$e->getMessage());
      }
	}
}

