<?php

class Shipmentmanager_ShipmentmanagerController extends Zend_Controller_Action
{

    public $Request = array();
    public function init()
    {
        try{	
			$this->Request = $this->_request->getParams();
			$this->ModelObj = new Shipmentmanager_Model_Shipmentmanager();
			$this->ModelObj->getData  = $this->Request;
			$this->view->ModelObj = $this->ModelObj;
			$this->_helper->layout->setLayout('main');
	 }catch(Exception $e){
	    echo $e->getMessage();die;
	 }	
    }

    public function indexAction()
    {
        // action body
    }

    public function pickrequestAction()
    {
        $this->view->schedulepickup = $this->ModelObj->PickupRequest();
    }

    public function returnshipmentAction()
    {
        $this->view->schedulepickup =array();
    }

    public function deliverytrackerAction()
    {
        // action body
    }

    public function customerscanAction()
    {
        // action body
    }


}









