<?php

class Shipmentmanager_Model_Shipmentmanager extends Planner_Model_Planner
{
	public function PickupRequest(){
	   $accesslevel = commonfunction::LevelClause();
	   $select = $this->_db->select()
		               ->from(array('ST'=>SHIPMENT), array('DATE(ST.create_date) AS create_date','GROUP_CONCAT(DISTINCT DATE(ST.create_date)) AS Alldate','IF(BT.barcode_id,1,1) AS parcel_type'))
					   ->joininner(array('BT'=>SHIPMENT_BARCODE),"ST.shipment_id=BT.shipment_id",array('SUM(BT.weight) AS total_weight','COUNT(1) AS total_quantity','GROUP_CONCAT(DISTINCT BT.barcode_id) AS barcode_id'))
					   ->joininner(array('BD'=>SHIPMENT_BARCODE_DETAIL),"BD.barcode_id=BT.barcode_id",array(''))
					   ->joininner(array('AT'=>USERS_DETAILS),"ST.user_id=AT.user_id",array('company_name','user_id'))
					   ->joininner(array('US'=>USERS_SETTINGS),"US.user_id=AT.user_id",array(''))
					   ->joininner(array('SR'=>SERVICES),'SR.service_id=ST.service_id',array(''))
					   ->joinleft(array('ASP'=>USERS_SCHEDULE_PICKUP),'ASP.user_id=AT.user_id',array())
					   ->joininner(array('CT'=>COUNTRIES),'AT.country_id=CT.country_id',array(''))
					   ->joinleft(array('SST'=>SHIPMENT_SCHEDULE_TIME),'SST.barcode_id=BT.barcode_id AND DATE(SST.date_added) = CURDATE() AND SST.parcel_type=1',array(''))
					   ->joinleft(array('MPT'=>SHIPMENT_MANUAL_PICKUP),'MPT.manual_pickup_id=BD.manual_pickup_id',
					   array('pickup_address'=>"if((BD.manual_pickup_id>0),CONCAT(MPT.name,'^',MPT.street1,'^',MPT.street2,'^',MPT.zipcode,'^',MPT.city,'^',MPT.country),if((ASP.zipcode!='' && ASP.city!=''),CONCAT(ASP.name,'^',ASP.street1,'^',ASP.street2,'^',ASP.zipcode,'^',ASP.city,'^',ASP.country),CONCAT(AT.company_name,'^',AT.address1,'^',AT.address2,'^',AT.postalcode,'^',AT.city,'^',CT.country_name)))",
					   	  'pickup_date'=>"if((BD.manual_pickup_id>0 && MPT.pickup_date!='0000-00-00'),MPT.pickup_date,if(ASP.user_id>0 && (".commonfunction::lowercase(date('D'))."_start"."!='00:00:00' || default_time_start!='00:00:00'),CURDATE(),CURDATE()))",
					      'pickup_time'=>"if((BD.manual_pickup_id>0 && MPT.pickup_time!='00:00:00'),MPT.pickup_time,IF(SST.pickup_time!='00:00:00' && SST.pickup_time!='',SST.pickup_time,if(ASP.user_id>0 && ".commonfunction::lowercase(date('D'))."_start"."!='00:00:00',".commonfunction::lowercase(date('D'))."_start".",if(default_time_start!='00-00-00',default_time_start,'00-00-00'))))"))
					   ->where("BT.checkin_status='0' AND BT.pickup_status='0' AND BT.show_planner='1' AND BD.driver_id=0 AND BD.assigned_date < CURDATE() AND ST.shipment_type!=5")
					   ->where("US.gls_pickup = '0'".$accesslevel)
					   ->where("(ST.create_date > NOW() - INTERVAL 60 DAY OR (BD.manual_pickup_id>0 AND DATE(MPT.pickup_date) = CURDATE() OR (ASP.picked_by_driver='0' AND BD.manual_pickup_id>0)))")
					   ->group("DATE(ST.create_date)")
					   ->group(new Zend_Db_Expr('pickup_time'))
					   ->having("pickup_date <= CURDATE()")
					   ->order(new Zend_Db_Expr('pickup_time'))
					   ->order(new Zend_Db_Expr('pickup_date'));//print_r($select->__tostring());die;
		return  $this->getAdapter()->fetchAll($select);
	}

}

