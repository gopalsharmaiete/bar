<?php
class Application_Model_Ajax extends Zend_Custom{
   /**
     * Return city and street of given postalcode
     * @param  $adaptor|$post main db adaptor and post data from ajax
     * @return city list as HTML dropdown or textbox
     */
	public function getCity(){ 
		$this->getData[ZIPCODE] = $this->ValidateZipcode($this->getData[ZIPCODE],$this->getData[COUNTRY_ID]);
		$select = $this->masterdb->select()
						  ->from(array('WC'=>CITIES),array('*'))
						  ->where('WC.country_id=?',trim($this->getData[COUNTRY_ID]))
						  ->where('WC.postcode=?',trim($this->getData[ZIPCODE]))
						  ->group('WC.city');
		$cityLists = $this->masterdb->fetchAll($select);	
		$city = '';
		$street = '';
		$Cti = 0;
		$Str = 0;
		if(!empty($cityLists)){
		    if(count($cityLists)>1){
			       $city .= "<select name=\"rec_city\" id=\"rec_city\" class=\"inputfield\">";
				   foreach($cityLists as $cities){
				     $checked = (isset($this->getData[CITY]) && $cities['city']==trim($this->getData[CITY]))?'selected="selected"':'';
					 $city .= "<option value=\"".$cities['city']."\" ".$checked.">".$cities['city']."</option>";
				  }
			     $city .= "</select>";
				 $Cti = 1;
			}
			else{
			    $city = (isset($this->getData[CITY]) && !empty($this->getData[CITY]))?$this->getData[CITY]:$cityLists[0]['city'];
				$Cti = 2;
			} 
			if(count($cityLists)>1 && $post['country_id']==9){
			     $street .= "<select name=\"rec_street\" id=\"rec_street\" class=\"inputfield\">";
		       foreach($cityLists as $street){
			     $checked = (isset($this->getData[STREET]) && $cities['street']==trim($this->getData[STREET]))?'selected="selected"':'';
			  	 $street .= "<option value=\"".$street['street']."\" ".$checked.">".$cities['street']."</option>";
		      }
			  $street .= "</select>";
			   $Str = 1;
			}
			else{
			   $street = (isset($this->getData[STREET]) && !empty($this->getData[STREET]))?$this->getData[STREET]:$cityLists[0]['street'];
			    $Str = 2;
			}  
		}
		return json_encode(array('Str'=>$Str,'Cti'=>$Cti,'Street'=>$street,'City'=>$city));
	}
	
	public function getServiceList(){
		   $userdetails = $this->getCustomerDetails($this->getData[ADMIN_ID]);
		   $this->getData[PARENT_ID] = $userdetails[PARENT_ID];
		   $services = $this->getRoutingID();
		   $ReturnSTr = '';
		   if($services){
		       foreach($services as $service){
			    $displaynon = (isset($this->getData['selected_service']) && $this->getData['selected_service']==$service[SERVICE_ID])?'':'style="display:none"';
				$checked = (isset($this->getData['selected_service']) && $this->getData['selected_service']==$service[SERVICE_ID])?'checked="checked"':'';
			    $price = ' &euro;'.commonfunction::numberformat($service['customer_price'],2).'';
				$selected = ($this->getData['selected_service']>0  && ($this->getData['selected_service']==$service[SERVICE_ID]) && $this->getData['selected_addservice']<1)?' selectedbox':'';
				$serviceinformation = $this->serviceInfo($service);
				$ReturnSTr .= '<div class="radiotextbox">';
				$ReturnSTr .= '<div class="sideaction">';
				$ReturnSTr .= '<div class="sideicon"><img src="'.IMAGE_LINK.(($service['signature']=='1')?'/sign.png':'/sign_x.png').'" title="Signature"></div>';
				$ReturnSTr .= '<div class="sideicon"><img src="'.IMAGE_LINK.(($service['tracking']=='1')?'/Barcode-Scanner.png':'/Barcode-Scanner_x.png').'"  title="Tracking"></div></div>';
				$ReturnSTr .= '<div class="radiobutton'.$selected.'" id="radiobox_'.$service[SERVICE_ID].'">';
				$ReturnSTr .= '<input type="radio" name="service_id" id="service_id_'.$service[SERVICE_ID].'" value="'.$service[SERVICE_ID].'"  class="imgradio"  onclick="onclickservice('.$service[SERVICE_ID].','.$service[FORWARDER_ID].','.$service[FORWARDER_ID].')" '.$checked.' />';
				$ReturnSTr .= '<label for="service_id_'.$service[SERVICE_ID].'"><img src="'.SERVICE_ICON.$service['service_icon'].'" class="img-responsive"/></label>';
				$ReturnSTr .= '<p>'.$service['service_name'].'&nbsp;<a class="tooltip"><img src="'.SERVICE_ICON.'info.png"/><b class="tooltiptext">'.$service['description'].$serviceinformation.'</b></a><span>'.$price.'</span></p></div><div class="clearfix"></div>';				
				$addservices = $this->getRoutingID($service[SERVICE_ID]);
				if(!empty($addservices)){
					$ReturnSTr .= '<div class="subradio" id="addservicediv_'.$service[SERVICE_ID].'" '.$displaynon.'>';
					
				    foreach($addservices as $addservice){
					    $addserviceinfo = $this->serviceInfo($addservice);
					    $addchecked = (isset($this->getData['selected_addservice']) && $this->getData['selected_addservice']==$addservice[SERVICE_ID])?'checked="checked"':'';
					    $addprice = ' &euro;'.commonfunction::numberformat($addservice['customer_price'],2).' ';
						$addselected = ($this->getData['selected_addservice']>0  && ($this->getData['selected_addservice']==$addservice[SERVICE_ID]))?' selectedbox':'';
						$ReturnSTr .= '<div class="radiobutton2'.$addselected.'" id="radiobox_'.$addservice[SERVICE_ID].'">';
						$ReturnSTr .= '<div class="sideaction" style="top:0px; right:0px">';
					$ReturnSTr .= '<div class="sideicon"><img src="'.IMAGE_LINK.'/sign.png"></div>';
					$ReturnSTr .= '<div class="sideicon"><img src="'.IMAGE_LINK.'/Barcode-Scanner.png"></div></div>';
						$ReturnSTr .= '<input type="radio" name="addservice_id" id="addservice_id_'.$addservice[SERVICE_ID].'" value="'.$addservice[SERVICE_ID].'"  class="imgradio2"  onclick="onclickaddservice('.$addservice[SERVICE_ID].','.$addservice[FORWARDER_ID].','.$addservice[FORWARDER_ID].')" />';
						
						
						$ReturnSTr .= '<label for="addservice_id_'.$addservice[SERVICE_ID].'"><img src="'.SERVICE_ICON.$addservice['service_icon'].'" class="img-responsive"/></label>';
						$ReturnSTr .= '<p>'.$addservice['service_name'].'&nbsp;<a class="tooltip"><img src="'.SERVICE_ICON.'info.png"/><b class="tooltiptext">'.$addservice['description'].$addserviceinfo.'</b></a><span>'.$addprice.'</span></p></div>';
					}
					 $ReturnSTr .= '</div>';
				}
				$ReturnSTr .= '<div class="clearfix"></div></div>';
			}
		} 
		 return json_encode(array('success'=>(($ReturnSTr!='')?1:0),'Services'=>$ReturnSTr));	

	}
	public function serviceInfo($data){
	     $service_desc = ($data['transit_desc']!='')?$data['transit_desc']:$data['gen_desc'];
		 return $service_desc;
	}
		
	public function getAddressbook(){
	     $select = $this->_db->select()
									->from(array('AB' =>ADDRESS_BOOK),array('name','contact','street','street_no','address','street2','postalcode','city','phone','email','country_id'))
									->where("user_id=?",$this->getData['user_id'])
									->where("(name LIKE '".$this->getData['name_startsWith']."%' OR customer_number LIKE '".$this->getData['name_startsWith']."%')")
									->order("name ASC")
									->limit(15);
		 $addresbook =  $this->getAdapter()->fetchAll($select);	//return $select->__toString();
		 $returnArr = array();
		 if(!empty($addresbook)){
		    foreach($addresbook as $address){
			   $returnArr[] = array('Name'=>$address['name'],'FullAdd'=>commonfunction::implod_array($address,'^'));
			}
		 }else{
		     $returnArr[] = array('Name'=>'No record!','FullAdd'=>'No record!');
		 }//return $addresbook;	
		 return $returnArr;									
	}
	
	public function getStreetList(){
	    $select = $this->masterdb->select()
									->from(array('CT' =>CITIES),array('street'))
									->where("country_id=?",$this->getData['country_id'])
									->where("postcode=?",$this->getData['rec_zipcode'])
									->where("street LIKE '".$this->getData['name_startsWith']."%'")
									->order("street ASC")->group("street")
									->limit(15);
		 $streetlists =  $this->masterdb->fetchAll($select);	//return $select->__toString();
		 $returnArr = array();
		 if(!empty($streetlists)){
		    foreach($streetlists as $streetlist){
			   $returnArr[] = $streetlist['street'];
			}
		 }else{
		     $returnArr[] = $this->getData['name_startsWith'];
		 }//return $addresbook;	
		 return $returnArr;	
	}
	
	public function getWeightClassService(){
	     $where = '';
		 if($this->getData['service']>0){
		    $where = " AND WC.service_id='".$this->getData['service']."'";
		 }
		 $select = $this->_db->select()
	   					->from(array('WC'=>ROUTING_WEIGHT_CLASS),array('*','GROUP_CONCAT(service_id) AS all_service'))
						->where("WC.country_id='".$this->getData['country_id']."' AND WC.user_id='".Zend_Encript_Encription::decode($this->getData['user_id'])."'".$where)
						->group("WC.min_weight")
						->group("WC.max_weight")
						->order("WC.min_weight ASC");//echo $select->__toString();
		$weightclasses =  $this->getAdapter()->fetchAll($select);
		$returnString = '';
		$returnString .= '<div class="table-header"><table width="100%" cellpadding="0" cellspacing="0"><thead>';
		$returnString .= '<tr><th class="header-cell wd1">Services</th>';
		foreach($weightclasses as $weightclass){
		  $minweight[]   = $weightclass['min_weight'];
		  $maxweight[]   = $weightclass['max_weight'];
		  $allservices[]   = commonfunction::explode_string($weightclass['all_service'],',');
		  $returnString .= '<th class="header-cell wd1">'.$weightclass['min_weight'].' - to - '.$weightclass['max_weight'].'</th>';
		}
	   $returnString .= '</tr></thead></table></div><div class="table-body"><table width="100%" cellpadding="0" cellspacing="0"><tbody>';
	   $select = $this->_db->select()
	   					->from(array('WC'=>ROUTING_WEIGHT_CLASS),array('*'))
						->joininner(array('CT'=>COUNTRIES),"CT.country_id=WC.country_id",array('country_name'))
						->joininner(array('ST'=>SERVICES),"ST.service_id=WC.service_id",array('service_name'))
						->joinleft(array('PSV'=>SERVICES),"PSV.service_id=ST.parent_service", array('service_name AS parent_name'))
						->where("WC.country_id='".$this->getData['country_id']."' AND WC.user_id='".Zend_Encript_Encription::decode($this->getData['user_id'])."'".$where)
						->group("WC.service_id")
						->order("WC.min_weight ASC")
						->order(new Zend_Db_Expr("CASE WHEN ST.parent_service=0 THEN ST.service_id ELSE ST.parent_service END"))
						->order("ST.service_id");
						//echo $select->__toString();
		$serviceLists =  $this->getAdapter()->fetchAll($select);	
		
		foreach($serviceLists as $servicekey=>$serviceList){
		   //$returnString .= '<div class="row" style="background-color: '.(isset($serviceList['parent_name'])?'#ffecb3':'aquamarine;').'">';
		   $parent_service = isset($serviceList['parent_name'])?'-<b>'.$serviceList['parent_name'].'</b>':'';
		   $returnString .= '<tr style="background-color: '.(isset($serviceList['parent_name'])?'#ffecb3':'aquamarine;').'"><td class="body-cell wd1">'.$serviceList['service_name'].$parent_service.'</td>';
		   foreach($minweight as $key=>$weightbox){
		        $returnString .= '<td class="body-cell wd1">';
				if(commonfunction::inArray($serviceList['service_id'],$allservices[$key])){
				$addedRouting = $this->getAlreadyAddedROuting($weightbox,$maxweight[$key],$serviceList['service_id']); 
				$returnString .= '<input type="text" name="routingdata['.$weightbox.'-'.$maxweight[$key].']['.$servicekey.'][price]" class="inputfield" style="width: 74px;" placeholder="Price" value="'.(isset($addedRouting['depot_price'])?$addedRouting['depot_price']:'').'">&nbsp;';
				$returnString .= '<input type="hidden" name="routingdata['.$weightbox.'-'.$maxweight[$key].']['.$servicekey.'][service_id]" value="'.$serviceList['service_id'].'">&nbsp;';
				$returnString .= '<select class="inputfield" style="width: 50%;" id="forwarder_id" name="routingdata['.$weightbox.'-'.$maxweight[$key].']['.$servicekey.'][forwarder_id]">';
				$returnString .= '<option value="">--Select--</option>';
				$forwarderList =  $this->getForwarderCountry(); 
				foreach($forwarderList as $forwarder){ 
				   $selected = (isset($addedRouting['forwarder_id']) && $addedRouting['forwarder_id']==$forwarder['forwarder_id'])?'selected="selected"':'';
				   $returnString .= '<option value="'.$forwarder['forwarder_id'].'" '.$selected.'>'.$forwarder['forwarder_name'].'</option>';
				}
				//$returnString .= '</td>';
			  }
			 $returnString .= '</td>';
				
		   }
		   $returnString .= '</tr>';
		}
		$returnString .= '</tbody> </table></div>';
		
		
		return $returnString;
	}
	
	public function getWeightClassService_old(){
	     $where = '';
		 if($this->getData['service']>0){
		    $where = " AND WC.service_id='".$this->getData['service']."'";
		 }
		 $select = $this->_db->select()
	   					->from(array('WC'=>ROUTING_WEIGHT_CLASS),array('*','GROUP_CONCAT(service_id) AS all_service'))
						->where("WC.country_id='".$this->getData['country_id']."' AND WC.user_id='".Zend_Encript_Encription::decode($this->getData['user_id'])."'".$where)
						->group("WC.min_weight")
						->group("WC.max_weight")
						->order("WC.min_weight ASC");//echo $select->__toString();
		$weightclasses =  $this->getAdapter()->fetchAll($select);
		$returnString = '';
		$returnString .= '<div class="header-row row">';
		$returnString .= '<span class="cell">Services</span>';
		foreach($weightclasses as $weightclass){
		  $minweight[]   = $weightclass['min_weight'];
		  $maxweight[]   = $weightclass['max_weight'];
		  $allservices[]   = commonfunction::explode_string($weightclass['all_service'],',');
		  $returnString .= '<span class="cell">'.$weightclass['min_weight'].' - to - '.$weightclass['max_weight'].'</span>';
		}
	   $returnString .= '</div>';
	   $select = $this->_db->select()
	   					->from(array('WC'=>ROUTING_WEIGHT_CLASS),array('*'))
						->joininner(array('CT'=>COUNTRIES),"CT.country_id=WC.country_id",array('country_name'))
						->joininner(array('ST'=>SERVICES),"ST.service_id=WC.service_id",array('service_name'))
						->joinleft(array('PSV'=>SERVICES),"PSV.service_id=ST.parent_service", array('service_name AS parent_name'))
						->where("WC.country_id='".$this->getData['country_id']."' AND WC.user_id='".Zend_Encript_Encription::decode($this->getData['user_id'])."'".$where)
						->group("WC.service_id")
						->order("WC.min_weight ASC")
						->order(new Zend_Db_Expr("CASE WHEN ST.parent_service=0 THEN ST.service_id ELSE ST.parent_service END"))
						->order("ST.service_id");
						//echo $select->__toString();
		$serviceLists =  $this->getAdapter()->fetchAll($select);	
		
		foreach($serviceLists as $servicekey=>$serviceList){
		   $returnString .= '<div class="row" style="background-color: '.(isset($serviceList['parent_name'])?'#ffecb3':'aquamarine;').'">';
		   $parent_service = isset($serviceList['parent_name'])?'-<b>'.$serviceList['parent_name'].'</b>':'';
		   $returnString .= '<span class="cell" data-label="Service">'.$serviceList['service_name'].$parent_service.'</span>';
		   foreach($minweight as $key=>$weightbox){
		        $returnString .= '<span class="cell" data-label="Pricestep">';
				if(commonfunction::inArray($serviceList['service_id'],$allservices[$key])){
				$addedRouting = $this->getAlreadyAddedROuting($weightbox,$maxweight[$key],$serviceList['service_id']); 
				$returnString .= '<input type="text" name="routingdata['.$weightbox.'-'.$maxweight[$key].']['.$servicekey.'][price]" class="inputfield" style="width: 74px;" placeholder="Price" value="'.(isset($addedRouting['depot_price'])?$addedRouting['depot_price']:'').'">&nbsp;';
				$returnString .= '<input type="hidden" name="routingdata['.$weightbox.'-'.$maxweight[$key].']['.$servicekey.'][service_id]" value="'.$serviceList['service_id'].'">&nbsp;';
				$returnString .= '<select class="inputfield" style="width: 150px;" id="forwarder_id" name="routingdata['.$weightbox.'-'.$maxweight[$key].']['.$servicekey.'][forwarder_id]">';
				$returnString .= '<option value="">--Select Forwarder--</option>';
				$forwarderList =  $this->getForwarderCountry(); 
				foreach($forwarderList as $forwarder){ 
				   $selected = (isset($addedRouting['forwarder_id']) && $addedRouting['forwarder_id']==$forwarder['forwarder_id'])?'selected="selected"':'';
				   $returnString .= '<option value="'.$forwarder['forwarder_id'].'" '.$selected.'>'.$forwarder['forwarder_name'].'</option>';
				}
				$returnString .= '</select>';
			  }
			 $returnString .= '</span>';
				
		   }
		   $returnString .= '</div>';
		}
		
		
		return $returnString;
	}
	
	public function getAlreadyAddedROuting($min_weight,$max_weight,$service_id){
	   $select = $this->_db->select()
	   					->from(array('RT'=>ROUTING),array('depot_price','forwarder_id'))
						->where("RT.country_id='".$this->getData['country_id']."' AND RT.user_id='".Zend_Encript_Encription::decode($this->getData['user_id'])."'")
						->where("RT.min_weight='".$min_weight."' AND RT.max_weight='".$max_weight."' AND RT.service_id='".$service_id."' AND RT.special_routing='0'");
						//echo $select->__toString();die;
		return  $this->getAdapter()->fetchRow($select);
	}
	
	public function getWeightClassService_local(){
	     $select = $this->_db->select()
	   					->from(array('WC'=>ROUTING_WEIGHT_CLASS),array('*'))
						->where("WC.country_id='".$this->getData['country_id']."'")
						->group("WC.min_weight")
						->group("WC.max_weight")
						->order("WC.min_weight ASC");
		$weightclasses =  $this->getAdapter()->fetchAll($select);
		$returnString = '';
		$returnString .= '<div class="header-row row">';
		$returnString .= '<span class="cell">Services</span>';
		foreach($weightclasses as $weightclass){
		  $minweight[]   = $weightclass['min_weight'];
		  $maxweight[]   = $weightclass['max_weight'];
		  $returnString .= '<span class="cell">'.$weightclass['min_weight'].' - to - '.$weightclass['max_weight'].'</span>';
		}
	   $returnString .= '</div>';
	   $select = $this->_db->select()
	   					->from(array('WC'=>ROUTING_WEIGHT_CLASS),array('*'))
						->joininner(array('CT'=>COUNTRIES),"CT.country_id=WC.country_id",array('country_name'))
						->joininner(array('ST'=>SERVICES),"ST.service_id=WC.service_id",array('service_name'))
						->joinleft(array('PSV'=>SERVICES),"PSV.service_id=ST.parent_service", array('service_name AS parent_name'))
						->where("WC.country_id='".$this->getData['country_id']."'")
						->group("WC.service_id")
						->order("WC.min_weight ASC")->order("ST.service_id ASC")->order("ST.parent_service ASC");
		$serviceLists =  $this->getAdapter()->fetchAll($select);	
		
		foreach($serviceLists as $servicekey=>$serviceList){
		   $returnString .= '<div class="row">';
		   $parent_service = isset($serviceList['parent_name'])?'-<b>'.$serviceList['parent_name'].'</b>':'';
		   $returnString .= '<span class="cell" data-label="Service">'.$serviceList['service_name'].$parent_service.'</span>';
		   foreach($minweight as $key=>$weightbox){
		        $dissabled = ($serviceList['parent_name']!='')?'disabled="disabled"':'';
				$returnString .= '<span class="cell" data-label="Pricestep">';
				$returnString .= '<input type="text" name="routingdata['.$weightbox.'-'.$maxweight[$key].']['.$servicekey.'][price]" id="price_'.$key.'_'.$serviceList['service_id'].'" class="inputfield" style="width: 74px;" placeholder="Price" '.$dissabled.' onkeyup="enableSubservice(this.value,'.$key.','.$serviceList['service_id'].')" onblur="enableSubservice(this.value,'.$key.','.$serviceList['service_id'].')">&nbsp;';
				$returnString .= '<input type="hidden" name="routingdata['.$weightbox.'-'.$maxweight[$key].']['.$servicekey.'][service_id]" value="'.$serviceList['service_id'].'">&nbsp;';
				$returnString .= '<select class="inputfield" style="width: 150px;" name="routingdata['.$weightbox.'-'.$maxweight[$key].']['.$servicekey.'][forwarder_id]" id="forwarder_'.$key.'_'.$serviceList['service_id'].'" '.$dissabled.'>'; 
				$returnString .= '<option value="">--Select Forwarder--</option>';
				$forwarderList =  $this->getForwarderList(); 
				foreach($forwarderList as $forwarder){ 
				  $returnString .= '<option value="'.$forwarder['forwarder_id'].'">'.$forwarder['forwarder_name'].'</option>';
				}
				$returnString .= '</select></span>';
				
		   }
		   $returnString .= '</div>';
		}
		
		
		return $returnString;
	}
	
	public function ModifyInvoiceExtrahead(){//print_r($this->getData);die;
	   if($this->getData['mode']=='Delete'){
	   		$this->_db->delete(INVOICE_EXTRA_HEAD,"invoiceextra_id='".$this->getData['invoiceextra_id']."'");
	   }else{
	   		$this->_db->update(INVOICE_EXTRA_HEAD,array('quantity'=>$this->getData['added_quantity'],'description'=>$this->getData['added_description'],'price'=>$this->getData['added_price'],'btw_class'=>$this->getData['added_btw_class']),"invoiceextra_id='".$this->getData['invoiceextra_id']."'");
	   }
	}
	/**
	* Function : addcounstatus()
	* This function is for country change status
	* Date of creation 25/07/2016
	**/ 
	public function getChangeStatus($data)
	{ 
	try {
		if($data['condi_value'] > 0) {
		   $update = $this->_db->update($data['tablename'],array($data['column']=>$data['column_value']),$data['condi_column'].'='.$data['condi_value']);
		   return ($update) ? true : false;
		}
	} catch (Exception $e) {
		die('Something went wrong: ' . $e->getMessage());
		}
	}

 /**
 * Delete table record
 * Function : deleterecord()
 * This function is to delete table record
 * Date of creation 24/11/2016
 **/  
  public function deleterecord($data)
  { 
   try{
		$update = $this->_db->update($data['tablename'],array($data['column']=>$data['column_value'],'deleted_date'=>new Zend_Db_Expr('NOW()'),'deleted_by'=>$this->Useconfig['user_id'],'deleted_ip'=>commonfunction::loggedinIP()),$data['condi_column'].' = '.$data['condi_value']);
		return ($update) ? true : false;
    }catch (Exception $e) {
             $this->_logger->info('Class-'.__CLASS__.',Function-'.__FUNCTION__.',Line-'.__LINE__.',Error-'.$e->getMessage());
        } 
  }
  
  public function getfrwarderSettings(){
        $forwarder_id = (isset($this->getData['forwarder_id']))?$this->getData['forwarder_id']:0;
		$select = $this->_db->select()
	   					->from(array('FS'=>FORWARDER_SETTINGS),array('*'))
						->where("FS.country_id='".$this->getData['country_id']."' AND FS.forwarder_id='".$forwarder_id."'");
						//echo $select->__toString();
		$forwarderSetting =  $this->getAdapter()->fetchRow($select);
		if(empty($forwarderSetting)){
		  $select = $this->_db->select()
	   					->from(array('FS'=>FORWARDER_SETTINGS),array('*'))
						->where("FS.country_id='".$this->getData['country_id']."' AND FS.forwarder_id=0");
						//echo $select->__toString();
		 $forwarderSetting =  $this->getAdapter()->fetchRow($select);
		}
		return $forwarderSetting;	
  }
  
  
}

