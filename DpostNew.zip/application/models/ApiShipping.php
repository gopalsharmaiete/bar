<?php

class Application_Model_ApiShipping extends Application_Model_Shipments
{
   public $PostData = array();
  
   public function UsernamePasswordValidation(){
       $error = '';
       if(empty($this->getData['username'])) {
           $error['Username'] = 'Please assign username!,';
        }
       if(empty($this->getData['password'])) {
           $error['Password'] = 'Please assign password!,';
       }
       if(!empty($error)) {
           return array('Error'=>array('ErrorMessage'=>commonfunction::implod_array($error,',')));
       }else{
	      $select = $this->_db->select()
						  ->from(array('UT'=>USERS),array('access_kay_valid','access_key'))
						  ->joininner(array('UD'=>USERS_DETAILS),"UT.user_id=UD.user_id",array('*'))
						  ->joininner(array('US'=>USERS_SETTINGS),"US.user_id=UD.user_id",array('*'))
						  ->where('UT.username=?',addslashes($this->getData['username']))
						  ->where('UT.password=?',md5(addslashes($this->getData['password'])))
						  ->where('UT.user_status=?','1');
						//print_r($select->__toString());die;
     	  $result = $this->getAdapter()->fetchRow($select);
	    }	
		if(!empty($result))
		{
		   if($result['level_id']!=5 && $result['level_id']!=10){
			  return array('Error'=>array('ErrorMessage'=>'You have not privilege to create a shipment. Please contact to Parcel NL!'));
		   }
		   if($result['access_kay_valid']=='1' && $result['access_key']!=$this->getData['access_key']){
			  return array('Error'=>array('ErrorMessage'=>'Invalid Access Key!Please contact your administrator!'));
		   }
		   $logicSeesion = new Zend_Session_Namespace('logicSeesion');
		   $logicSeesion->userconfig =  $result;
		   $this->getData[ADMIN_ID] = $result[ADMIN_ID];
		}else{
			return array('Error'=>array('ErrorMessage'=>'Couldn\'t find any users!'));
		}
	 return $error;	

  }
  public function setDataToIndex($data){
       $this->getData['username'] =  trim($data['username']);
	   $this->getData['password']   = trim($data['password']);
	   $this->getData['access_key']   = trim(isset($data['access_key'])?$data['access_key']:'');
	   $this->getData['quantity'] = (trim($data['quantity'])>10)?10:trim($data['quantity']);
	   $this->getData['weight']   = trim($data['weight']);
	   $this->getData['rec_name'] = trim($data['shipto']);
	   $this->getData['rec_contact'] = trim($data['contact']);
	   $this->getData['rec_street'] = trim($data['street']);
	   $this->getData['rec_streetnr'] = trim($data['streetno']);
	   $this->getData['rec_address'] = trim($data['address1']);
	   $this->getData['rec_street2'] = trim($data['address2']);
	   $this->getData['rec_zipcode'] = trim($data['postalcode']);
	   $contry_detail  = $this->getCountryDetail(trim($data['countrycode']), 2);
	   $this->getData['country_id']  = $contry_detail[COUNTRY_ID];
	   $this->getData['rec_city'] = trim($data['city']);
	   $this->getData['rec_statecode'] = trim(isset($data['StateCode'])?$data['StateCode']:'');
	   $this->getData['rec_phone'] = trim($data['phone']);
	   $this->getData['rec_email'] = trim($data['email']);
	   $this->getData['email_notification'] = (!empty($this->getData['rec_email']))?1:0;
	   $this->getData['rec_reference'] = trim($data['reference']);
	   //$this->getData['shipment_worth'] = str_replace(',','.',$data['price']);
	   //$this->getData['shipment_worth'] = str_replace(',','.',$data['price']);
	   $this->getData['goods_id'] = commonfunction::getGoodsType(trim($data['goods_type']));
	   $this->getData['goods_description'] = trim($data['goods_description']);
	   $this->getData['currency'] = trim(isset($data['currency'])?$data['currency']:'EUR');
	   $this->getData['service_id'] = 1;//$this->serviceIdbyNameInternalCode(substr($data['servicecode'],0,1));
	   $this->getData['addservice_id'] = 0;
	   $this->getData['ActionCode'] = strtolower(trim(isset($data['ActionCode'])?$data['ActionCode']:'add'));
	   $this->getData['TrackingNumber'] = trim(isset($data['ParcelNumber'])?$data['ParcelNumber']:'');
	   if(!empty($data['appdata'])){
	       $alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
	       $this->getData['app_reference'] = $alphabet[rand(0,25)].rand(0,9).date('hi');
	   }
	   $this->getData['labeltype'] = strtoupper(trim(isset($data['labeltype'])?$data['labeltype']:''));
	   $this->getData['create_ip'] =  (isset($data['create_ip']))?trim($data['create_ip']):commonfunction::loggedinIP();
	   $this->getData['shipment_type'] = (isset($data['shipment_type'])) ? $data['shipment_type'] : 4;
	   //Sender
	   $this->getData['SenderCode'] 	= (isset($data['SenderCode'])) ? $data['SenderCode'] : '';
	   $this->getData['sname'] 			= (isset($data['sname'])) ? $data['sname'] : '';
	   $this->getData['saddress1'] 		= (isset($data['saddress1'])) ? $data['saddress1'] : '';
	   $this->getData['saddress2'] 		= (isset($data['saddress2'])) ? $data['saddress2'] : '';
	   $this->getData['szipcode'] 		= (isset($data['szipcode'])) ? $data['szipcode'] : '';
	   $this->getData['scity'] 			= (isset($data['scity'])) ? $data['scity'] : '';
	   $this->getData['scountrycode'] 	= (isset($data['scountrycode'])) ? $data['scountrycode'] : '';
	   
	   
  }
  public function checkSenderCode(){
       $senderAdd = new Application_Model_Senderaddress();
	   if((!isset($this->getData['SenderCode']) || $this->getData['SenderCode']=='') && isset($this->getData['szipcode']) && isset($this->getData['scountrycode'])){
			$this->getData['senderaddress_id']  = $senderAdd->createSenderAddress($this->getData);
	  }else{
	       $this->getData['senderaddress_id']  = $senderAdd->getAddressID($this->getData);
	  }	
  }
  
  public function AddApiShipment(){ 
      $this->checkSenderCode(); //echo "<pre>";print_r($this->getData);die;
	  $this->checkRouting();
	  $label = $this->addShipment();
	  return $label;
  }
  


}

