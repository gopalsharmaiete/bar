<?php
class Application_Model_YodelLabel extends Zend_custom{
	  public $ForwarderDetail = array();
	  public $xmlCreate = array();
	  public function CreateYodelLabel($shipmentObj,$newbarcode=true){
			$this->ForwarderDetail = $shipmentObj->RecordData['forwarder_detail'];
			if($newbarcode){
			  switch($shipmentObj->RecordData[FORWARDER_ID]){
				case 29:
					$this->createXMLYodel($shipmentObj);
					$this->getCreateLabelResponse($shipmentObj);	
			    break;
				case 40:
					$this->createXMLHermesuk($shipmentObj);
					$this->getLabelResponseHermesh($shipmentObj);	
			    break;
				case 52:
					$this->createXMLRposten($shipmentObj);
					$this->getLabelResponseRposten($shipmentObj);	
			    break;
			}
		  }	
			return true;
    	
	  }
	  
	  public function getCreateLabelResponse($shipmentObj){
		   $xml_data  = file_get_contents(PRINT_OPEN_LABEL.$this->ForwarderDetail['forwarder_name'].'/xml/CreateShipment.xml');
		   $content = $this->CurlResponse('http://api.parcelhub.net/api/0.3/CreateShipment',array('Content-Type: text/xml'),$xml_data);
		try{	
			$dom = new DOMDocument;
			$dom->loadXML($content);			
		    $xml = simplexml_load_string($content);
			$json_encoded = json_encode($xml);
			$json = json_decode($json_encoded);
			
		if(!empty($dom->getElementsByTagName('Description')->item(0)->nodeValue)){
		       $this->_logger->info('Class-'.__CLASS__.',Function-'.__FUNCTION__.',Line-'.__LINE__.',Error-'.$shipmentObj->RecordData[SHIPMENT_ID].' '.$dom->getElementsByTagName('Description')->item(0)->nodeValue);
				if($shipmentObj->RecordData['API']){ 
					$objparcelnl = new ParcelnlLabel();
					$this->updateYodeltoParcelnl($objLabel);
					$objLabel->RecordData[FORWARDER_ID]	= 22;
					$objparcelnl->CreateParcelNl(true,$objLabel,array());
					return true;
				}else{
					echo "F^There is some Error With XML Data. Please Try Again!";exit;
				}
			}
		}catch(Exception $e){
		      $this->_logger->info('Class-'.__CLASS__.',Function-'.__FUNCTION__.',Line-'.__LINE__.',Error-'.$shipmentObj->RecordData[SHIPMENT_ID].' '.$dom->getElementsByTagName('Description')->item(0)->nodeValue);
		}	
		$ReturnData = array();
		$findarr = array('(',')',' ');
		$replace = array('','','');
		$labelmodel = $json->Packages->Package->ShippingInfo->Labels->Label->RawLabelData->YodelLabelModel;
		$shipmentObj->RecordData[BARCODE] 		= str_replace($findarr,$replace,$json->Packages->Package->ShippingInfo->TrackingNumber);
		$shipmentObj->RecordData['BARCODE_READABLE'] 		= $json->Packages->Package->ShippingInfo->TrackingNumber;
		$shipmentObj->RecordData[REROUTE_BARCODE] = $labelmodel->RoutingBarcode;
		$shipmentObj->RecordData[TRACENR_BARCODE] = $shipmentObj->RecordData[BARCODE];
		$shipmentObj->RecordData[TRACENR] 		= $json->ShippingInfo->ShipmentServiceProviderId;
		$pdfdata = array('ProductName'=>$labelmodel->ProductName,'ServiceDescription'=>$labelmodel->ServiceDescription,'ReturnCode'=>$labelmodel->TrackingNumbers->JDNumbers->ReturnCode,'ServiceCentreLocationName'=>$labelmodel->ServiceCentreLocationName,'HubLocationName'=>$labelmodel->HubLocationName,'MeterNumber'=>$labelmodel->MeterNumber);
		 $shipmentObj->RecordData['pdf_data'] =  $pdfdata;
		
		 if($shipmentObj->RecordData[BARCODE]==''){
		 
		 }
		$this->storeLabelData($shipmentObj,$json_encoded);
		 return true; 
		}
	  
	  public function CurlResponse($URL,$header=array(),$xml_data){
 			try{
				$ch = curl_init($URL);
				curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
				curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
				curl_setopt($ch, CURLOPT_POST, 1);
				curl_setopt($ch, CURLOPT_HTTPHEADER,$header);
				curl_setopt($ch, CURLOPT_POSTFIELDS, $xml_data);
				curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
				$content = curl_exec($ch);
				curl_close($ch);
			}catch(Exception $e){ }	
			return $content;
	  }
	  
	  public function storeLabelData($shipmentObj,$pdfdata){
		$select = $this->_db->select()
									->from(YODEL_PDF,array('*'))
									->where("barcode='".$shipmentObj->RecordData[BARCODE]."'");
									//print_r($select->__toString());die;
		$record = $this->getAdapter()->fetchRow($select);
		if(empty($record)){
		   $this->_db->insert(YODEL_PDF,array_filter(array('barcode'=>$shipmentObj->RecordData[BARCODE],'pdf_contant'=>$pdfdata)));
		}else{
		   $this->_db->update(YODEL_PDF,array('pdf_contant'=>$pdfdata),"barcode='".$shipmentObj->RecordData[BARCODE]."'");
		}
		return; 
	  }		
		
		
	  public function createXMLYodel($shipmentObj){ 
				$dom = new DOMDocument ( '1.0', 'UTF-8' );
				$root = $dom->createElement ('CreateShipment');
				$root->setAttribute ( 'xmlns', 'http://api.parcelhub.net/schemas/api/parcelhub-api-v0.3.xsd');
				$dom->appendChild ($root);
				//$this->xmlCreate['AuthenticationDetails']['Username'] 			= 'TEST001';
//				$this->xmlCreate['AuthenticationDetails']['Password'] 			= 'TEST001'; 
				
				$this->xmlCreate['AuthenticationDetails']['Username'] 			= 'PNL001';
				$this->xmlCreate['AuthenticationDetails']['Password'] 			= 'pnl2894';
				
				$this->xmlCreate['RequestedLabelFormat']      		  			= 'PDF';
				$this->xmlCreate['RequestedLabelSize']				  			= '6';
				
				$senderAdd = $this->ForwarderDetail['SenderAddress'];
				$customeradd = $this->getCustomerDetails($shipmentObj->RecordData[ADMIN_ID]);
				
				$this->xmlCreate['Shipment']['CollectionAddress']['ContactName'] = ($senderAdd[1]!='')?substr(trim($senderAdd[1]),0,35):'Parcel.nl';
				$this->xmlCreate['Shipment']['CollectionAddress']['CompanyName'] = ($senderAdd[0]!='')?substr(trim($senderAdd[0]),0,35):'Parcel.nl';
				$this->xmlCreate['Shipment']['CollectionAddress']['Email'] 		 = 'klantenservice@parcel.nl';
				$this->xmlCreate['Shipment']['CollectionAddress']['Phone'] 		 = '31748800700';
				$this->xmlCreate['Shipment']['CollectionAddress']['City'] 		 = 'Nottingham';
				$this->xmlCreate['Shipment']['CollectionAddress']['Address1']	 = 'Little Tennis Street Unit 1';
				$this->xmlCreate['Shipment']['CollectionAddress']['Postcode'] 	 = 'NG2 4EU';
				$this->xmlCreate['Shipment']['CollectionAddress']['Country'] 	 = 'GB';
				$this->xmlCreate['Shipment']['CollectionAddress']['AddressType'] = 'Business';
				
				$this->xmlCreate['Shipment']['DeliveryAddress']['ContactName']   = !empty($shipmentObj->RecordData[CONTACT]) ? substr($shipmentObj->RecordData[CONTACT],0,35) : substr($shipmentObj->RecordData[RECEIVER],0,35);
				$this->xmlCreate['Shipment']['DeliveryAddress']['CompanyName']   = substr($shipmentObj->RecordData[RECEIVER],0,35);
				$this->xmlCreate['Shipment']['DeliveryAddress']['Email'] 		 = !empty($shipmentObj->RecordData[EMAIL])?$shipmentObj->RecordData[EMAIL]:$customeradd['email'];
				$this->xmlCreate['Shipment']['DeliveryAddress']['Phone'] 		 = preg_replace('/\s+/', '',!empty($shipmentObj->RecordData[PHONE])?$shipmentObj->RecordData[PHONE]:'31748800700');
				$this->xmlCreate['Shipment']['DeliveryAddress']['City'] 		 = $shipmentObj->RecordData[CITY];
				$this->xmlCreate['Shipment']['DeliveryAddress']['Area'] 		 = substr($shipmentObj->RecordData[STREET],0,32);
				$address1 = trim($shipmentObj->RecordData[STREETNR].' '.$shipmentObj->RecordData[ADDRESS].' '.$shipmentObj->RecordData[STREET2]);
				$this->xmlCreate['Shipment']['DeliveryAddress']['Address1']	 	 = substr((trim($address1)!='')?trim($address1):$shipmentObj->RecordData[STREET],0,35);
				
				$postcodestring = preg_replace('/\s+/', '',preg_replace('/[^A-Za-z0-9 ]/', '',$shipmentObj->RecordData[ZIPCODE]));
				
				$this->xmlCreate['Shipment']['DeliveryAddress']['Postcode'] 	 = substr($postcodestring,0,-3).' '.substr($postcodestring,-3);
				$this->xmlCreate['Shipment']['DeliveryAddress']['Country'] 	 	 = $shipmentObj->RecordData['rec_cncode'];
				 if($shipmentObj->RecordData[SERVICE_ID]==1){
				  $this->xmlCreate['Shipment']['DeliveryAddress']['AddressType'] = 'Residential';
				 }else{
				  $this->xmlCreate['Shipment']['DeliveryAddress']['AddressType'] = 'Business';
			   }
				
				
				$this->xmlCreate['Shipment']['Packages']['Package']['Dimensions']['Length'] = 0;
				$this->xmlCreate['Shipment']['Packages']['Package']['Dimensions']['Width'] = 0;
				$this->xmlCreate['Shipment']['Packages']['Package']['Dimensions']['Height'] = 0;
				$this->xmlCreate['Shipment']['Packages']['Package']['Weight'] = $shipmentObj->RecordData[WEIGHT];
				
				$this->xmlCreate['Shipment']['Packages']['Package']['Value'] = 0;
				$this->xmlCreate['Shipment']['Packages']['Package']['ValueCurrency'] = 'GBP';
				$this->xmlCreate['Shipment']['Packages']['Package']['Contents'] = $shipmentObj->RecordData[REFERENCE];
				
				if($shipmentObj->RecordData[SERVICE_ID]==7 || $shipmentObj->RecordData[SERVICE_ID]==146){
				   $this->xmlCreate['Shipment']['Packages']['Package']['Value'] = $shipmentObj->RecordData['cod_price'];
				   $this->xmlCreate['Shipment']['Packages']['Package']['ValueCurrency'] = $shipmentObj->RecordData['currency'];
				   $this->xmlCreate['Shipment']['Packages']['Package']['Contents'] = $shipmentObj->RecordData['goods_id'];
				}
				
				$this->xmlCreate['Shipment']['TypeOfShipment'] = 'Delivery';
				$this->xmlCreate['Shipment']['ContentsDescription'] = $shipmentObj->RecordData[REFERENCE];
				
			 if($shipmentObj->RecordData['shipment_worth']>0){
				$this->xmlCreate['Shipment']['CustomsInfo']['DescriptionOfGoods'] = ($shipmentObj->RecordData['goods_description']!='')?$shipmentObj->RecordData['goods_description']:'Commercial';
				$this->xmlCreate['Shipment']['CustomsInfo']['DeclaredValue'] = ($shipmentObj->RecordData['shipment_worth']>0)?round($shipmentObj->RecordData['shipment_worth']):0;
				$this->xmlCreate['Shipment']['CustomsInfo']['ExportReason'] = ($shipmentObj->RecordData['goods_id']!='')?$shipmentObj->RecordData['goods_id']:'Documents';
				$this->xmlCreate['Shipment']['CustomsInfo']['IsDutiable'] = 'false';
				$this->xmlCreate['Shipment']['CustomsInfo']['TermsOfTrade'] = 'DDU';
				$this->xmlCreate['Shipment']['CustomsInfo']['DeclaredCurrency'] = 'GBP'; 
			}	
			$first2digit 		= 	strtoupper(substr($postcodestring,0,2));
			$first3digit 		= 	strtoupper(substr($postcodestring,0,2));
			$first4digit 		= 	strtoupper(substr($postcodestring,0,2));
			$thirdfouthdigit 	= 	strtoupper(substr($postcodestring,0,2));
			$thirddigit 		= 	strtoupper(substr($postcodestring,0,2));
				
			 if($first2digit=='JE' || $first2digit=='GY'){	
			        $this->xmlCreate['Shipment']['ServiceInfo']['ServiceId'] = 56;
					$this->xmlCreate['Shipment']['ServiceInfo']['ServiceProviderId'] = 10;
					$this->xmlCreate['Shipment']['ServiceInfo']['ServiceCustomerUID'] = 6422;
			  }elseif($first2digit=='BT'){	
			        $this->xmlCreate['Shipment']['ServiceInfo']['ServiceId'] = 164;
					$this->xmlCreate['Shipment']['ServiceInfo']['ServiceProviderId'] = 10;
					$this->xmlCreate['Shipment']['ServiceInfo']['ServiceCustomerUID'] = 6426;
			  }elseif($first2digit=='HS' || $first2digit=='IM' || $first3digit=='IOM' || $first4digit=='FK18' || $first4digit=='FK19' || $first2digit=='IV' || $first4digit=='KA27' || $first4digit=='KA28' || $first2digit=='KW' || ($first2digit=='PA' && $thirdfouthdigit>=20) || ($first2digit=='PH' && $thirdfouthdigit>=17) || ($first2digit=='PO' && $thirdfouthdigit>=30) || ($first2digit=='TR' && $thirdfouthdigit>=21) || $first2digit=='ZE'){	
			        $this->xmlCreate['Shipment']['ServiceInfo']['ServiceId'] = 224;
					$this->xmlCreate['Shipment']['ServiceInfo']['ServiceProviderId'] = 10;
					$this->xmlCreate['Shipment']['ServiceInfo']['ServiceCustomerUID'] = 6455;
			  }elseif($shipmentObj->RecordData['service_id']==1){	
					$this->xmlCreate['Shipment']['ServiceInfo']['ServiceId'] = 56;
					$this->xmlCreate['Shipment']['ServiceInfo']['ServiceProviderId'] = 10;
					$this->xmlCreate['Shipment']['ServiceInfo']['ServiceCustomerUID'] = 6422;
			  }elseif($shipmentObj->RecordData['service_id']==2){
					$this->xmlCreate['Shipment']['ServiceInfo']['ServiceId'] = 251;
					$this->xmlCreate['Shipment']['ServiceInfo']['ServiceProviderId'] = 10;
					$this->xmlCreate['Shipment']['ServiceInfo']['ServiceCustomerUID'] = 6396;
			  }else{
			       $this->xmlCreate['Shipment']['ServiceInfo']['ServiceId'] = 251;
				   $this->xmlCreate['Shipment']['ServiceInfo']['ServiceProviderId'] = 10;
				   $this->xmlCreate['Shipment']['ServiceInfo']['ServiceCustomerUID'] = 6396;
			      
			  }	
				$this->xmlCreate['Shipment']['Reference1'] = $shipmentObj->RecordData[REFERENCE];
				$this->xmlCreate['Shipment']['Reference2'] = $shipmentObj->RecordData[REFERENCE];
				
				$this->xmlCreate['Shipment']['CollectionDetails']['CollectionDate'] = date('Y-m-d');
				$this->xmlCreate['Shipment']['CollectionDetails']['CollectionReadyTime'] = date('H:i:s');
				$this->xmlCreate['Shipment']['CollectionDetails']['LocationCloseTime'] = date('H:i:s');
				
				$this->createXmlstructure($this->xmlCreate,$dom,$root);
				
				$saveData = $dom->save(PRINT_SAVE_LABEL.$this->ForwarderDetail['forwarder_name'].'/xml/CreateShipment.xml');
				return PRINT_OPEN_LABEL.$this->ForwarderDetail['forwarder_name'].'/xml/CreateShipment.xml';	
    	}
	/**
	*Craete xml for create shipment
	*Function : createXML()
	*function create XML for create shipment at yodel
	**/
	 public function createXMLHermesuk($shipmentObj){ 
				$dom = new DOMDocument ( '1.0', 'UTF-8' );
				$root = $dom->createElement ('Shipment');
				$root->setAttribute ( 'xmlns', 'http://api.parcelhub.net/schemas/api/parcelhub-api-v0.4.xsd');
				$dom->appendChild ($root);
				
				$senderAdd = $this->ForwarderDetail['SenderAddress'];
				$customeradd = $this->getCustomerDetails($shipmentObj->RecordData[ADMIN_ID]);
				
				$this->xmlCreate['CollectionAddress']['ContactName'] = ($senderAdd[1]!='')?substr(trim($senderAdd[1]),0,35):'Parcel.nl';
				$this->xmlCreate['CollectionAddress']['CompanyName'] = ($senderAdd[0]!='')?substr(trim($senderAdd[0]),0,35):'Parcel.nl';
				$this->xmlCreate['CollectionAddress']['Email'] 		 = 'klantenservice@parcel.nl';
				$this->xmlCreate['CollectionAddress']['Phone'] 		 = '31748800700';
				$this->xmlCreate['CollectionAddress']['City'] 		 = 'Nottingham';
				$this->xmlCreate['CollectionAddress']['Address1']	 = 'Little Tennis Street Unit 1';
				$this->xmlCreate['CollectionAddress']['Postcode'] 	 = 'NG2 4EU';
				$this->xmlCreate['CollectionAddress']['Country'] 	 = 'GB';
				$this->xmlCreate['CollectionAddress']['AddressType'] = 'Business';
				
				$this->xmlCreate['DeliveryAddress']['ContactName']   = !empty($shipmentObj->RecordData[CONTACT]) ? substr($shipmentObj->RecordData[CONTACT],0,35) : substr($shipmentObj->RecordData[RECEIVER],0,35);
				$this->xmlCreate['DeliveryAddress']['CompanyName']   = substr($shipmentObj->RecordData[RECEIVER],0,35);
				$this->xmlCreate['DeliveryAddress']['Email'] 		 = !empty($shipmentObj->RecordData[EMAIL])?$shipmentObj->RecordData[EMAIL]:$customeradd['email'];
				$this->xmlCreate['DeliveryAddress']['Phone'] 		 = preg_replace('/\s+/', '',!empty($shipmentObj->RecordData[PHONE])?$shipmentObj->RecordData[PHONE]:'31748800700');
				
				$address1 = trim($shipmentObj->RecordData[ADDRESS].' '.$shipmentObj->RecordData[STREET2]);
				$this->xmlCreate['DeliveryAddress']['Address1']	 	 = substr($shipmentObj->RecordData[STREET].' '.$shipmentObj->RecordData[STREETNR],0,32);
				
				if(trim($address1)!=''){
				 $this->xmlCreate['DeliveryAddress']['Address2']	 	 = substr(trim($address1),0,30);
				}
				$this->xmlCreate['DeliveryAddress']['City'] 		 = $shipmentObj->RecordData[CITY];
				
				$postcodestring = preg_replace('/\s+/', '',preg_replace('/[^A-Za-z0-9 ]/', '',$shipmentObj->RecordData[ZIPCODE]));
				$this->xmlCreate['DeliveryAddress']['Postcode'] 	 = substr($postcodestring,0,-3).' '.substr($postcodestring,-3);
				$this->xmlCreate['DeliveryAddress']['Country'] 	 	 = $shipmentObj->RecordData['rec_cncode'];
				
				if($shipmentObj->RecordData[SERVICE_ID]==1){
				  $this->xmlCreate['DeliveryAddress']['AddressType'] = 'Residential';
				 }else{
				  $this->xmlCreate['DeliveryAddress']['AddressType'] = 'Business';
			   }
			    $this->xmlCreate['Reference1'] = substr($shipmentObj->RecordData[REFERENCE],0,20);
				$this->xmlCreate['Reference2'] = substr($shipmentObj->RecordData[REFERENCE],0,20);
				
				$this->xmlCreate['ContentsDescription'] = ($shipmentObj->RecordData['goods_description']!='')?$shipmentObj->RecordData['goods_description']:$shipmentObj->RecordData[REFERENCE];
				
				$this->xmlCreate['Packages']['PackageType'] = 'Parcel';
				$this->xmlCreate['Packages']['Package']['Dimensions']['Length'] = 0;
				$this->xmlCreate['Packages']['Package']['Dimensions']['Width'] = 0;
				$this->xmlCreate['Packages']['Package']['Dimensions']['Height'] = 0;
				$this->xmlCreate['Packages']['Package']['Weight'] = $shipmentObj->RecordData[WEIGHT];
				
				$this->xmlCreate['Packages']['Package']['Value'] = ($shipmentObj->RecordData['shipment_worth']>0)?round($shipmentObj->RecordData['shipment_worth']):0;
				$this->xmlCreate['Packages']['Package']['Contents'] = ($shipmentObj->RecordData['goods_id']!='')?$shipmentObj->RecordData['goods_id']:'Documents';
				
				$this->xmlCreate['ServiceInfo']['ServiceId'] = 5011;
				$this->xmlCreate['ServiceInfo']['ServiceProviderId'] = 9;
				$this->xmlCreate['ServiceInfo']['ServiceCustomerUID'] = 2;
				   
				$this->createXmlstructure($this->xmlCreate,$dom,$root);
				
				$saveData = $dom->save(PRINT_SAVE_LABEL.$this->ForwarderDetail['forwarder_name'].'/xml/CreateShipment.xml');
				return PRINT_OPEN_LABEL.$this->ForwarderDetail['forwarder_name'].'/xml/CreateShipment.xml';		
    	}
		
	 
	 public function getLabelResponseHermesh($shipmentObj){
		    try{
			$xml_data  = file_get_contents(PRINT_OPEN_LABEL.$this->ForwarderDetail['forwarder_name'].'/xml/CreateShipment.xml');
			$authurl = "http://api.parcelhub.net/api/0.4/token";
			$URL = "http://api.parcelhub.net/api/0.4/Shipment?RequestedLabelSize=6&RequestedLabelFormat=PDF";
			$authenticate = $this->CurlResponse($authurl,array('Content-Type: text/xml'),"grant_type=password&username=PNL001&password=pnl2894");
			$auth = json_decode($authenticate); 
			
			$labelcontent = $this->CurlResponse($URL,array('Content-Type: text/xml','Authorization: bearer '.$auth->access_token),$xml_data);
			$xml = simplexml_load_string($labelcontent);
			$json_encoded = json_encode($xml);
			$json = json_decode($json_encoded);
		   //echo "<pre>";print_r($json);die;
		 if(isset($json->Message)){
		        $this->_logger->info('Class-'.__CLASS__.',Function-'.__FUNCTION__.',Line-'.__LINE__.',Error-'.$shipmentObj->RecordData[SHIPMENT_ID].' '.$json->Message);
				if($shipmentObj->RecordData['API']){ 
					$objparcelnl = new ParcelnlLabel();
					$this->updateYodeltoParcelnl($objLabel);
					$objLabel->RecordData[FORWARDER_ID]	= 22;
					$objparcelnl->CreateParcelNl(true,$objLabel,array());
					return true;
				}else{
					echo "F^There is some Error With XML Data. Please Try Again!";exit;
				}
			}
		 }catch(Exception $e){
		     $this->_logger->info('Class-'.__CLASS__.',Function-'.__FUNCTION__.',Line-'.__LINE__.',Error-'.$shipmentObj->RecordData[SHIPMENT_ID].' '.$e->getMessage());
		 }	
		$ReturnData = array();
		$findarr = array('(',')',' ');
		$replace = array('','','');
		
		$labelmodel = $json->Packages->Package->PackageShippingInfo->Labels->Label->RawLabelData->RawLabelDataModel->Packages->RawLabelPiece;
		//$labelmodel1 = $json->Packages->Package->PackageShippingInfo->Labels->Label->RawLabelData->HubEuropeRawLabelModel;
		
		$shipmentObj->RecordData[BARCODE] 		= str_replace($findarr,$replace,$labelmodel->Courier2Barcode1);
		$shipmentObj->RecordData[REROUTE_BARCODE] = $json->ShippingInfo->ParcelhubTrackingNumber;
		$shipmentObj->RecordData[TRACENR] 		= $shipmentObj->RecordData[BARCODE];
		$shipmentObj->RecordData[TRACENR_BARCODE] 		= $shipmentObj->RecordData[BARCODE];
		$shipmentObj->RecordData['ParcelhubShipmentId']    = $json->ParcelhubShipmentId;
		
		$labeldata = array('SortLevel1'=>$labelmodel->Courier2SortLevel1,'SortLevel2'=>(!is_object($labelmodel->Courier2SortLevel2)?$labelmodel->Courier2SortLevel2:''),'SortLevel3'=>(!is_object($labelmodel->Courier2SortLevel3)?$labelmodel->Courier2SortLevel3:''),'SortLevel4'=>(!is_object($labelmodel->Courier2SortLevel4)?$labelmodel->Courier2SortLevel4:''),'SortLevel5'=>(!is_object($labelmodel->Courier2SortLevel5)?$labelmodel->Courier2SortLevel5:''),'ReturnCode'=>(!is_object($labelmodel->ReturnCode)?$labelmodel->ReturnCode:''),'BarcodeHumanReadable'=>$labelmodel->Courier2Barcode1HumanReadable,'Entity1Key'=>$labelmodel->Entity1Description,'Entity2Key'=>$labelmodel->Entity2Description,'Entity1Value'=>$labelmodel->Entity1Value,'Entity2Value'=>$labelmodel->Entity2Value,'ClientName'=>(!is_object ($labelmodel->Courier1LabelCourierID))?$labelmodel->Courier1LabelCourierID:'Hermes','ParcelhubShipmentId'=>$shipmentObj->RecordData['ParcelhubShipmentId']);
		
		 $shipmentObj->RecordData['pdf_data'] = $labeldata;
		if($shipmentObj->RecordData[BARCODE]==''){
		
		}
		$this->storeLabelData($shipmentObj,json_encode($labeldata));
		 return true; 
		}
		
	 public function createXMLRposten($shipmentObj){ 
				$dom = new DOMDocument ( '1.0', 'UTF-8' );
				$root = $dom->createElement ('Shipment');
				$root->setAttribute ( 'xmlns', 'http://api.parcelhub.net/schemas/api/parcelhub-api-v0.4.xsd');
				$dom->appendChild ($root);
				
				$senderAdd = $this->ForwarderDetail['SenderAddress'];
				$customeradd = $this->getCustomerDetails($shipmentObj->RecordData[ADMIN_ID]);
				
				$this->xmlCreate['CollectionAddress']['ContactName'] = ($senderAdd[1]!='')?substr(trim($senderAdd[1]),0,35):'Parcel.nl';
				$this->xmlCreate['CollectionAddress']['CompanyName'] = ($senderAdd[0]!='')?substr(trim($senderAdd[0]),0,35):'Parcel.nl';
				$this->xmlCreate['CollectionAddress']['Email'] 		 = 'klantenservice@parcel.nl';
				$this->xmlCreate['CollectionAddress']['Phone'] 		 = '31748800700';
				$this->xmlCreate['CollectionAddress']['City'] 		 = 'Nottingham';
				$this->xmlCreate['CollectionAddress']['Address1']	 = 'Little Tennis Street Unit 1';
				$this->xmlCreate['CollectionAddress']['Postcode'] 	 = 'NG2 4EU';
				$this->xmlCreate['CollectionAddress']['Country'] 	 = 'GB';
				$this->xmlCreate['CollectionAddress']['AddressType'] = 'Business';
				
				$this->xmlCreate['DeliveryAddress']['ContactName']   = !empty($shipmentObj->RecordData[CONTACT]) ? substr($shipmentObj->RecordData[CONTACT],0,35) : substr($shipmentObj->RecordData[RECEIVER],0,35);
				$this->xmlCreate['DeliveryAddress']['CompanyName']   = substr($shipmentObj->RecordData[RECEIVER],0,35);
				$this->xmlCreate['DeliveryAddress']['Email'] 		 = !empty($shipmentObj->RecordData[EMAIL])?$shipmentObj->RecordData[EMAIL]:$customeradd['email'];
				$this->xmlCreate['DeliveryAddress']['Phone'] 		 = preg_replace('/\s+/', '',!empty($shipmentObj->RecordData[PHONE])?$shipmentObj->RecordData[PHONE]:'31748800700');
				
				$address1 = trim($shipmentObj->RecordData[ADDRESS].' '.$shipmentObj->RecordData[STREET2]);
				$this->xmlCreate['DeliveryAddress']['Address1']	 	 = substr($shipmentObj->RecordData[STREET].' '.$shipmentObj->RecordData[STREETNR],0,32);
				
				if(trim($address1)!=''){
				 $this->xmlCreate['DeliveryAddress']['Address2']	 	 = substr(trim($address1),0,30);
				}
				$this->xmlCreate['DeliveryAddress']['City'] 		 = $shipmentObj->RecordData[CITY];
				
				$postcodestring = preg_replace('/\s+/', '',preg_replace('/[^A-Za-z0-9 ]/', '',$shipmentObj->RecordData[ZIPCODE]));
				$this->xmlCreate['DeliveryAddress']['Postcode'] 	 = substr($postcodestring,0,-3).' '.substr($postcodestring,-3);
				$this->xmlCreate['DeliveryAddress']['Country'] 	 	 = $shipmentObj->RecordData['rec_cncode'];
				
				if($shipmentObj->RecordData[SERVICE_ID]==1){
				  $this->xmlCreate['DeliveryAddress']['AddressType'] = 'Residential';
				 }else{
				  $this->xmlCreate['DeliveryAddress']['AddressType'] = 'Business';
			   }
			    $this->xmlCreate['Reference1'] = substr($shipmentObj->RecordData[REFERENCE],0,20);
				$this->xmlCreate['Reference2'] = substr($shipmentObj->RecordData[REFERENCE],0,20);
				
				$this->xmlCreate['ContentsDescription'] = ($shipmentObj->RecordData['goods_description']!='')?$shipmentObj->RecordData['goods_description']:$shipmentObj->RecordData[REFERENCE];
				
				$this->xmlCreate['Packages']['PackageType'] = 'Parcel';
				$this->xmlCreate['Packages']['Package']['Dimensions']['Length'] = 0;
				$this->xmlCreate['Packages']['Package']['Dimensions']['Width'] = 0;
				$this->xmlCreate['Packages']['Package']['Dimensions']['Height'] = 0;
				$this->xmlCreate['Packages']['Package']['Weight'] = $shipmentObj->RecordData[WEIGHT];
				
				$this->xmlCreate['Packages']['Package']['Value'] = ($shipmentObj->RecordData['shipment_worth']>0)?round($shipmentObj->RecordData['shipment_worth']):0;
				$this->xmlCreate['Packages']['Package']['Contents'] = ($shipmentObj->RecordData['goods_id']!='')?$shipmentObj->RecordData['goods_id']:'Documents';
				
				
				$this->xmlCreate['Packages']['Package']['PackageCustomsDeclaration']['ContentsDescription'] = ($shipmentObj->RecordData['goods_id']!='')?$shipmentObj->RecordData['goods_id']:'Documents';
				$this->xmlCreate['Packages']['Package']['PackageCustomsDeclaration']['Weight'] = $shipmentObj->RecordData[WEIGHT];
				$this->xmlCreate['Packages']['Package']['PackageCustomsDeclaration']['Value'] = ($shipmentObj->RecordData['shipment_worth']>0)?round($shipmentObj->RecordData['shipment_worth']):0;
				$this->xmlCreate['Packages']['Package']['PackageCustomsDeclaration']['CountryOfOrigin'] = 'GB';
				$this->xmlCreate['Packages']['Package']['PackageCustomsDeclaration']['HSTariffNumber'] = '9703000000';
				$this->xmlCreate['Packages']['Package']['PackageCustomsDeclaration']['Quantity'] = 1;
				
				
				$this->xmlCreate['ServiceInfo']['ServiceId'] = 25011;
				$this->xmlCreate['ServiceInfo']['ServiceProviderId'] = 31;
				$this->xmlCreate['ServiceInfo']['ServiceCustomerUID'] = 4;
				
				$this->xmlCreate['CustomsDeclarationInfo']['CategoryOfItem'] = 'Sold';
				$this->xmlCreate['CustomsDeclarationInfo']['CategoryOfItemExplanation'] = 'Sold '.($shipmentObj->RecordData['goods_id']!='')?$shipmentObj->RecordData['goods_id']:'Documents';
				$this->xmlCreate['CustomsDeclarationInfo']['TermsOfTrade']		= 'DutiesAndTaxesUnpaid';
				$this->xmlCreate['CustomsDeclarationInfo']['PostalCharges'] = ($shipmentObj->RecordData['shipment_worth']>0)?round($shipmentObj->RecordData['shipment_worth']):0;
				$this->xmlCreate['CustomsDeclarationInfo']['ImportersContactDetails'] = $this->xmlCreate['DeliveryAddress']['Phone'];
				   
				$this->createXmlstructure($this->xmlCreate,$dom,$root);
				$saveData = $dom->save(PRINT_SAVE_LABEL.$this->ForwarderDetail['forwarder_name'].'/xml/CreateShipment.xml');
				return PRINT_OPEN_LABEL.$this->ForwarderDetail['forwarder_name'].'/xml/CreateShipment.xml';		
    	}
		
	 public function getLabelResponseRposten($shipmentObj){
		   try{
			$xml_data  = file_get_contents(PRINT_OPEN_LABEL.$this->ForwarderDetail['forwarder_name'].'/xml/CreateShipment.xml');
			$authurl = "http://api.parcelhub.net/api/0.4/token";
			$URL = "http://api.parcelhub.net/api/0.4/Shipment?RequestedLabelSize=6&RequestedLabelFormat=PDF";
			$authenticate = $this->CurlResponse($authurl,array('Content-Type: text/xml'),"grant_type=password&username=PNL001&password=pnl2894");
			$auth = json_decode($authenticate); 
			
			$labelcontent = $this->CurlResponse($URL,array('Content-Type: text/xml','Authorization: bearer '.$auth->access_token),$xml_data);
			$xml = simplexml_load_string($labelcontent);
			$json_encoded = json_encode($xml);
			$json = json_decode($json_encoded);
		   echo "<pre>";print_r($json);die;
		 if(isset($json->Message)){
		        $this->_logger->info('Class-'.__CLASS__.',Function-'.__FUNCTION__.',Line-'.__LINE__.',Error-'.$shipmentObj->RecordData[SHIPMENT_ID].' '.$json->Message);
				if($shipmentObj->RecordData['API']){ 
					$objparcelnl = new ParcelnlLabel();
					$this->updateYodeltoParcelnl($objLabel);
					$objLabel->RecordData[FORWARDER_ID]	= 22;
					$objparcelnl->CreateParcelNl(true,$objLabel,array());
					return true;
				}else{
					echo "F^There is some Error With XML Data. Please Try Again!";exit;
				}
			}
		 }catch(Exception $e){
		     $this->_logger->info('Class-'.__CLASS__.',Function-'.__FUNCTION__.',Line-'.__LINE__.',Error-'.$shipmentObj->RecordData[SHIPMENT_ID].' '.$e->getMessage());
		 }	
		$ReturnData = array();
		$findarr = array('(',')',' ');
		$replace = array('','','');
		
		$labelmodel = $json->Packages->Package->PackageShippingInfo->Labels->Label->RawLabelData->RawLabelDataModel->Packages->RawLabelPiece;
		$labelmodel1 = $json->Packages->Package->PackageShippingInfo->Labels->Label->RawLabelData->HubEuropeRawLabelModel;
		
		$shipmentObj->RecordData[BARCODE] 		= str_replace($findarr,$replace,$json->ShippingInfo->CourierTrackingNumber);
		$shipmentObj->RecordData[REROUTE_BARCODE] = $json->ShippingInfo->ParcelhubTrackingNumber;
		$shipmentObj->RecordData[TRACENR] 		= $shipmentObj->RecordData[BARCODE];
		$shipmentObj->RecordData[TRACENR_BARCODE] 		= $shipmentObj->RecordData[BARCODE];
		$shipmentObj->RecordData['ParcelhubShipmentId']    = $json->ParcelhubShipmentId;
		
		$labeldata = array('TermsOfTrade'=>$json->CustomsDeclarationInfo->TermsOfTrade,'ImportersContactDetails'=>$json->CustomsDeclarationInfo->ImportersContactDetails,'Tarif_number'=>'9703000000');
		$shipmentObj->RecordData['pdf_data'] = $labeldata;
		$shipmentObj->RecordData['country_name'] = $objLabel->RecordData['rec_country_code'];
		$shipmentObj->RecordData['origin_country'] = 'GB';
		$shipmentObj->RecordData['Tarif_number'] = '9703000000';
		
		if($shipmentObj->RecordData[BARCODE]==''){
			
		}
		$this->storeLabelData($shipmentObj,json_encode($labeldata));
		 return true; 
		}
	  
	  
		
		
	  public function createXmlstructure($struct, DOMDocument $dom, DOMElement $parent){
		   $struct = ( array ) $struct;

              foreach ( $struct as $key => $value ) {//print_r($key);
               if ($value === false) {
                $value = 0;
               } elseif ($value === true) {
                $value = 1;
               }

               if (ctype_digit ( ( string ) $key )) {
                $key = 'key_' . $key;
               }

               if (is_array ( $value ) || is_object ( $value )) {
                $element = $dom->createElement ($key);
                $this->createXmlstructure ( $value, $dom, $element );
               } else {
                $element = $dom->createElement ($key);
				if($key=='Value' || $key=='PostalCharges'){
					$element->setAttribute('Currency', "GBP");
				}
                $element->appendChild ( $dom->createTextNode ( $value ) );
               }
            $parent->appendChild ( $element );
   		 }
	}
}