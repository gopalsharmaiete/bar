<?php
class Application_Model_Adminlogin extends Zend_Custom
{
  public function getUserconfigs($user_id){
     try{
	 $select = $this->_db->select()
						  ->from(array('UD'=>USERS_DETAILS),array('*'))
						  ->joininner(array('US'=>USERS_SETTINGS),"US.user_id=UD.user_id",array('*'))
						  ->where('UD.user_id=?', $user_id);
	 }catch(Exception $e){
	   //echo $e->getMessage();die;
	 }
	 
	 return $this->getAdapter()->fetchRow($select);					  
  }

}

