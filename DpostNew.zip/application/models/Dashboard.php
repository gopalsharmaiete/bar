<?php

class Application_Model_Dashboard extends Zend_Custom
{
   public function AddedParcel(){
        $where = $this->LevelClause();
		$select = $this->_db->select()
									->from(array('BT' =>SHIPMENT_BARCODE),array("COUNT(1) AS CNT"))
									->joininner(array('ST'=>SHIPMENT),"ST.shipment_id=BT.shipment_id",array(""))
									->joininner(array('AT' =>USERS_DETAILS),"AT.user_id=ST.user_id",array(""))
									->where("BT.checkin_status='0' AND BT.delete_status='0' AND ST.delete_status='0' AND DATE(ST.create_date)= CURDATE()".$where);
									//print_r($select->__toString());die;
		$count = $this->getAdapter()->fetchRow($select);
		return $count['CNT'];
   }
   public function DeliveredParcel(){
        $where = $this->LevelClause();
		$select = $this->_db->select()
									->from(array('BT' =>SHIPMENT_BARCODE),array("COUNT(1) AS CNT"))
									->joininner(array('ST'=>SHIPMENT),"ST.shipment_id=BT.shipment_id",array(""))
									->joininner(array('AT' =>USERS_DETAILS),"AT.user_id=ST.user_id",array(""))
									->joininner(array('BD'=>SHIPMENT_BARCODE_DETAIL),"BD.barcode_id=BT.barcode_id",array(""))
									->where("BT.checkin_status='1' AND BT.delivery_status='1' AND BT.delete_status='0' AND ST.delete_status='0' AND DATE(BD.delivery_date)= CURDATE()".$where);
									//print_r($select->__toString());die;
		$count = $this->getAdapter()->fetchRow($select);
		return $count['CNT'];
   }
   public function ErrorParcel(){
        $where = $this->LevelClause();
		$select = $this->_db->select()
									->from(array('BT' =>SHIPMENT_BARCODE),array("COUNT(1) AS CNT"))
									->joininner(array('ST'=>SHIPMENT),"ST.shipment_id=BT.shipment_id",array(""))
									->joininner(array('AT' =>USERS_DETAILS),"AT.user_id=ST.user_id",array(""))
									->where("BT.checkin_status='1' AND BT.error_status='1' AND BT.delete_status='0' AND ST.delete_status='0'".$where);
									//print_r($select->__toString());die;
		$count = $this->getAdapter()->fetchRow($select);
		return $count['CNT'];
   }
   
   public function PlannedPickup(){
		$select = $this->_db->select()
									->from(array('DH' =>DRIVER_HISTORY),array('pickup_time'))
									->joininner(array('DD'=>DRIVER_DETAIL_TABLE),"DH.driver_id=DD.driver_id",array("driver_name"))
									->where("DH.user_id='".$this->Useconfig['user_id']."' AND DH.assign_date= CURDATE()")
									->group("DH.user_id");
									//print_r($select->__toString());die;
		return $this->getAdapter()->fetchRow($select);
   }
   public function openInvoices(){
        $where = $this->LevelClause();
		$select = $this->_db->select()
									->from(array('IV' =>INVOICE),array('*'))
									->joininner(array('AT' =>USERS_DETAILS),"AT.user_id=IV.user_id",array(""))
									->where("IV.payment_status='0'".$where)
									->order("IV.invoice_date DESC")
									->limit(5);
									//print_r($select->__toString());die;
		return $this->getAdapter()->fetchAll($select);
   }
   public function openTickets(){
        $where = $this->LevelClause();
		$select = $this->_db->select()
									->from(array('IV' =>INVOICE),array('*'))
									->joininner(array('AT' =>USERS_DETAILS),"AT.user_id=IV.user_id",array(""))
									->where("IV.payment_status='0'".$where)
									->order("IV.invoice_date DESC")
									->limit(5);
									//print_r($select->__toString());die;
		return $this->getAdapter()->fetchAll($select);
   }
   
   public function shopAPiorders(){
      $shopobjects = new Application_Model_Shopapi();
	  $shoplists = $shopobjects->getShopList();
	  $totalorder = 0;
	  foreach($shoplists as $shoplist){
	    $shopobjects->getData = $shoplist;
		$shopobjects->getData['onlycount'] = 1;
		$totalorder =  $totalorder + $shopobjects->getOrderCount();
	  }
	  echo $totalorder;die;
   }
}

