<?php
//ini_set('display_errors','1');
abstract class Application_Model_Shipmentlabel extends Zend_Custom
{
    // array containing all the extended classes
    private $_exts = array();
    public $_this;
	public $shipment_id = array();
	public $shipment_type = 1;
	public $bulkshipment = array();
	public $trackingdetail = array();
	public function __construct(){
	  parent::__construct();
	  $_this = $this;
	  global $objSession;
	}
	
    public function CreateLabel(){
	     $shipmentdetails = $this->getShipmentDetails();
		 global $labelObj,$objSession;
		 $labelObj->SetlabelFormat();
		 $this->_insertbrcode = true;
		 foreach($shipmentdetails as $shipments){
		      unset($this->RecordData);
			  $this->RecordData = $shipments;
			  $ReferenceNo =  $this->SystemGeneratedReference();
			  //$this->RecordData[FORWARDER_ID] = 1;
			  //$this->RecordData['country_id'] = 17;
			  //$this->RecordData['addservice_id'] = 111;
			  $this->RecordData[LABEL_DATE] = commonfunction::DateNow();
			  $this->getParcelPrice();
			   $file = 'PDF_'.time().'_'.$this->RecordData[SHIPMENT_ID].'.pdf';
			   $this->RecordData['forwarder_detail'] = $this->ForwarderDetail();
			  for($q=1;$q<=$this->RecordData[QUANTITY];$q++){ 
			    $labelObj->ParcelCount =  $labelObj->ParcelCount + 1;
				$this->RecordData['parcelcount'] = $q;
				$this->RecordData['ShipmentCount'] = $q.'/'.$this->RecordData[QUANTITY];
				unset($this->RecordData['tracenr']);
				unset($this->RecordData['tracenr_barcode']);
				unset($this->RecordData['barcode']);
				unset($this->RecordData['reroute_barcode']);
				$this->RecordData[REFERENCE] = $this->multireference($ReferenceNo,$q);
			     $this->GenerateBarcodeData(true);
				 $labelObj->outputparam = $this->RecordData;
				 $labelObj->labelAllForwarder();
				 $this->trackingdetail['ParcelNumber'.$q] = 'PARCEL NUMBER :'.$this->RecordData[TRACENR_BARCODE];
				 $this->trackingdetail['TrackingURL'.$q]  = 'TRACKING URL: '.BASE_URL.'Parceltracking/tracking/tockenno/'.Zend_Encript_Encription::encode($this->RecordData[BARCODE_ID]); 
				 
			  } 
			  $this->AutocheckinReturn();
			  switch($this->RecordData['shipment_type']){
			     case 2:
				   if($this->getData['shipment_mode']=='Print'){
				    ob_end_clean();
			    	$labelObj->Output($file,'D');
			   		$labelObj->PopUpLabel();
				  }	
				 break;
				case 4:
				case 10:
			       $labelObj->Output(PRINT_SAVE_LABEL.$this->RecordData['forwarder_detail']['forwarder_name'].'/'.$file,'F');
			       return array('Success'=>array('SuccessMessage' => 'MESSAGE: Shipment has created successfully.....',
                        'Forwarder'=>'FORWARDER: '.$this->RecordData['forwarder_detail']['forwarder_name'],
                        'TrackingDetails'=>$this->trackingdetail,
                        'LabelURL'=>'LABEL URL: '.PRINT_OPEN_LABEL.$this->RecordData['forwarder_detail']['forwarder_name'].'/'.$file
                       ));
					if($this->_getData['labeltype']=='PDF'){
						//$return['Success']['Label'] = base64_encode(file_get_contents($this->_ApiSaveLink[$this->RecordData[FORWARDER_ID]].$file));
				   }
				 break;
				 default:
				   
				   $labelObj->AutoPrint(true);
			   	   $labelObj->_filePath = PRINT_OPEN_LABEL.$this->RecordData['forwarder_detail']['forwarder_name'].'/'.$file;
			       $labelObj->Output(PRINT_SAVE_LABEL.$this->RecordData['forwarder_detail']['forwarder_name'].'/'.$file,'F'); 
			       $objSession->AddSipmentLabel = $labelObj->_filePath;
			  }
		 }
		  
	}
	
	public function EditPrintLabel($oldRecord,$quantity_diff){ 
	     $Shipmentrecord = $this->getshipmentBarcodeDetail();
		 global $labelObj,$objSession;
		 $labelObj->SetlabelFormat();
		   $file = 'PDF_'.time().'_'.$this->RecordData[SHIPMENT_ID].'.pdf';
		   $q = 1;
		   $this->_insertbrcode = false;
		   foreach($Shipmentrecord as $shipmentRecord){
		        $labelObj->ParcelCount =  $labelObj->ParcelCount + 1;
		        $this->RecordData  = $shipmentRecord;
				$this->RecordData['forwarder_detail'] = $this->ForwarderDetail();
				$this->RecordData['parcelcount'] = $q;
				$this->RecordData['ShipmentCount'] = $q.'/'.$this->RecordData[QUANTITY];
				if($oldRecord[FORWARDER_ID]==$this->RecordData[FORWARDER_ID]){
				    /*$this->RecordData[TRACENR] 	= $Shipmentrecord[$q][TRACENR];
					$this->RecordData[BARCODE] = $Shipmentrecord[$q][BARCODE];
					$this->RecordData[TRACENR_BARCODE] = $Shipmentrecord[$q][TRACENR_BARCODE];
					$this->RecordData[BARCODE_ID] = $Shipmentrecord[$q][BARCODE_ID];
					$this->RecordData[REROUTE_BARCODE] = $Shipmentrecord[$q][REROUTE_BARCODE];*/
					$this->GenerateBarcodeData(false);
					$this->updateBarcodeAfterEdit();
				}else{
				    unset($this->RecordData['tracenr']);
				    /*$labelObj->ParcelCount =  $labelObj->ParcelCount + 1;
					unset($this->RecordData['tracenr_barcode']);
					unset($this->RecordData['barcode']);
					unset($this->RecordData['reroute_barcode']);*/
					$this->GenerateBarcodeData(true);
				}
				$labelObj->outputparam = $this->RecordData;
				$labelObj->labelAllForwarder();
				$q++;
		   }
		   for($i=1;$i<=$quantity_diff;$i++){
		       $this->_insertbrcode = true;
		       $this->RecordData['forwarder_detail'] = $this->ForwarderDetail();
			   $this->GenerateBarcodeData(true);
			   $labelObj->outputparam = $this->RecordData;
			   $labelObj->labelAllForwarder();
		   }
		  if(isset($this->getData['API_EDI'])){
		      $labelObj->Output(PRINT_SAVE_LABEL.$this->RecordData['forwarder_detail']['forwarder_name'].'/'.$file,'F');
			   $return = array('Success'=>array('SuccessMessage' => 'MESSAGE: Shipment has created successfully.....',
					'Forwarder'=>'    FORWARDER: '.$this->RecordData['forwarder_detail']['forwarder_name'],
					'TrackingDetails'=>$trakingApi,
					'LabelURL'=>'    LABEL URL: '.PRINT_OPEN_LABEL.$this->RecordData['forwarder_detail']['forwarder_name'].'/'.$file
				 ));	
		  }else{
		      $labelObj->AutoPrint(true);
			  $labelObj->_filePath = PRINT_OPEN_LABEL.$this->RecordData['forwarder_detail']['forwarder_name'].'/'.$file;
			  $labelObj->Output(PRINT_SAVE_LABEL.$this->RecordData['forwarder_detail']['forwarder_name'].'/'.$file,'F'); 
			  $objSession->AddSipmentLabel = $labelObj->_filePath;
		  }
		 /*if($oldRecord[FORWARDER_ID]==$this->RecordData[FORWARDER_ID]){
		    for($q=0;$q<$this->RecordData[QUANTITY];$q++){
				if($quantity_diff > 0 && $q >= $oldRecord[QUANTITY]){ 
					$labelObj->ParcelCount =  $labelObj->ParcelCount + 1;
					$this->RecordData['parcelcount'] = $q;
					$this->RecordData['ShipmentCount'] = $q.'/'.$this->RecordData[QUANTITY];
					unset($this->RecordData['tracenr']);
					unset($this->RecordData['tracenr_barcode']);
					unset($this->RecordData['barcode']);
					unset($this->RecordData['reroute_barcode']);
					$this->GenerateBarcodeData(true);
				}else{
					$this->RecordData[TRACENR] 	= $Shipmentrecord[$q][TRACENR];
					//$this->RecordData[REFERENCE] = $this->MultiReference($this->RecordData[REFERENCE],($i+1));
					$this->RecordData[BARCODE] = $Shipmentrecord[$q][BARCODE];
					$this->RecordData[TRACENR_BARCODE] = $Shipmentrecord[$q][TRACENR_BARCODE];
					//$this->RecordData[LABEL_DATE] = $Shipmentrecord[$i][LABEL_DATE];
					$this->RecordData[BARCODE_ID] = $Shipmentrecord[$q][BARCODE_ID];
					$this->RecordData[REROUTE_BARCODE] = $Shipmentrecord[$q][REROUTE_BARCODE];
					$this->GenerateBarcodeData(false);
					$this->UpdateBarcodeAfterEdit($Shipmentrecord[$q]);
				}
			  $labelObj->outputparam = $this->RecordData;
			  $labelObj->labelAllForwarder();
			}
		 }else{
		 
		 }*/
	}
	
	public function GenerateBarcodeData($new_tracking=true){ 
	     if($new_tracking && $this->RecordData['forwarder_detail']['tracenr_status']=='1'){
		    $this->RecordData['tracenr'] = $this->getUniqueTracking();
		 }
	     switch($this->RecordData['forwarder_id']){
			      case 1:
				  case 2:
				  case 3:
				  case 26:
				  case 32:
				  case 38:
				  case 54:
				     $this->CreateDPDLabel($this,$new_tracking);
				  break;
				  case 4:
				  	 $this->RecordData['SOCKET'] = $new_tracking;
				  	 $this->CreateGLSDELabel($this,$new_tracking);
				  break;
				  case 5:
				  	  $this->RecordData['SOCKET'] = $new_tracking;
				  	  $this->CreateGLSFreightLabel($this,$new_tracking);
				  break;
				  case 6:
				     $this->RecordData['SOCKET'] = $new_tracking;
				  	 $this->CreateGLSNLLabel($this,$new_tracking);
				  break;
				  case 7:
				     $this->CreateBpostLabel($this,$new_tracking);
				  break;
				  case 9:
				     $this->CreateExpressLabel($this,$new_tracking);
				  break;
				  case 11:
				     $this->CreatePostatLabel($this,$new_tracking);
				  break;
				  case 14:
				     $this->CreatePostnlLabel($this,$new_tracking);
				  break;
				  case 15:
				     $this->CreateCODLabel($this,$new_tracking);
				  break;
				  case 17:
				  case 18:
				  case 19:
				     $this->CreateUPSLabel($this,$new_tracking);
				  break;
				   case 20:
				     $this->CreateColissimoLabel($this,$new_tracking);
				  break;
				  case 22:
				    $this->CreateParcelnlLabel($this,$new_tracking);
				  break;
				  case 23:
				    $this->CreateLDELabel($this,$new_tracking);
				  break;
				  case 24:
				    $this->CreateDHLLabel($this,$new_tracking);
				  break;
				  case 25:
				    $this->CreateDHLGlobalLabel($this,$new_tracking);
				  break;
				  case 27:
				    $this->CreateMondialRelayLabel($this,$new_tracking);
				  break;
				  case 28:
				    $this->CreateAnpostLabel($this,$new_tracking);
				  break;
				  case 29:
				  case 40:
				  case 52:
				    $this->RecordData['API'] = $new_tracking;
					$this->CreateYodelLabel($this,$new_tracking);
				  break;
				 case 30:
				   $this->CreateCorreosLabel($this,$new_tracking);
				 break;
				 case 33:
				   $this->CreateWwplLabel($this,$new_tracking);
				 break;
				  case 34:
					$this->CreateGLSITLabel($this,$new_tracking);
				  break;
				 case 36:
				   $this->CreateRDPAGLabel($this,$new_tracking);
				 break;
				 case 37:
				   $this->CreateBRTLabel($this,$new_tracking);
				 break;
				 case 41:
				 	$this->RecordData['API'] = $new_tracking;
				    $this->CreateFadelloLabel($this,$new_tracking);
				 break;
				 case 42:
				     $this->CreateDeburenLabel($this,$new_tracking);
				 break;
				 case 43:
				     $this->CreateOmnivaLabel($this,$new_tracking);
				 break;
				 case 44:
				     $this->CreateAramexLabel($this,$new_tracking);
				 break;
				 case 45:
				    $this->CreateESCorreosLabel($this,$new_tracking);
				  break;
				  case 46:
				    $this->CreateRussianPostLabel($this,$new_tracking);
				  break;
				  case 48:
				    $this->CreateSystematicLabel($this,$new_tracking);
				  break;
				  case 49:
				    $this->CreateRswisspostLabel($this,$new_tracking);
				  break; 
				  case 50:
				    $this->CreateHamacherLabel($this,$new_tracking);
				  break;
				  case 51:
				    $this->CreateUrgentSwisspostLabel($this,$new_tracking);
				  break; 
				  case 53:
				    $this->CreateDCPostalLabel($this,$new_tracking);
				  break;
			  
		}
		if($new_tracking){
			$this->insertUpdateBarcode(); 
		}
		return true;
	}
	
	public function PrintAllLabel($new_tracking=false){ 
	     $shipmentdetails = $this->getShipmentDetailsForPrint();
		 global $labelObj,$objSession;
		 $labelObj->SetlabelFormat();
		 $file = 'PDF_'.time().'_'.date('Y_m_d').'.pdf';
		 $shipment_id = 0;
		 $countparcel = 1;
		 foreach($shipmentdetails as $shipments){
			 unset($this->RecordData);
			 $this->RecordData = $shipments;
			 $this->RecordData['forwarder_detail'] = $this->ForwarderDetail();
			  $labelObj->ParcelCount =  $labelObj->ParcelCount + 1;
			  if($this->RecordData[SHIPMENT_ID]!=$shipment_id){
				  $shipment_id = $this->RecordData[SHIPMENT_ID];
				  $countparcel=1;
			  }
			  $this->RecordData['parcelcount'] = $countparcel;
			  $this->RecordData['ShipmentCount'] = $countparcel.'/'.$this->RecordData[QUANTITY];
				$this->GenerateBarcodeData(false);
				$labelObj->outputparam = $this->RecordData;
				$labelObj->labelAllForwarder();
			  $countparcel++;
		       
		}
		ob_end_clean();
		$labelObj->Output($file,'D');
		$labelObj->PopUpLabel();
		return true;
	}
    public function getShipmentDetails(){
	    $where = $this->LevelClause();
	    if(!empty($this->bulkshipment) && $this->bulkshipment>0){
		    $select = $this->_db->select()
									->from(array('ST'=>SHIPMENT),array('*'))
									->joinleft(array('BT' =>SHIPMENT_BARCODE),"ST.shipment_id=BT.shipment_id",array())
									->joininner(array('AT' =>USERS_DETAILS),"AT.user_id=ST.user_id",array())
									->where('ISNULL(BT.barcode)'.$where);
			  //$select->where('ISNULL(Barcode.'.SHIPMENT_BARCODE.')');						
			  $select->order("ST.shipment_id DESC");
			  $select->limit($this->bulkshipment,0);
		}else{
		   $select = $this->_db->select()
								->from(array('ST'=>SHIPMENT),array('*'))
								->joininner(array('AT' =>USERS_DETAILS),"AT.user_id=ST.user_id",array('parent_id'))
								->where("shipment_id IN ('".implode("','",$this->shipment_id)."')".$where);
		 }				  
						  
			// print_r($select->__toString());die;
		return $this->getAdapter()->fetchAll($select);
	}
	public function getShipmentDetailsForPrint(){
	     $where = $this->LevelClause();
		 $select = $this->_db->select()
									->from(array('BT'=>SHIPMENT_BARCODE),array('*'))
									->joininner(array('BD' =>SHIPMENT_BARCODE_DETAIL),"BD.barcode_id=BT.barcode_id",array('*'))
									->joininner(array('ST' =>SHIPMENT),"ST.shipment_id=BT.shipment_id",array('user_id','forwarder_id','original_forwarder','country_id','addservice_id','service_attribute','senderaddress_id','quantity','rec_name','rec_contact','rec_street','rec_streetnr','rec_address','rec_street2','rec_zipcode','rec_city','rec_phone','rec_email','rec_state','length','width','height','goods_id','goods_description','shipment_worth','cod_price','currency','create_date'))
									->joinleft(array('RB' =>SHIPMENT_BARCODE_REROUTE),"RB.barcode_id=BT.barcode_id",array('*'))
									->joininner(array('AT' =>USERS_DETAILS),"AT.user_id=ST.user_id",array());
		$select->where("ST.shipment_id IN ('".implode("','",$this->getData['shipment_id'])."')".$where);
		$select->order("ST.shipment_id ASC");//print_r($select->__toString());die;
		   return $this->getAdapter()->fetchAll($select);
									
	}
	public function getshipmentBarcodeDetail(){
		     $select = $this->_db->select()
										->from(array('BT'=>SHIPMENT_BARCODE),array('*'))
										->joininner(array('BD' =>SHIPMENT_BARCODE_DETAIL),"BD.barcode_id=BT.barcode_id",array('*'))
										->joininner(array('ST' =>SHIPMENT),"ST.shipment_id=BT.shipment_id",array('*'))
										->where("ST.shipment_id IN ('".implode("','",$this->shipment_id)."')");
		   return $this->getAdapter()->fetchAll($select);
	}
	public function getDPDRouteInfo(){
	    $select = $this->_db->select()
						->from(DPDROUTEINFO,array('BarcodeID','DPDService','Indentification','OSort','DSort','Version','ServiceCode','DestinationDepot','Country'))
						->where("shipment_id='".$this->RecordData[SHIPMENT_ID]."'");
	   	$result  = $this->getAdapter()->fetchRow($select);
		if(empty($result)){
		    return $this->CalculateDPDRoutes();
		}
		foreach($result as $key=>$routesvalue){ 
		    $this->RecordData[$key] = $routesvalue;
		}
	}
	public function CalculateDPDRoutes($update=false){
	    try{
		 $RouteObj = new Zend_Dpdroute_Routeclass();
		 $RouteObj->inputdata['depot_number']    = $this->RecordData['forwarder_detail']['depot_number'];
		 $RouteObj->inputdata[ZIPCODE] 			 = $this->RecordData[ZIPCODE];
		 $RouteObj->inputdata[STREET] 			 = $this->RecordData[STREET];
		 $RouteObj->inputdata[CITY] 			 = $this->RecordData[CITY];
		 $RouteObj->inputdata['ServiceCode']     = ($this->RecordData[WEIGHT]<=3)?$this->RecordData['forwarder_detail']['service_code_kp']:$this->RecordData['forwarder_detail']['service_code_np'];
		 $RouteObj->inputdata['CountryCode'] 	 = $this->RecordData['rec_cncode'];
		 $RouteObj->inputdata[FORWARDER_ID] 	 = $this->RecordData[FORWARDER_ID];
		}catch(Exception $e){
		   echo $e->getMessage();die;
		}
		$routesinfo = $RouteObj->RouteInformation();
		if(!is_array($routesinfo)){
		   return $routesinfo;
		}
		foreach($routesinfo as $key=>$routesvalue){ 
		    $this->RecordData[$key] = $routesvalue;
		}
		
		if($update){
			$this->_db->update(DPDROUTEINFO,array('DPDService'=>$this->RecordData['DPDService'],'Indentification'=>$this->RecordData['Indentification'],'ServiceInfo'=>$this->RecordData['ServiceInfo'],'OSort'=>$this->RecordData['OSort'],'DSort'=>$this->RecordData['DSort'],'GroupingPriority'=>$this->RecordData['GroupingPriority'],'BarcodeID'=>$this->RecordData['BarcodeID'],'DestinationDepot'=>$this->RecordData['DestinationDepot'],'Version'=>$this->RecordData['Version'],'ServiceCode'=>$this->RecordData['ServiceCode'],'Country'=>$this->RecordData['Country']),"shipment_id='".$this->RecordData[SHIPMENT_ID]."'");
		}else{
		  $this->_db->insert(DPDROUTEINFO,array_filter(array('shipment_id'=>$this->RecordData[SHIPMENT_ID],'forwarder_id'=>$this->RecordData[FORWARDER_ID],'DPDService'=>$this->RecordData['DPDService'],'Indentification'=>$this->RecordData['Indentification'],'ServiceInfo'=>$this->RecordData['ServiceInfo'],'OSort'=>$this->RecordData['OSort'],'DSort'=>$this->RecordData['DSort'],'GroupingPriority'=>$this->RecordData['GroupingPriority'],'BarcodeID'=>$this->RecordData['BarcodeID'],'DestinationDepot'=>$this->RecordData['DestinationDepot'],'Version'=>$this->RecordData['Version'],'ServiceCode'=>$this->RecordData['ServiceCode'],'Country'=>$this->RecordData['Country'])));
		}
		
	}
	
	public function insertUpdateBarcode(){
	     try{
		 if($this->_insertbrcode){ 
				 $this->_db->insert(SHIPMENT_BARCODE,
								 array_filter(array(SHIPMENT_ID   	     => $this->RecordData[SHIPMENT_ID],
													TRACENR    			 => $this->RecordData[TRACENR],
													TRACENR_BARCODE      => $this->RecordData[TRACENR_BARCODE],
													BARCODE    			 => $this->RecordData[BARCODE],
													LOCAL_BARCODE    	 => isset($this->RecordData[LOCAL_BARCODE])?$this->RecordData[LOCAL_BARCODE]:'',
													REFERENCE_BARCODE    => isset($this->RecordData[REFERENCE_BARCODE])?$this->RecordData[REFERENCE_BARCODE]:$this->getShipmentSeriesno($this->RecordData[TRACENR]),
													FORWARDER_ID	     => $this->RecordData[FORWARDER_ID],
													WEIGHT     			 => $this->RecordData[WEIGHT],
													SERVICE_ID           => $this->RecordData[SERVICE_ID],
													DEPOT_PRICE	     	 => $this->RecordData[DEPOT_PRICE],
													CUSTOMER_PRICE	     => $this->RecordData[CUSTOMER_PRICE])));
				$this->RecordData[BARCODE_ID] = $this->getAdapter()->lastInsertId();
				$this->_db->insert(SHIPMENT_BARCODE_REROUTE,array_filter(array(BARCODE_ID		=>	$this->RecordData[BARCODE_ID],
																			   REROUTE_BARCODE  =>	isset($this->RecordData[REROUTE_BARCODE])?commonfunction::addslashesing($this->RecordData[REROUTE_BARCODE]):'')));
				$this->_db->insert(SHIPMENT_BARCODE_DETAIL,array_filter(array(BARCODE_ID		=>	$this->RecordData[BARCODE_ID],
																			  LABEL_DATE 		=>	(isset($this->RecordData[LABEL_DATE]) && $this->RecordData[LABEL_DATE]!='0000-00-00 00:00:00')?new Zend_Db_Expr('NOW()'):'0000-00-00 00:00:00',
																			  REFERENCE		     => $this->RecordData[REFERENCE])));
		}else{
			$this->_db->update(SHIPMENT_BARCODE,array(TRACENR    		 => $this->RecordData[TRACENR],
													TRACENR_BARCODE      => $this->RecordData[TRACENR_BARCODE],
													BARCODE    			 => $this->RecordData[BARCODE],
													LOCAL_BARCODE    	 => $this->RecordData[LOCAL_BARCODE],
													FORWARDER_ID	     => $this->RecordData[FORWARDER_ID],
													WEIGHT     			 => $this->RecordData[WEIGHT],
													SERVICE_ID           => $this->RecordData[SERVICE_ID],
													DEPOT_PRICE	     	 => $this->RecordData[DEPOT_PRICE],
													CUSTOMER_PRICE	     => $this->RecordData[CUSTOMER_PRICE]),"barcode_id='".$this->RecordData[BARCODE_ID]."'");
				//$this->RecordData[BARCODE_ID] = $this->getAdapter()->lastInsertId();
				$this->_db->update(SHIPMENT_BARCODE_REROUTE,array(REROUTE_BARCODE  =>	commonfunction::addslashesing($this->RecordData[REROUTE_BARCODE])),"barcode_id='".$this->RecordData[BARCODE_ID]."'");
				$this->_db->update(SHIPMENT_BARCODE_DETAIL,array(REFERENCE	 => $this->RecordData[REFERENCE]),"barcode_id='".$this->RecordData[BARCODE_ID]."'");
		}
	  }catch(Exception $e){
	     echo $e->getMessage();die;
	     //return $this->GenerateBarcodeData(true);
	  }																																			
	}
	public function updateBarcodeAfterEdit(){
	    try{
			$this->_db->update(SHIPMENT_BARCODE,array(TRACENR    		 => $this->RecordData[TRACENR],
													TRACENR_BARCODE      => $this->RecordData[TRACENR_BARCODE],
													BARCODE    			 => $this->RecordData[BARCODE],
													LOCAL_BARCODE    	 => $this->RecordData[LOCAL_BARCODE],
													FORWARDER_ID	     => $this->RecordData[FORWARDER_ID],
													WEIGHT     			 => $this->RecordData[WEIGHT],
													SERVICE_ID           => $this->RecordData[SERVICE_ID],
													DEPOT_PRICE	     	 => $this->RecordData[DEPOT_PRICE],
													CUSTOMER_PRICE	     => $this->RecordData[CUSTOMER_PRICE]),"barcode_id='".$this->RecordData[BARCODE_ID]."'");
				$this->_db->update(SHIPMENT_BARCODE_REROUTE,array(REROUTE_BARCODE  =>	commonfunction::addslashesing($this->RecordData[REROUTE_BARCODE])),"barcode_id='".$this->RecordData[BARCODE_ID]."'");
				$this->_db->update(SHIPMENT_BARCODE_DETAIL,array(REFERENCE	 => $this->RecordData[REFERENCE]),"barcode_id='".$this->RecordData[BARCODE_ID]."'");
	  }catch(Exception $e){
	     echo $e->getMessage();die;
	  }	
	}
	/**
	*Reference Generated by system
	*Function : SystemGeneratedReference()
	*Generate Rendom Reference of Parcel
	**/
	public function SystemGeneratedReference(){
		  if($this->RecordData[REFERENCE]==''){
			$record = $this->getCustomerDetails($this->RecordData['user_id']);
			$FName      = commonfunction::sub_string(commonfunction::uppercase($record['name']),0,3);
			$Rec_Name  = commonfunction::sub_string(commonfunction::uppercase($this->RecordData[RECEIVER]),0,3);
			$ParcelNo  = commonfunction::paddingleft($this->RecordData[SHIPMENT_ID],4,'0',STR_PAD_LEFT);
			 return commonfunction::stringReplace(' ','',$FName.$ParcelNo.$Rec_Name);
		 }else{
			 return $this->RecordData[REFERENCE];
		 }	
	}
	public function multireference($reference,$count){
	  return ($count==1)?$reference:$reference.'-'.($count-1);
	}
	
	public function AutocheckinReturn(){
      if(($this->RecordData['addservice_id']==124 || $this->RecordData['addservice_id']==148) && $this->RecordData[FORWARDER_ID]==14){
		  $select = $this->_db->select()
								   ->from(SHIPMENT_BARCODE,array('barcode_id'))
								   ->where("shipment_id='".$this->RecordData[SHIPMENT_ID]."' AND checkin_status='0'");
			$shipments = $this->getAdapter()->fetchAll($select);
		    foreach($shipments as $shipment){ 
			   $this->CheckIN($shipment['barcode_id'],9);
		   }
	  }
   }

    public function addExtandable($object)
    {
        $this->_exts[]=$object;
    }

    public function __get($varname)
    {
        foreach($this->_exts as $ext)
        {
            if(property_exists($ext,$varname))
            return $ext->$varname;
        }
    }

    public function __call($method,$args)
    {
        foreach($this->_exts as $ext)
        {
            if(method_exists($ext,$method))
            return call_user_func_array(array($ext,$method),$args);
        }
    }
	
	


}