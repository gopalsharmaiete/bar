<?php

class Application_Model_Parceltracking extends Zend_Custom
{
    public function parcelinformation(){
	   $select = $this->_db->select()
									->from(array('BT' =>SHIPMENT_BARCODE),array('*'))
									->joininner(array('BD'=>SHIPMENT_BARCODE_DETAIL),"BD.barcode_id=BT.barcode_id",array('rec_reference','checkin_date'))
									->joininner(array('BL'=>SHIPMENT),"BL.shipment_id=BT.shipment_id",array('country_id','user_id','rec_name','addservice_id','create_date','senderaddress_id','goods_id','create_by','rec_zipcode'))
									->joininner(array('AT' =>USERS_DETAILS),"AT.user_id=BL.user_id",array("AT.company_name"))
									->joininner(array('CT' =>COUNTRIES),"CT.country_id=BL.country_id",array("CT.country_name"))
									->joininner(array('FT' =>FORWARDERS),"FT.forwarder_id=BT.forwarder_id",array("FT.forwarder_name"))
									->joininner(array('ST' =>SERVICES),"ST.service_id=BT.service_id",array("ST.service_name"))
									->where("BT.barcode_id='".$this->getData['barcode_id']."'"); //print_r($select->__toString());die;
		$this->RecordData =   $this->getAdapter()->fetchRow($select);
		$this->RecordData['forwarder_detail'] = $this->ForwarderDetail();
		$this->getData = $this->RecordData;
		$this->getOurTracking();
		return $this->getData;
		//echo "<pre>";print_r($this->RecordData);die;
	}
	
	public function getOurTracking(){ //echo "<pre>";print_r($this->getData);die;
	   $tracking_data = array();
	   $userdetails = $this->getCustomerDetails($this->getData['create_by']);
	   //Added
	   $tracking_data[] = array('location'=>$userdetails['city'].'('.$userdetails['cncode'].')','status'=>'Parcel Added','updatedon'=>$this->getData['create_date']);
	   //Label Generated 
	   $tracking_data[] = array('location'=>$userdetails['city'].'('.$userdetails['cncode'].')','status'=>'Parcel Added','updatedon'=>$this->getData['create_date']);
	   //assigned To driver
	   $tracking_data[] = array('location'=>$userdetails['city'].'('.$userdetails['cncode'].')','status'=>'Parcel Added','updatedon'=>$this->getData['create_date']);
	   //Pickup by Driver
	    $tracking_data[] = array('location'=>$userdetails['city'].'('.$userdetails['cncode'].')','status'=>'Parcel Added','updatedon'=>$this->getData['create_date']);
	   //Checkin
	    $tracking_data[] = array('location'=>$userdetails['city'].'('.$userdetails['cncode'].')','status'=>'Parcel Added','updatedon'=>$this->getData['create_date']);
	   //Hub check-in
	   //Electronic data Exchange
	   //
	   //echo "<pre>";print_r($tracking_data);die;
	   $this->getData['Tracking'] =  $tracking_data;
	}
	
	

}

