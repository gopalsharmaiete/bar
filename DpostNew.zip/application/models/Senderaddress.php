<?php

class Application_Model_Senderaddress extends Zend_Custom
{
    public function getSenderaddress($data){ 
	      $select = $this->_db->select()
									->from(array('SA' =>USER_SENDER_ADDRESS),array('*'))
									->joininner(array('AC' =>SENDER_ADDRESS_COUNTRIES),"SA.address_id=AC.address_id",array(''))
									->where("SA.user_id=?",$data['user_id'])
									->where("SA.country_id=?",$data['country_id']);//echo $select->__toString();die;
		 $senderaddresses =  $this->getAdapter()->fetchAll($select);
		 $option .= '<option value="C">Default Address</option>';
		 $option .= '<option value="B">No Address</option>';
		 foreach($senderaddresses as $senderaddress){
		   $address = array_filter(array($senderaddress['name'],$senderaddress['street'].' '.$senderaddress['streetnumber'],$senderaddress['streetaddress'],$senderaddress['postalcode'].' '.$senderaddress['city']));
		   $option .= '<option value="'.$senderaddress['address_id'].'">'.commonfunction::implod_array($address,', ').'</option>';  
		 }
		 return $option;
	}
	
	public function createSenderAddress($data){
	  		$contry_detail  = $this->getCountryDetail(trim($data['scountrycode']), 2);
			$this->_db->insert(USER_SENDER_ADDRESS,array_filter(array('user_id'=>$data['user_id'],'name'=>$data['sname'],'street'=>$data['saddress1'],'streetaddress'=>$data['saddress2'],'postalcode'=>$data['szipcode'],'city'=>$data['scity'],'country_id'=>$contry_detail[COUNTRY_ID])));
			return  $this->getAdapter()->lastInsertId();
	}
	public function getAddressID($data){
	   if($data['SenderCode']=='B'){
	      return 'B';
	   }elseif($data['SenderCode']=='C' || $data['SenderCode']==''){
	      return 'C';
	   }else{
	       $select = $this->_db->select()
									->from(array('SA' =>USER_SENDER_ADDRESS),array('address_id'))
									->where("SA.user_id=?",$data['user_id'])
									->where("SA.apicode=?",$data['SenderCode']);//echo $select->__toString();die;
		  $senderaddresses =  $this->getAdapter()->fetchRow($select);
		  return  $senderaddresses['address_id'];
	   }
	}

}

