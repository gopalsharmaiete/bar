<?php
class Application_Model_GLSNLLabel extends Zend_custom{
      public $GLSNLdata = array();
	  public function CreateGLSNLLabel($shipmentObj,$newbarcode=true){
	  
	  }
}