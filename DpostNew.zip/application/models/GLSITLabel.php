<?php
class Application_Model_GLSITLabel extends Zend_custom{
	  public function CreateGLSITLabel($shipmentObj,$newbarcode=true){ 
	  	 $shipmentObj->RecordData[BARCODE] = $shipmentObj->RecordData['forwarder_detail']['customer_number'].$shipmentObj->RecordData[TRACENR];	
		 $shipmentObj->RecordData[TRACENR_BARCODE] = $shipmentObj->RecordData[BARCODE];
	  }
}