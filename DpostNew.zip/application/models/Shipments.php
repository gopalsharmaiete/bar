<?php 
class Application_Model_Shipments extends Application_Model_Shipmentlabel
{
    
    public function __construct()
    {   parent::__construct();
        parent::addExtandable(new Application_Model_DPDLabel());
		parent::addExtandable(new Application_Model_GLSDELabel());
		parent::addExtandable(new Application_Model_GLSFreightLabel());
		parent::addExtandable(new Application_Model_GLSNLLabel());
		parent::addExtandable(new Application_Model_BpostLabel());
		parent::addExtandable(new Application_Model_ExpressLabel());
		parent::addExtandable(new Application_Model_PostatLabel());
		parent::addExtandable(new Application_Model_PostnlLabel());
		parent::addExtandable(new Application_Model_CODLabel());
		parent::addExtandable(new Application_Model_UPSLabel());
		parent::addExtandable(new Application_Model_ColissimoLabel());
		parent::addExtandable(new Application_Model_ParcelnlLabel());
		parent::addExtandable(new Application_Model_LDELabel());
		parent::addExtandable(new Application_Model_DHLLabel());
		parent::addExtandable(new Application_Model_MondialRelayLabel());
		parent::addExtandable(new Application_Model_AnpostLabel());
		parent::addExtandable(new Application_Model_YodelLabel());
		parent::addExtandable(new Application_Model_CorreosLabel());
		parent::addExtandable(new Application_Model_RDPAGLabel());
		parent::addExtandable(new Application_Model_WwplLabel());
		parent::addExtandable(new Application_Model_GLSITLabel());
		parent::addExtandable(new Application_Model_BRTLabel());
		parent::addExtandable(new Application_Model_FadelloLabel());
		parent::addExtandable(new Application_Model_DeburenLabel());
		parent::addExtandable(new Application_Model_OmnivaLabel());
		parent::addExtandable(new Application_Model_AramexLabel());
		parent::addExtandable(new Application_Model_RussianPostLabel());
		parent::addExtandable(new Application_Model_SystematicLabel());
		parent::addExtandable(new Application_Model_RswisspostLabel());
		parent::addExtandable(new Application_Model_HamacherLabel());
		parent::addExtandable(new Application_Model_UrgentSwisspostLabel());
		parent::addExtandable(new Application_Model_DCPostalLabel());
    }

	public function addShipment(){
	   global $objSession,$labelObj;
	   $this->DataValidation();
	   $errorData = $this->ErrorCheck();
	   if($errorData){
	       if(($this->getData['shipment_type']==4 || $this->getData['shipment_type']==10)){
		      return $errorData;  
		   }elseif($this->getData['shipment_type']==2){
		         $this->getData['data_error'] =  $errorData; 
				 return false; 
		   }else{
		       $objSession->errorMsg = "Shipment Not Added Due to following error:-<br>".$errorData;
			   return false;
		   }
	   }
	   $shipment_id = $this->insertInToTable(SHIPMENT,array($this->getData));//echo "<pre>";print_r($this->getData);die;
	   if(isset($this->getData['addservice_id']) && ($this->getData['addservice_id']==126 || $this->getData['addservice_id']==149) && $this->getData['parcel_shop']!=''){
	      $this->_db->insert(SHIPMENT_PARCELPOINT,array_filter(array('shipment_id'=>$shipment_id,'parcel_shop'=>$this->getData['parcel_shop'])));
	   }
	   $this->shipment_id = array($shipment_id);
	   if($this->getData['shipment_type']==2){
	     return $this->shipment_id;
	   }
		if($this->getData[FORWARDER_ID]<=3) {  
			$labelObj = new Zend_Labelclass_PDFLabel('P','mm','label');
		}	
	   $objSession->successMsg = "Shipment Added successfully!!";
	   return $this->CreateLabel();
	}
	
	public function editShipment($oldRecord){
	   global $objSession,$labelObj;
	   $this->getData['shipment_id'] =  Zend_Encript_Encription::decode($this->getData['shipment_id']);
	   $updateData = $this->getData;
	   unset($updateData['shipment_id']);
	   $updateData['modify_date'] = commonfunction::DateNow();
	   $shipment_id = $this->UpdateInToTable(SHIPMENT,array($updateData),"shipment_id='".$this->getData['shipment_id']."'");
	   $this->shipmentEditLog($oldRecord);
	   $this->shipment_id = array($this->getData['shipment_id']);
	   $quantity_diff = $this->getData[QUANTITY] - $oldRecord[QUANTITY];
	   if($quantity_diff<0){
	       $this->deleteExtraShipment($quantity_diff);  
	   }
		if($this->getData[FORWARDER_ID]<=3 || $this->getData[FORWARDER_ID]=23 || $this->getData[FORWARDER_ID]==32) {
			$labelObj = new Zend_Labelclass_PDFLabel('P','mm','label');
		}	
	   $objSession->successMsg = "Shipment Edited successfully!!";
	   $this->RecordData = $this->getData;
	   return $this->EditPrintLabel($oldRecord,$quantity_diff);
	}
	public function DataValidation(){
	    $this->getData[ZIPCODE] = $this->ValidateZipcode($this->getData[ZIPCODE],$this->getData[COUNTRY_ID]);
		$this->getData[WEIGHT]  = commonfunction::stringReplace(',','.',$this->getData[WEIGHT]);
		$this->getData['cod_price']  = isset($this->getData['cod_price'])?commonfunction::stringReplace(',','.',$this->getData['cod_price']):0;
		$this->getData['shipment_worth']  =  isset($this->getData['shipment_worth'])?commonfunction::stringReplace(',','.',$this->getData['shipment_worth']):0;
		$this->getData['create_date'] = commonfunction::DateNow();
	    $this->getData['create_by'] = $this->Useconfig['user_id'];
	    $this->getData['create_ip'] = (isset($this->getData['create_ip']))?trim($this->getData['create_ip']):commonfunction::loggedinIP();
		$this->getData['quantity'] = (!isset($this->getData['quantity']) || $this->getData['quantity']<=0 || $this->getData['quantity']>10)?1:$this->getData['quantity'];
		$this->getData['email_notification'] = (!empty($this->getData['rec_email'])) ? 1 : 0;
	}
	
	public function getNewShipment(){ 
		$this->getData['user_id'] = isset($this->getData['user_id'])?Zend_Encript_Encription::decode($this->getData['user_id']):'';
		$where = $this->LevelClause();
		if($this->getData['user_id']>0){
		    $where .=  " AND AT.user_id='".$this->getData['user_id']."'";
		}
		$OrderLimit = commonfunction::OdrderByAndLimit($this->getData,'AT.company_name','ASC');
		
		$select = $this->_db->select()
									->from(array('BT' =>SHIPMENT_BARCODE),array("AT.user_id"))
									->joininner(array('ST'=>SHIPMENT),"ST.shipment_id=BT.shipment_id",array(""))
									->joininner(array('AT' =>USERS_DETAILS),"AT.user_id=ST.user_id",array(""))
									->where("BT.checkin_status='0' AND BT.delete_status='0' AND ST.delete_status='0'".$where)
									->group("AT.user_id");
									//print_r($select->__toString());die;
		$count = $this->getAdapter()->fetchAll($select);							
		$select = $this->_db->select()
									->from(array('BT' =>SHIPMENT_BARCODE),array('SUM(BT.weight) AS Total_weight',"COUNT(barcode_id) AS total_quantity"))
									->joininner(array('ST'=>SHIPMENT),"ST.shipment_id=BT.shipment_id",array("COUNT(ST.shipment_id) AS Total_parcel"))
									->joininner(array('AT' =>USERS_DETAILS),"AT.user_id=ST.user_id",array("AT.company_name","AT.user_id"))
									->where("BT.checkin_status='0' AND BT.delete_status='0' AND ST.delete_status='0'".$where)
									->group("AT.user_id")
									->order($OrderLimit['OrderBy'].' '.$OrderLimit['OrderType'])
									->limit($OrderLimit['Toshow'],$OrderLimit['Offset']);//print_r($select->__toString());die;
		$records =  $this->getAdapter()->fetchAll($select);
		return array('Total'=>count($count),'Records'=>$records);
	}
	
	public function getShowAllShipments(){
	   try{
	    $this->getData['user_id'] = isset($this->getData['user_id'])?Zend_Encript_Encription::decode($this->getData['user_id']):'';
		$this->getData['parent_id'] = isset($this->getData['parent_id'])?Zend_Encript_Encription::decode($this->getData['parent_id']):'';
		$where = $this->LevelClause();
		$where .= commonfunction::filters($this->getData);
		if(isset($this->getData['shipment_type']) && $this->getData['shipment_type']>0){
		    $where .=  " AND ST.shipment_type='".$this->getData['shipment_type']."'";
		}
		if(isset($this->getData['from_date']) && isset($this->getData['to_date']) &&  $this->getData['from_date']!='' && $this->getData['to_date']!=''){
		    $where .=  " AND DATE(ST.create_date) BETWEEN '".$this->getData['from_date']."' AND '".$this->getData['to_date']."'";
		}
		if(isset($this->getData['print_status']) && $this->getData['print_status']>0){
		    $where .=  ($this->getData['print_status']==1)?" AND BD.label_date!='0000-00-00 00:00:00'":" AND BD.label_date='0000-00-00 00:00:00'";
		}
		
		$OrderLimit = commonfunction::OdrderByAndLimit($this->getData,'ST.shipment_id','DESC');
		
		$select = $this->_db->select()
									->from(array('ST'=>SHIPMENT),array('COUNT(1) AS CNT'))
									->joininner(array('BT' =>SHIPMENT_BARCODE),"ST.shipment_id=BT.shipment_id",array(''))
									->joininner(array('BD' =>SHIPMENT_BARCODE_DETAIL),"BD.barcode_id=BT.barcode_id",array(''))
									->joininner(array('AT' =>USERS_DETAILS),"AT.user_id=ST.user_id",array(""))
									->joininner(array('FT' =>FORWARDERS),"FT.forwarder_id=ST.forwarder_id",array(""))
									->joininner(array('CT' =>COUNTRIES),"CT.country_id=ST.country_id",array(""))
									->joininner(array('SV' =>SERVICES),"ST.service_id=SV.service_id",array(""))
									->where("BT.checkin_status='0' AND BT.delete_status='0' AND ST.delete_status='0'".$where)
									->group("ST.shipment_id");
									//print_r($select->__toString());die;
		$count = $this->getAdapter()->fetchAll($select);							
		
	    $select = $this->_db->select()
									->from(array('ST'=>SHIPMENT),array('rec_name','rec_reference','create_date','rec_zipcode','quantity','addservice_id','shipment_id'))
									->joininner(array('BT' =>SHIPMENT_BARCODE),"ST.shipment_id=BT.shipment_id",array('pickup_status','weight'))
									->joininner(array('BD' =>SHIPMENT_BARCODE_DETAIL),"BD.barcode_id=BT.barcode_id",array('rec_reference','assigned_date','label_date'))
									->joininner(array('AT' =>USERS_DETAILS),"AT.user_id=ST.user_id",array("AT.company_name"))
									->joininner(array('FT' =>FORWARDERS),"FT.forwarder_id=ST.forwarder_id",array("FT.forwarder_name"))
									->joininner(array('CT' =>COUNTRIES),"CT.country_id=ST.country_id",array("CT.country_name"))
									->joininner(array('SV' =>SERVICES),"ST.service_id=SV.service_id",array("SV.service_name"))
									->where("BT.checkin_status='0' AND BT.delete_status='0' AND ST.delete_status='0'".$where)
									->group("ST.shipment_id")
									->order($OrderLimit['OrderBy'].' '.$OrderLimit['OrderType'])
									->limit($OrderLimit['Toshow'],$OrderLimit['Offset']);
		 $records =  $this->getAdapter()->fetchAll($select);								
		}catch(Exception $e){$this->_logger->info('Class-'.__CLASS__.',Function-'.__FUNCTION__.',Line-'.__LINE__.',Error-'.$e->getMessage());}
		
		return array('Total'=>count($count),'Records'=>$records);						
	}
	public function getShipmentHistory($limit=true){
		try{
	    $this->getData['user_id'] = isset($this->getData['user_id'])?Zend_Encript_Encription::decode($this->getData['user_id']):'';
		$this->getData['parent_id'] = isset($this->getData['parent_id'])?Zend_Encript_Encription::decode($this->getData['parent_id']):'';
		$where = $this->LevelClause();
		$where .= commonfunction::filters($this->getData);
		if(isset($this->getData['shipment_type']) && $this->getData['shipment_type']>0){
		    $where .=  " AND ST.shipment_type='".$this->getData['shipment_type']."'";
		}
		if(isset($this->getData['from_date']) && isset($this->getData['to_date']) &&  $this->getData['from_date']!='' && $this->getData['to_date']!=''){
		    $where .=  " AND DATE(BT.checkin_date) BETWEEN '".$this->getData['from_date']."' AND '".$this->getData['to_date']."'";
		}
		if(isset($this->getData['search_word']) && $this->getData['search_word']!=''){
		    $where .=  " AND BT.tracenr_barcode='".trim($this->getData['search_word'])."'";
		}
		$OrderLimit = commonfunction::OdrderByAndLimit($this->getData,'BT.barcode_id','DESC');
		
		/*$select = $this->_db->select()
									->from(array('BT' =>SHIPMENT_BARCODE),array('COUNT(1) AS CNT'))
									->joininner(array('BD'=>SHIPMENT_BARCODE_DETAIL),"BD.barcode_id=BT.barcode_id",array())
									->joininner(array('ST'=>SHIPMENT),"ST.shipment_id=BT.shipment_id",array())
									->joininner(array('AT' =>USERS_DETAILS),"AT.user_id=ST.user_id",array())
									->where("BT.checkin_status='1' AND BT.delete_status='0' AND ST.delete_status='0'".$where);print_r($select->__toString());die;*/
		//$count =  $this->getAdapter()->fetchRow($select);
		
		//$paginations = commonfunction::PageCounter(500,$this->getData);
	    $select = $this->_db->select()
									->from(array('BT' =>SHIPMENT_BARCODE),array('*'))
									->joininner(array('BD'=>SHIPMENT_BARCODE_DETAIL),"BD.barcode_id=BT.barcode_id",array('rec_reference','checkin_date','checkin_ip'))
									//->joininner(array('CL'=>SHIPMENT_BARCODE_LOG),"CL.barcode_id=BT.barcode_id",array(''))
									->joininner(array('ST'=>SHIPMENT),"ST.shipment_id=BT.shipment_id",array('rec_name','rec_street','rec_streetnr','rec_address','rec_street2','country_id','addservice_id','create_date','quantity','goods_id','create_ip','senderaddress_id','rec_zipcode','rec_city','rec_phone','rec_email'))
									->joininner(array('AT' =>USERS_DETAILS),"AT.user_id=ST.user_id",array("AT.company_name",'customer_number','user_id'))
									->joininner(array('CT' =>COUNTRIES),"CT.country_id=ST.country_id",array("CT.country_name"))
									->joininner(array('FT' =>FORWARDERS),"FT.forwarder_id=BT.forwarder_id",array("FT.forwarder_name"))
									->joininner(array('SR' =>SERVICES),"SR.service_id=BT.service_id",array("SR.service_name"))
									->where("BT.checkin_status='1' AND BT.delete_status='0' AND ST.delete_status='0'".$where)
									->order($OrderLimit['OrderBy'].' '.$OrderLimit['OrderType']);
									//print_r($select->__toString());die;
		 if($limit){
		   $select->limit($OrderLimit['Toshow'],$OrderLimit['Offset']);
		 }							
		$records =  $this->getAdapter()->fetchAll($select);
		return array('Total'=>2,'Records'=>$records);
		}catch(Exception $e){$this->_logger->info('Class-'.__CLASS__.',Function-'.__FUNCTION__.',Line-'.__LINE__.',Error-'.$e->getMessage());
		 return array('Total'=>0,'Records'=>array());
		}
	}
	public function getGoodsCategory($goods_check='D',$check=false){
	       $select = $this->_db->select()
									->from(array('GC' =>GOODS_CATEGORY),array('*'))
									->where("status='1'");
			if($check){
			    $select->where("goods_code=?",$goods_check);
			}else{
			    return $this->getAdapter()->fetchAll($select); 
			} 
									//print_r($select->__toString());die;
		return $this->getAdapter()->fetchRow($select);
	}
	public function AddressBookList(){
	     $select = $this->_db->select()
									->from(array('AB' =>ADDRESS_BOOK),array('name','contact','street','street_no','address','street2','postalcode','city','phone','email','country_id'))
									->joininner(array('CT'=>COUNTRIES),"AB.country_id=CT.country_id",array('country_name'))
									->where("user_id=?",$this->getData['user_id']);
		 if(isset($this->getData['Name'])){
		    $select->where("name LIKE ?", $this->getData['Name'].'%');
		 }
		 if(isset($this->getData['postalcode'])){
		    $select->where("postalcode LIKE ?", $this->getData['postalcode'].'%');
		 }
		 if(isset($this->getData['city'])){
		    $select->where("city LIKE ?", $this->getData['city'].'%');
		 }
		 if(isset($this->getData['country_id']) && $this->getData['country_id']>0){
		    $select->where("AB.country_id=?", $this->getData['country_id']);
		 }	//print_r($select->__toString());die;						
		 return $this->getAdapter()->fetchAll($select);							
	}
	public function ErrorCheck($chckType=0){
	   $error = array();
	   if($this->getData['shipment_type']==5){
		   return false;
		}
	    $country_detail = $this->getCountryDetail($this->getData[COUNTRY_ID],1);
	   if($this->getData[ZIPCODE]=='' && ($country_detail['postcode_validate']=='' || $country_detail['postcode_validate']==1)){
	      $error[107] = 'Zipcode Can not be Blank!!';
	   }
	   if(!isset($this->getData[FORWARDER_ID]) || !isset($this->getData[SERVICE_ID])){
	      $error[111] = 'Routing Not found!!';
	   }
	   
	   if($this->getData[RECEIVER]==''){
	      $error[108] = 'Receiver Can not be blank!!';
	   }
	   if($this->getData[STREET]==''){
	      $error[109] = 'Street Can not be blank!!';
	   }
	   if($this->getData[CITY]==''){
	      $error[110] = 'City Can not be blank!!';
	   }
	   if($this->getData[WEIGHT]<=0){
	      $error[101] = 'Weight must be greater than 0!!';
	   }
	   if($this->getData[SERVICE_ID]<=0){
	      $error[102] =  'Please select/send valid service!!';
	   }
	   if($this->getData[ADMIN_ID]<=0){
	      $error[103] =  'Some problem in data Please try again!!';
	   }
	   if($this->getData[COUNTRY_ID]<=0){
	      $error[104] =  'Please assign valid country!!';
	   }
	   if(isset($this->getData['addservice_id']) && ($this->getData['addservice_id']==7 || $this->getData['addservice_id']==146) && $this->getData['cod_price']<=0){
	     $error[105] =  'Either COD price is blank or 0, Please enter valid amount!!';
	   }
	   if(isset($this->getData['addservice_id']) && $this->getData['addservice_id']==5 && $this->getData[PHONE]<=0){
	     $error[106] =  'Either Phone number is blank or invalid, Please select sub service!!';
	   }
	   /*$prices = $this->CalculateParcelPrice($data);
	   if($this->_getData[CUSTOMER_PRICE]<=0){
	      return 'Either Customer Price is not set or Some problem in data Please try again!!';
	   }*/
	   if($chckType==1){
	      if(!empty($error)){
		       echo json_encode(array('error'=>1,'error_msg'=>commonfunction::implod_array($error,'<br>')));die;
		  }else{
		       echo json_encode(array('error'=>0,'error_msg'=>'Proceed'));die;
		  }
	   }
	   if(($this->getData['shipment_type']==0 || $this->getData['shipment_type']==1 || $this->getData['shipment_type']==2) && !empty($error)){
	       return commonfunction::implod_array('<br>',$error); 
	   }elseif(($this->getData['shipment_type']==4 || $this->getData['shipment_type']==10) && !empty($error)){
	        $error = array('Error'=>array('ErrorMessage'=>commonfunction::implod_array($error,',')));
	   }
	   
	   return $error;
	}
	
	public function getShipmentById(){
	  try{
	    $shipment_id = Zend_Encript_Encription::decode($this->getData['shipment_id']);
		$select = $this->_db->select()
									->from(array('ST'=>SHIPMENT),array('*'))
									->joininner(array('CT'=>COUNTRIES),"CT.country_id=ST.country_id",array('continent_id','postcode_length'))
									->where("ST.shipment_id='".$shipment_id."'");
		}catch(Exception $e){ echo $e->getMessage();die;}
		return $this->getAdapter()->fetchRow($select);	
	}
	
   public function shipmentEditLog($oldRecord){
       $oldRecord['edit_date'] =  commonfunction::DateNow();
	   $oldRecord['edit_by'] = $this->Useconfig['user_id'];
	   $oldRecord['edit_ip'] = commonfunction::loggedinIP();
	   $this->insertInToTable(SHIPMENT_EDITED,array($oldRecord));
	   return true;
   }  
   public function deleteExtraShipment($quantitydiff){
			$select = $this->_db->select()
								->from(SHIPMENT_BARCODE,array(BARCODE_ID))
								->where('shipment_id=?',$this->getData['shipment_id'])
								->where('checkin_status=?','0')
								->order("barcode_id DESC")
								->limit(abs($quantitydiff));
								//print_r($select->__toString());die;
			$result = $this->getAdapter()->fetchAll($select);
			foreach($result as $record){
			   $this->_db->delete(SHIPMENT_BARCODE,"barcode_id='".$record['barcode_id']."'");
			   $this->_db->delete(SHIPMENT_BARCODE_DETAIL,"barcode_id='".$record['barcode_id']."'");
			   $this->_db->delete(SHIPMENT_BARCODE_REROUTE,"barcode_id='".$record['barcode_id']."'");
			}
			return true;					
	}
	public function getImportheaders(){
	   $select = $this->_db->select()
								->from(IMPORT_HEADER,array("*"))
								->order('header_id DESC');
								//print_r($select->__toString());die;
	   $results = $this->getAdapter()->fetchAll($select); 
	   
	   return commonfunction::AssociatToLeanier($results,'header_index');
	}
	
	public function importShipment($flag=1,$imp_reco = array()){
	    global $objSession;
		if($flag==1){
			$this->getData['user_id'] = Zend_Encript_Encription::decode($this->getData['user_id']);
			$csvheader = $this->getImportheaders();
			$file_name = commonfunction::ImportFile('import_shipment','csv',$this->getData['user_id']);
			$button_type = (isset($this->getData['import']))?1:2;
			$CsvData = commonfunction::ReadCsv($file_name,';',$button_type);
			$ImportData = commonfunction::importAssociative($CsvData,$csvheader,$this->getData);
		}else{
		   $ImportData = $imp_reco;
		}
		$errorCount = 0;
		$successcount = 0;
		$ErrorList = array();
		foreach($ImportData as $key=>$import){
		  $error = 0 ;
		  $this->getData = $import;
		 /* $this->getData['quantity'] = (!isset($this->getData['quantity']) || $this->getData['quantity']<=0 || $this->getData['quantity']>10)?1:$this->getData['quantity'];
		  $this->getData['email_notification'] = (!empty($this->getData['rec_email'])) ? 1 : 0;*/
		  $this->DataValidation();
		  $routingerr = $this->checkRouting();
		  if(!$routingerr){
		    $ErrorList[] = 'Routing Error in row '.($key+1);
			$error =1 ;
		  }
		  $generalErr = $this->ErrorCheck(); 
		  if($generalErr){
		    $ErrorList[] = 'Following Error in row '.($key+1).'<br>'.$generalErr;
			$error =1 ;
		  }
		  if($error<=0){
		     	$shipment_id = $this->insertInToTable(SHIPMENT,array($this->getData));
	  			$this->shipment_id = array($shipment_id);
				$successcount++;
		  }else{
		      $shipment_id = $this->insertInToTable(SHIPMENT_TEMP,array($this->getData)); 
			  $errorCount++;    
		  }
		  $error = 0;
		}
	
	   if($successcount > 0){
	      $objSession->successMsg = $successcount." Row Imported successfully!!";
	   }
	   if($errorCount>0){
	     $objSession->errorMsg = $errorCount. " Rows Rejected!<br>";
		 $objSession->errorMsg .= implode('<br>',$ErrorList);
		 $objSession->errorMsg .= '<a href="'.BASE_URL.'/Shipment/importerror">Click here</a>';
	   }
	}
	
	public function checkRouting($return=false){
	    $service_id = ($this->getData['addservice_id']>0 )?$this->getData['addservice_id']:$this->getData['service_id'];
	    $services = $this->getRoutingID($service_id,$service_id);
		foreach($services as $service){
		   if($service_id==$service['service_id']){
		     if($return){
			   return $service;
			 }else{
		      $this->getData['forwarder_id'] = $service['forwarder_id'];
		   	  $this->getData['original_forwarder'] = $service['forwarder_id'];
			  return true;
			 } 
		   }  
		} 
		return false;
	}
	public function PrintAction(){
	   global $objSession;
	   switch($this->getData['shipment_mode']){
	      case 'Delete':
		     $this->DeleteParcel();
			 $objSession->successMsg = "Selected shipment(s) deleted successfully!";
		  break;
		  case 'PrintAll':
		    $this->PrintAllLabel();
		  break;
		  case 'PrintShippingList':
		  break;
		  case 'PerformaInvoice':
		  break;
	   }
	}
	public function BulkPrinting(){
	   if($this->getData['BulkShipping']>0){
	       
	   }
	   if($this->getData['BulkPrint']>0){
	       
	   }
	}
	public function DeleteParcel(){
	  if(!empty($this->getData[SHIPMENT_ID])){
		 foreach($this->getData[SHIPMENT_ID] as $shipment_id){	
			$select = $this->_db->select()
								->from(array('BT'=>SHIPMENT_BARCODE),array('shipment_id','barcode_id'))
								->where("BT.".SHIPMENT_ID."=".$shipment_id." AND BT.checkin_status='0'");
			$results = $this->getAdapter()->fetchAll($select);
			foreach($results as $result){
			    $result['deleted_by'] = $this->Useconfig['user_id'];
				$result['deleted_date'] = commonfunction::DateNow();
				$result['deleted_ip'] = commonfunction::loggedinIP();
				$this->insertInToTable(SHIPMENT_DELETED,array($result));
				$this->_db->update(SHIPMENT_BARCODE,array('delete_status'=>1),"barcode_id='".$result['barcode_id']."'");
			}
			$select = $this->_db->select()
								->from(array('BT'=>SHIPMENT_BARCODE),array('COUNT(1) AS CNT'))
								->where("BT.".SHIPMENT_ID."=".$shipment_id." AND BT.checkin_status='1' AND BT.delete_status='0'");
			$checkinCount = $this->getAdapter()->fetchRow($select);
			if($checkinCount['CNT']<=0){
			   $this->_db->update(SHIPMENT,array('delete_status'=>1),"shipment_id='".$shipment_id."'");
			}
		}	 
	  }
	}
	
	public function getImportShipmentList(){
	    try{
	    $this->getData['user_id'] = isset($this->getData['user_id'])?Zend_Encript_Encription::decode($this->getData['user_id']):'';
		$this->getData['parent_id'] = isset($this->getData['parent_id'])?Zend_Encript_Encription::decode($this->getData['parent_id']):'';
		$where = $this->LevelClause();
		$where .= commonfunction::filters($this->getData);
		
		$OrderLimit = commonfunction::OdrderByAndLimit($this->getData,'ST.shipment_id','DESC');
		
		$select = $this->_db->select()
									->from(array('ST'=>SHIPMENT),array('COUNT(1) AS CNT'))
									->joinleft(array('BT' =>SHIPMENT_BARCODE),"ST.shipment_id=BT.shipment_id",array(''))
									->joininner(array('AT' =>USERS_DETAILS),"AT.user_id=ST.user_id",array(""))
									->joininner(array('FT' =>FORWARDERS),"FT.forwarder_id=ST.forwarder_id",array(""))
									->joininner(array('CT' =>COUNTRIES),"CT.country_id=ST.country_id",array(""))
									->where("ST.delete_status='0' AND ISNULL(BT.barcode_id) AND ST.shipment_type!=16".$where);
									
		//$count = $this->getAdapter()->fetchRow($select);							
		
	    $select = $this->_db->select()
									->from(array('ST'=>SHIPMENT),array('rec_name','rec_reference','create_date','rec_zipcode','quantity','addservice_id','shipment_id'))
									->joinleft(array('BT' =>SHIPMENT_BARCODE),"ST.shipment_id=BT.shipment_id",array())
									->joininner(array('AT' =>USERS_DETAILS),"AT.user_id=ST.user_id",array("AT.company_name"))
									->joininner(array('FT' =>FORWARDERS),"FT.forwarder_id=ST.forwarder_id",array("FT.forwarder_name"))
									->joininner(array('CT' =>COUNTRIES),"CT.country_id=ST.country_id",array("CT.country_name"))
									->joininner(array('SV' =>SERVICES),"ST.service_id=SV.service_id",array("SV.service_name"))
									->where("ST.delete_status='0'  AND ISNULL(BT.barcode_id) AND ST.shipment_type!=16".$where)
									->group("ST.shipment_id")
									->order($OrderLimit['OrderBy'].' '.$OrderLimit['OrderType'])
									->limit($OrderLimit['Toshow'],$OrderLimit['Offset']);
		 $records =  $this->getAdapter()->fetchAll($select);								
		}catch(Exception $e){$this->_logger->info('Class-'.__CLASS__.',Function-'.__FUNCTION__.',Line-'.__LINE__.',Error-'.$e->getMessage());}
		
		return array('Total'=>2,'Records'=>$records);
	}
	public function importPrint(){  
	    global $objSession;
	  if($this->getData['shipment_mode']!=''){ 
	   switch($this->getData['shipment_mode']){
			case 'Print':
				    $this->shipment_id = $this->getData[SHIPMENT_ID];
			 		$this->CreateLabel();
					$objSession->successMsg = "Label Printed successfully!";
					break;
			case 'Move':
				    $this->shipment_id = $this->getData[SHIPMENT_ID];
			 		$this->CreateLabel();
					$objSession->successMsg = "Shipment move to new Shipment successfully!";
				break;
			case 'Delete':
			      $this->shipment_id = $this->getData[SHIPMENT_ID];
				  $this->DeleteImportShipment();
				  $objSession->successMsg = "Selected shipment(s) deleted successfully!";
				break;		
		 }
		} 
		 if(isset($this->getData['shipment_mode1']) && $this->getData['shipment_mode1']>0){
				$this->bulkshipment = $this->getData['shipment_mode1'];
				$this->CreateLabel();
				$objSession->successMsg = "Label Printed successfully!";
		 }
	}
	public function DeleteImportShipment(){
	     $select = $this->_db->select()
									->from(array('BT'=>SHIPMENT_BARCODE),array('COUNT(1) AS CNT'))
									->where("BT.shipment_id IN ('".implode("','",$this->shipment_id)."')")
									->group("BT.shipment_id");
		 $records =  $this->getAdapter()->fetchRow($select);
		 if($records['CNT']<=0){
		     $this->_db->delete(SHIPMENT,"shipment_id IN ('".implode("','",$this->shipment_id)."')");
		 }
	}
	
	public function ExportHistory(){
	     $exportData = $this->getShipmentHistory(true);
		 $commonobj = new Application_Model_Common();
		 $commonobj->shipmenthistoryExport($exportData);
		 print_r($exportData);die;
	}
}